package com.igate.gs.test26.multiplemain;

import com.igate.gs.test.immutable.Employee;

public class TestMultiMainClass {

	public static void main(String[] args) {

		System.out.println("Test main method 2 ");

		Employee emp = new Employee();
		emp.setEmpName("Pradeep");
		emp.setEmpSalary(33000.123);

		System.out.println("Employee details  " + emp.getEmpName() + "  "
				+ emp.getEmpSalary());
	}
}

package com.igate.gs.test26.multiplemain;

import com.igate.gs.test.immutable.Employee;

public class TestMainClass {

	public static void main(String[] args) {

		System.out.println("Test main method 1 ");

		Employee emp = new Employee();
		emp.setEmpName("Bhavana");
		emp.setEmpSalary(35000.123);

		System.out.println("Employee details  " + emp.getEmpName() + "  "
				+ emp.getEmpSalary());

	}

}

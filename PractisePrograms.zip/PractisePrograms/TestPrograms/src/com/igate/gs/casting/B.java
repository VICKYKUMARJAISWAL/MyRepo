package com.igate.gs.casting;

public class B extends A{
	
	public B()
	{
		System.out.println("Invoking A class");
	}
	
	public void testB()
	{
		System.out.println("In method testA");
	}
	
	@Override
	public void testA()
	{
		System.out.println("In method testA in class B");
	}

}

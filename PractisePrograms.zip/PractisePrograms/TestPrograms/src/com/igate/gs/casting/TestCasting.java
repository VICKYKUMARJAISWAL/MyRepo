package com.igate.gs.casting;

public class TestCasting {
	public static void main(String[] args) {
		A a = new A();
		B b = new B();

		a.testA();
		b.testB();

		A ab = new B();

		ab.testA(); // Oly parent class methods can be invoked
/*
		B ba = (B) new A(); //Class cast exception

*/		B aab = (B) ab;

		aab.testA();
		aab.testB();

	}

}

package com.igate.gs.casting;

public class A {
	
	public A()
	{
		System.out.println("Invoking A class");
	}
	
	public void testA()
	{
		System.out.println("In method testA");
	}

}

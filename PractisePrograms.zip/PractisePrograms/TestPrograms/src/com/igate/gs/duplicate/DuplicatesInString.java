package com.igate.gs.duplicate;

import java.util.LinkedHashMap;
import java.util.Map;

public class DuplicatesInString {

	public void findDuplicates(String testString) {
		Map<Character, Integer> dupMap = new LinkedHashMap<Character, Integer>();
		char[] charString = testString.toCharArray();

		for (Character ch : charString) {
			if (dupMap.containsKey(ch)) {
				dupMap.put(ch, dupMap.get(ch) + 1);
			} else {
				dupMap.put(ch, 1);
			}
		}

		System.out.println("Duplicates in the map");
		for (Map.Entry<Character, Integer> map : dupMap.entrySet()) {
			if (map.getValue() > 1) {
				System.out.println(map.getKey() + "  " + map.getValue());
			}
		}

	}

	public static void main(String[] args) {
		System.out.println("Inside main method");
		String testString = "Java2Novice";
		DuplicatesInString dupInString = new DuplicatesInString();

		dupInString.findDuplicates(testString);

	}

}

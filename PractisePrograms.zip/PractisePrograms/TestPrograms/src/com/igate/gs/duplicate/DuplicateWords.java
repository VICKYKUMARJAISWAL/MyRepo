package com.igate.gs.duplicate;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DuplicateWords {

	public void findDuplicates(String testString) {
		Map<String, Integer> dupMap = new LinkedHashMap<String, Integer>();
		String[] words = testString.split(" ");

		for (String st : words) {
			if (dupMap.containsKey(st)) {
				dupMap.put(st, dupMap.get(st) + 1);
			} else {
				dupMap.put(st, 1);
			}
		}

		System.out.println("Duplicates in the map");
		for (Map.Entry<String, Integer> map : dupMap.entrySet()) {
			if (map.getValue() > 1) {
				System.out.println(map.getKey() + "  " + map.getValue());
			}
		}

	}

	public static void main(String[] args) {
		System.out.println("Inside main method");
		// String testString =
		// "Java is so boring. It is not my cup of tea. I would not like to do Java anymore";
		DuplicateWords dupWords = new DuplicateWords();
		String testString = null;
		FileInputStream fis = null;
		BufferedReader br = null;
		StringBuffer testData = new StringBuffer("");
		String maxCountLine = null;

		try {
			fis = new FileInputStream("duplicateTest.txt");
			// DataInputStream dis = new DataInputStream(fis);
			br = new BufferedReader(new InputStreamReader(fis));
			while ((testString = br.readLine()) != null) {
				System.out.println(testString);
				testData.append(testString);

				// To find line with max word count
				String[] words = testString.split(" ");
				int wordCount = words.length;
				int previousWordCount = 0;

				if (wordCount > previousWordCount) {
					previousWordCount = wordCount;
					maxCountLine = testString;
				}

			}
			System.out.println("Line with max count of words: " + maxCountLine);

			//Function to call duplicates
			dupWords.findDuplicates(testData.toString());

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				fis.close();
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}
}

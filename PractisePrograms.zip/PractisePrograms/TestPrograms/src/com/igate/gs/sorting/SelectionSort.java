package com.igate.gs.sorting;

public class SelectionSort {

	public static int[] doSelectionSort(int[] array) {

		int arrayLength = array.length;

		for (int i = 0; i <= arrayLength - 1; i++) {
			int index = i;
			for (int j = i + 1; j <= arrayLength-1; j++) {
				if (array[index] > array[j]) {
					index = j;
				}
			}
			int smallestNumb = array[index];
			array[index] = array[i];
			array[i] = smallestNumb;
			
			System.out.println("During sorting");
			for(int k=0;k<=arrayLength-1;k++)
			System.out.println(array[k]);
		}
		return array;
	}

	public static void main(String[] args) {
		int[] array = { 4, 6, 2, 5, 7, 9 };
		System.out.println("Before sorting");
		for (int i = 0; i <= array.length - 1; i++) {
			System.out.println(array[i]);
		}

		int[] sortedArray = doSelectionSort(array);
		
		System.out.println("The sorted array is");
		for (int i = 0; i < sortedArray.length; i++) {
			System.out.println(sortedArray[i]);
		}
	}

}

package com.igate.gs.sorting;

public class QuickSort {
	
	private int[] array;
	private int length;
	
	public static void sort()
	{
		
	}

}

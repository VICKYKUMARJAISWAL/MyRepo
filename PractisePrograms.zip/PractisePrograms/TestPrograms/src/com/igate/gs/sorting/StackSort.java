package com.igate.gs.sorting;

import java.util.*;

public class StackSort {

	public static void main(String[] args) {
		Stack<Integer> inputStack = new Stack<Integer>();
		inputStack.add(13);
		inputStack.add(9);
		inputStack.add(25);
		inputStack.add(17);
		inputStack.add(29);

		StackSort ss = new StackSort();
		inputStack= ss.sortStack(inputStack);
		System.out.println("SortedStack  " + inputStack);

	}

	private Stack<Integer> sortStack(Stack<Integer> inputStack) {
		Stack<Integer> tempStack = new Stack<Integer>();

		while (!inputStack.isEmpty()) {
			int tmp = inputStack.pop();

			while (!tempStack.isEmpty() && tempStack.peek() > tmp) {
				inputStack.push(tempStack.pop());
			}
			tempStack.push(tmp);

		}
		return tempStack;
	}

}

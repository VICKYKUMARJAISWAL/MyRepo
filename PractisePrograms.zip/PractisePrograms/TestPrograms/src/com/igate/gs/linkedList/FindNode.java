package com.igate.gs.linkedList;

//WAP to get the Kth to end nodes of the linked list
public class FindNode {

	public static void main(String[] args) {
		MyLinkedList linkedList = new MyLinkedList();
		
		linkedList.add(10);
		linkedList.add(20);
		linkedList.add(10);
		linkedList.add(30, 1);
		linkedList.add(40);
		linkedList.add(50, 2);
		linkedList.add(60);
		linkedList.display();
		
		Node currentNode = linkedList.getHeadNode();

		System.out.println("\nTo find the 4th to end node ");
		int k = 4;
		int length = linkedList.getSize();
		int index = length - k + 1;

		for (int i = 0; i < index; i++) {
			currentNode = currentNode.getNextRef();
		}

		System.out.println("The required node part");
		for (int j = index; j <= length; j++) {
			System.out.println(currentNode.getValue());
			currentNode=currentNode.getNextRef();
		}
		
		
	}

}

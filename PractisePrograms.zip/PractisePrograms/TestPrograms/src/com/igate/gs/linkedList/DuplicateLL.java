package com.igate.gs.linkedList;

public class DuplicateLL {
	public static void main(String[] args) {
		MyLinkedList linkedList = new MyLinkedList();
		
		linkedList.add(10);
		linkedList.add(20);
		linkedList.add(10);
		linkedList.add(30,1);
		linkedList.add(40);
		linkedList.display();
		linkedList = removeDuplicates(linkedList);
		System.out.println("After removing duplicates");
		linkedList.display();
		
		
		
	}
	
	public static MyLinkedList removeDuplicates(MyLinkedList ll)
	{
		int llSize = ll.getSize();
		
		for(int i=0;i<llSize;i++)
		{
			Object value = ll.get(i);
			
			for(int j=i+1;j<=llSize;j++)
			{
				Object cmpValue = ll.get(j);
				
				if(cmpValue.equals(value))
				{
					ll.remove(j);
					llSize--;
				}
			}
						
		}
		
		return ll;
	}

}

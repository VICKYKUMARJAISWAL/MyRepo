package com.igate.gs.linkedList;

public class ReverseLinkedList {
	public static void main(String[] args) {
		MyLinkedList linkedList = new MyLinkedList();

		System.out.println("The linked list created");
		linkedList.add(10);
		linkedList.add(20);
		linkedList.add(10);
		linkedList.add(30, 1);
		linkedList.add(40);
		linkedList.add(50, 2);
		linkedList.add(60);
		linkedList.display();
		
		System.out.println("\n Reverse Linked list");
		
		

	}
	
	public void reverse(MyLinkedList ll)
	{
	}

}

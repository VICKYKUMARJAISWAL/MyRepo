package com.igate.gs.linkedList;

public class MyLinkedList {

	private Node head;
	private int linkedListSize;

	public MyLinkedList() {
		head = new Node(null);
		linkedListSize = 0;
	}

	public void add(Object data) {
		Node tempNode = new Node(data);

		Node currentNode = head;

		while (currentNode.getNextRef() != null) {
			currentNode = currentNode.getNextRef();
		}

		currentNode.setNextRef(tempNode);
		linkedListSize++;
	}

	public void add(Object data, int index) {
		Node tempNode = new Node(data);

		Node currentNode = head;

		for (int i = 0; i < index && currentNode.getNextRef() != null; i++) {
			currentNode = currentNode.getNextRef();
		}

		tempNode.setNextRef(currentNode.getNextRef());
		currentNode.setNextRef(tempNode);
		linkedListSize++;
	}

	public Object get(int index) {
		if (index <= 0 && index > linkedListSize) {
			return -1;
		}

		Node currentNode = head;

		for (int i = 0; i < index; i++) {
			currentNode = currentNode.getNextRef();
		}

		return currentNode.getValue();
	}

	public boolean remove(int index) {
		Node currentNode = head;

		if (index <= 0 || index > linkedListSize) {
			return false;
		}

		for (int i = 0; i < index-1; i++) {
			currentNode = currentNode.getNextRef();
		}

		currentNode.setNextRef(currentNode.getNextRef().getNextRef()); // /Replace
																		// the
																		// index
																		// with
																		// next
																		// Node
																		// value
		linkedListSize--;

		return true;

	}
	
	public int getSize()
	{
		return linkedListSize;
	}
	
	public Node getHeadNode()
	{
		return head;
	}

	public void display() {
		System.out.println("\nLinkedList values");
		for(int i=0;i<=linkedListSize;i++)
		{
			System.out.println(get(i));
		}

	}

	
	public static void main(String[] args) {
		MyLinkedList ll = new MyLinkedList();
	
		ll.add(10);
		ll.display();
		ll.add(10);
		ll.display();
		ll.add(20);
		ll.display();
		ll.remove(1);
		ll.display();
		ll.add(40, 2);
		ll.display();
		ll.add(50);
		ll.display();
		ll.add(60,1);
		ll.display();

	}
	 
}

class Node {
	private Object value;

	private Node nextRef;

	public Node() {

	}

	public Node(Object value) {
		this.value = value;
		this.nextRef = null;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public Node getNextRef() {
		return nextRef;
	}

	public void setNextRef(Node nextRef) {
		this.nextRef = nextRef;
	}

}

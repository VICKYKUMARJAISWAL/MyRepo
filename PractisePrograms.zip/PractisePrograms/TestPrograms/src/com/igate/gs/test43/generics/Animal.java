/**
 * 
 */
package com.igate.gs.test43.generics;

import java.util.HashMap;
import java.util.Map;

/**
 * @author br815792
 *
 */
public class Animal {

	 Map<String,Animal> animalTypes = new HashMap<String,Animal>();
     
	 
	 public <T> void addAnimal(String name,Class<T> animalType, T animal)
	 {
		 
	 }
	
	
	
}

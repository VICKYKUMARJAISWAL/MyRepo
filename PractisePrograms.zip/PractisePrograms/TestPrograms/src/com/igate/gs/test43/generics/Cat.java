/**
 * 
 */
package com.igate.gs.test43.generics;

/**
 * @author br815792
 *
 */
public class Cat {

}

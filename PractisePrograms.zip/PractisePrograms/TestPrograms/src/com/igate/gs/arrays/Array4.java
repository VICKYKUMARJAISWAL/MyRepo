package com.igate.gs.arrays;

import java.util.Arrays;

//Find the longest consecutive seq in the array
public class Array4 {

	public static void main(String[] args) {
		int[] numbs = { 100, 4, 200, 1, 3, 2 };
		
		int[] consecutiveArray = new int[numbs.length];
		int[] longestArray = new int[numbs.length];

		for (int i = 0; i < numbs.length; i++) {
			int consecBegin = numbs[i];
			int index = 0;
			consecutiveArray = new int[numbs.length];
			while (getNumberSequential(numbs,consecBegin+1) != -1) {
				consecutiveArray[index] = consecBegin;
				consecBegin = consecBegin + 1;
				index++;

			}
			if (longestArray.length < consecutiveArray.length) {
				longestArray = consecutiveArray;
			}
		}

		System.out.println("The longest conseq seq is:");
		for (int val : consecutiveArray) {
			System.out.print(val + " ");
		}
	}

	public static int getNumberBinary(int[] numbArray, int key) {
		Arrays.sort(numbArray);
		int start = 0;
		int end = numbArray.length - 1;

		while (start < end) {
			int mid = (start + end) / 2;
			if (key == numbArray[mid]) {
				return mid;
			} else if (key < numbArray[mid]) {
				end = mid - 1;
			} else {
				start = mid + 1;
			}
		}
		return -1;
	}

	public static int getNumberSequential(int[] numbArray, int key) {

		for (int i = 0; i < numbArray.length; i++) {
			if (key == numbArray[i]) {
				return i;
			}

		}
		return -1;
	}

}

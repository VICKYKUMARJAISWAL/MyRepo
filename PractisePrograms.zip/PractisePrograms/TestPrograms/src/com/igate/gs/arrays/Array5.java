package com.igate.gs.arrays;

//How to reverse an array
public class Array5 {
	public static void main(String[] args) {
		int[] array = {5,2,8,5,9,};
		int arrayLength = array.length;
		System.out.println("Original Array: ");
		for(int in:array)
		{
		System.out.print(in);
		}
		
		for(int i=0;i<arrayLength/2;i++)
		{
			int tmp;
			tmp=array[i];
			array[i]=array[arrayLength-1-i];
			array[arrayLength-1-i]=tmp;
				
		}
		
		System.out.println("\nReverse Array: ");
		for(int in:array)
		{
		System.out.print(in);
		}
	}
	
}

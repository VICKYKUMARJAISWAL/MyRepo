package com.igate.gs.arrays;

/*WAP to find the index of the element such that the some of the numbers before it 
 is equal to the some of the numbers following it*/
public class Array1 {
	public static void main(String[] args) {
		System.out.println("Method excecution started");
		int array[] = { 3, 5, 8, 4, 4 };

		int middleNumb = 0;

		int arrayLength = array.length;

		for (int i = 0; i < arrayLength; i++) {
			int preSum = 0;
			int postSum = 0;

			if (i != 0) {

				for (int j = 0; j < i; j++) {
					preSum += array[j];
				}

				for (int k = arrayLength - 1; k > i; k--) {
					postSum += array[k];
				}

				if (preSum == postSum) {
					middleNumb = array[i];
					System.out.println("The middle element is:  " + middleNumb);
				}
			}

		}
	}

}

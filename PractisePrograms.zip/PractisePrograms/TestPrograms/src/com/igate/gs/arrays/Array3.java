package com.igate.gs.arrays;

//Find the smallest and highest numb in an array
public class Array3 {
	public static void main(String[] args) {
		int[] numb = { 3, 4, 1, 6, 9, 2 };

		int maxNumb = numb[0];
		int minNumb = numb[0];
		int maxNumb2 = numb[0];
		int minNumb2 = numb[0];

		for (int number : numb) {
			if (number < minNumb) {
				minNumb2 = minNumb;
				minNumb = number;
			} else if (number > maxNumb) {
				maxNumb2 = maxNumb;
				maxNumb = number;
			}
		}

		System.out.println("Max numb:  " + maxNumb + " Min numb:  " + minNumb);
		System.out.println("2nd Max numb:  " + maxNumb2 + " 2nd Min numb:  "
				+ minNumb2);
	}

}

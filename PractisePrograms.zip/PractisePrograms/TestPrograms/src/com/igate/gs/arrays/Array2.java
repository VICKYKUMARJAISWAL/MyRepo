package com.igate.gs.arrays;

//How to remove duplicates from an array
public class Array2 {
	public static void main(String[] args) {
		int[] a = { 2, 4, 6, 7, 4, 8, 1 };

		int[] resultArray = new int[a.length];
		int[] resultArrayUnsorted = new int[a.length];

		// If array is sorted

		// Arrays.sort(a);
		int checkVar = a[0];
		resultArray[0] = checkVar;
		for (int i = 1; i < a.length; i++) {
			int tmp = a[i];
			if (checkVar != tmp) {
				resultArray[i] = a[i];
			}
			checkVar = tmp;

		}
		System.out.println("Array widout duplicates : ");
		for (int in : resultArray) {
			System.out.print(in);
		}

		// If array is not sorted
		boolean flag = true;
		for (int i = 0; i < a.length; i++) {
			int previous = a[i];
			for (int j = i + 1; j < a.length; j++) {
				int tmpVar = a[j];
				if (previous == tmpVar) {
					flag = false;
					break;
				} else {
					flag = true;
				}
			}

			if (flag == true) {
				resultArrayUnsorted[i] = a[i];
			}

		}
		System.out.println("\nArray widout duplicates wen unsorted:");

		for (int val : resultArrayUnsorted) {

			System.out.print(val);
		}

	}
}

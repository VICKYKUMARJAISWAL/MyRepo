package com.igate.gs.arrays;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//Extract the integers from a given string
public class ExtractInteger {

	public static void main(String[] args) {

		String input1 = "bhavana: 3ms  bhavana lkjasd asdasd: 2ms";

		// Using Character functionality
		System.out.println("Using Character class");
		for (int i = 0; i < input1.length(); i++) {

			if (Character.isDigit(input1.charAt(i))) {
				System.out.print(input1.charAt(i) + " ");
			}
		}

		// Using Regex
		System.out.println("\nUsing regex");
		String numbers = input1.replaceAll("[^0-9]+", " ");
		for (String in : numbers.trim().split(" ")) {
			System.out.println("Nummbers in the string are:  " + in);

		}
		System.out.println("Array format"
				+ Arrays.asList(numbers.trim().split(" ")));

		// Using Regex pattern
		System.out.println("Using pattern and matcher regex");
		Pattern pattern = Pattern.compile("[0-9]+");
		Matcher matcher = pattern.matcher(input1);

		while (matcher.find()) {
			String st = matcher.group();
			System.out.println(st);
		}

	}
}

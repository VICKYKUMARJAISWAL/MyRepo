package com.igate.gs.test30.multithreading;

public class EvenOddAlternative {
	public static void main(String[] args) {
		Numbers numb = new Numbers();

		Thread evenThread = new Thread(new EvenThread(numb));
		Thread oddThread = new Thread(new OddThread(numb));

		evenThread.start();
		oddThread.start();

	}
}

class Numbers {
	private static int currentOdd = 1;

	private static int currentEven = 0;

	public volatile String flag = "odd";

	public synchronized int getEven() {
		if ("even".equals(flag)) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		int i = currentEven;
		currentEven = currentEven + 2;
		flag = "even";
		notify();
		return i;
	}

	public synchronized int getOdd() {
		if ("odd".equals(flag)) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		int i = currentOdd;
		currentOdd = currentOdd + 2;
		flag = "odd";
		notify();
		return i;
	}
}

class EvenThread implements Runnable {

	Numbers numb;

	public EvenThread() {

	}

	public EvenThread(Numbers numb) {
		this.numb = numb;
	}

	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println(numb.getEven());
		}
	}
}

class OddThread implements Runnable {

	Numbers numb;

	public OddThread() {

	}

	public OddThread(Numbers numb) {
		this.numb = numb;
	}

	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println(numb.getOdd());
		}
	}
}
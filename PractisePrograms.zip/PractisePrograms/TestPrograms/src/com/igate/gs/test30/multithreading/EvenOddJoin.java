package com.igate.gs.test30.multithreading;

public class EvenOddJoin {

	public static void main(String[] args) {
		Thread evenThread = new Thread(new Even());
		Thread oddThread = new Thread(new Odd());

		try {
			evenThread.start();
			oddThread.start();
			evenThread.join();
			oddThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}

class Even implements Runnable {

	public void run() {
		for (int i = 0; i < 11; i++) {
			if (i % 2 == 0) {
				System.out.println("Even" + i);
			}
		}
	}

}

class Odd implements Runnable {

	public void run() {
		for (int i = 0; i <= 11; i++) {
			if (i % 2 == 1) {
				System.out.println("Odd" + i);
			}
		}
	}

}

/**
 * 
 */
package com.igate.gs.test.singleton;

/**
 * @author br815792
 * 
 */
public class TestSingletonMain {

	public static void main(String[] args) {
		System.out.println("Inside main method - Testing Singleton");
		TestSingletonDCL testDCL = TestSingletonDCL.getInstance();
		TestSingletonDCL testDCL1 = TestSingletonDCL.getInstance();

		if (testDCL == testDCL1) {
			System.out.println("Singleton DCL successfully tested");
		} else {
			System.out
					.println("Objects returned do not belong to singleton class");
		}

		TestSingletonEarlyLoading testEarlyInit = TestSingletonEarlyLoading
				.getInstance();
		TestSingletonEarlyLoading testEarlyInit1 = TestSingletonEarlyLoading
				.getInstance();

		if (testEarlyInit == testEarlyInit1) {
			System.out
					.println("Singleton Early Initialization successfully tested");
		} else {
			System.out
					.println("Objects returned do not belong to singleton class");
		}

		TestSingletonWithoutCloning testcloneObject = TestSingletonWithoutCloning
				.getInstance();
		TestSingletonWithoutCloning newClonedObject = null;
		try {
			newClonedObject = (TestSingletonWithoutCloning) testcloneObject
					.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

		if (testcloneObject == newClonedObject) {
			System.out.println("Cloning Successful");
		}

	}

}

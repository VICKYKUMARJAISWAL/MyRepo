package com.igate.gs.test.immutable;

public class TestImmutableClass {

	public static void main(String[] args)
	{
		System.out.println("Test immutable class Company -- Start");
		
		Employee emp = new Employee();
		emp.setEmpName("Bhavana");
		emp.setEmpSalary(35000.123);
		

		Employee emp1 = new Employee();
		emp1.setEmpName("Cressy");
		emp1.setEmpSalary(32000.123);
		
		
		//Create first instance of the immutable class
		
		Company company = new Company("Igate", emp1);
		
		System.out.println("Company name  " + company.getCompanyName());
		
		Employee empComp = company.getEmployee();
		System.out.println("Employee details  " + empComp.getEmpName() + "  " + empComp.getEmpSalary());
		
		//Creating another instance of the immutable class - Creates a copy of company object and works on the same

		Company companyOne = new Company("GS", emp);
		
		System.out.println("Company name  " + companyOne.getCompanyName());
		
		Employee empComp1 = companyOne.getEmployee();
		System.out.println("Employee details  " + empComp1.getEmpName() + "  " + empComp1.getEmpSalary());
		
		
		
		System.out.println("Test immutable class Company -- End");
		
	}

}

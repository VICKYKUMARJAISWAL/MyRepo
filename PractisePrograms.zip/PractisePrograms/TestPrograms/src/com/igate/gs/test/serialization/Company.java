package com.igate.gs.test.serialization;

import java.io.Serializable;

public class Company implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String companyName;
	public String companyType;
	
}

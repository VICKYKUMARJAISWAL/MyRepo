package com.igate.gs.matrices;

public class TransposeMatrix {
	public static void main(String[] args) {
		int[][] mat = {{1,2,3},{4,5,6}};
	}

}

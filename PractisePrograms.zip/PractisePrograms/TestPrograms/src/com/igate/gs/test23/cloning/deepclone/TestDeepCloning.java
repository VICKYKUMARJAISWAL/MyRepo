/**
 * 
 */
package com.igate.gs.test23.cloning.deepclone;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.igate.gs.test23.cloning.Address;
import com.igate.gs.test23.cloning.Employee;

/**
 * @author br815792
 * 
 */
public class TestDeepCloning {

	public static void main(String[] args) {

		Employee emp = new Employee();
		Address address = new Address("whitefield", "Bangalore", "Karnataka");
		Address address1 = new Address("magarpatta", "Pune", "Maharastra");

		emp.setEmpName("Bhavana");
		emp.setAddress(address);

		System.out.println("Before Cloning -- EMployee details  "
				+ emp.getEmpName() + "  " + emp.getAddress().getStreet());

		Employee emp1 = (Employee) deepClone(emp);

		emp1.setEmpName("Pradeep");
		emp1.setAddress(address1);

		System.out.println("After Cloning -- EMployee details  "
				+ emp1.getEmpName() + "  " + emp1.getAddress().getStreet());

	}

	public static Object deepClone(Object object) {
		ByteArrayOutputStream baos = null;
		ObjectOutputStream oos = null;
		ByteArrayInputStream bais = null;
		ObjectInputStream ois = null;
		try {
			baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
			bais = new ByteArrayInputStream(baos.toByteArray());
			ois = new ObjectInputStream(bais);
			return ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				baos.close();
				oos.close();
				bais.close(); // Once the o/p stream is closed automatically i/p is closed.
				ois.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}
}

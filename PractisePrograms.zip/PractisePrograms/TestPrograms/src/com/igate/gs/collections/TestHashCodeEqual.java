package com.igate.gs.collections;

import java.util.HashMap;
import java.util.Map;

public class TestHashCodeEqual {
	public static void main(String[] args) {

		Employee emp1 = new Employee(100, "Siddhu");
		Map<Employee, String> hm = new HashMap<Employee, String>();
		hm.put(emp1, "Employee1");
		hm.put(new Employee(101, "shahid"), "Employee2");
		hm.put(new Employee(102, "hrithik"), "Employee3");
		hm.put(new Employee(101, "shahid"), "Employee2");

		System.out.println("Map printed as follows");
		for (Map.Entry<Employee, String> map : hm.entrySet()) {
			Employee emp = (Employee) map.getKey();
			System.out.println("EmployeeId:" + emp.getEmployeeId()
					+ "   EmployeeName:" + emp.getEmployeeName());
		}

	}
}

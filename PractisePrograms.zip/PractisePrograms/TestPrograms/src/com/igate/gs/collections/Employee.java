package com.igate.gs.collections;


public class Employee {

	int employeeId;
	String employeeName;

	public Employee() {
		System.out.println("Employee Empty Constructor invoked");
	}

	public Employee(int employeeId, String employeeName) {
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
 	public int hashCode() {

		int hashCode = employeeId * 20;
		hashCode += employeeName.hashCode();

		return hashCode;
	}

	public boolean equals(Object o) {
		if (o instanceof Employee) {
			Employee emp = (Employee) o;
			return (emp.employeeId == this.employeeId && emp.employeeName == this.employeeName);
		} else {
			return false;
		}

	}
}

package com.igate.gs.test34.multithreading;

public class Producer extends Thread {

	ProducerConsumerImpl pcImpl;

	public Producer(ProducerConsumerImpl pc) {
		super();
		pcImpl = pc;
	}

	@Override
	public void run() {
		try {
			pcImpl.put();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}

package com.igate.gs.test34.multithreading;

public class ProducerConsumerSolutionUsingLock {

	public static void main(String[] args) {
		System.out.println("Testing the Producer Consumer prob using lock");

		ProducerConsumerImpl sharedQueue = new ProducerConsumerImpl();

		Producer prod = new Producer(sharedQueue);
		Consumer cons = new Consumer(sharedQueue);

		prod.start();
		cons.start();
	}
}

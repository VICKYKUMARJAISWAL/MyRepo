/**
 * 
 */
package com.igate.gs.test31.multithreading;

import java.util.Vector;

/**
 * @author br815792
 * 
 */
public class Producer implements Runnable {

	public Producer(Vector sharedQueue, int size) {
		super();
		this.sharedQueue = sharedQueue;
		this.size = size;
	}

	private final Vector sharedQueue;
	private final int size;

	public void run() {
		for (int i = 1; i <= 10; i++) {
			try {
				while (sharedQueue.size() == size) {
					synchronized (sharedQueue) {
						System.out.println("Queue is full"
								+ Thread.currentThread().getName()
								+ "is waiting");

						sharedQueue.wait();
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			synchronized (sharedQueue) {
				System.out.println("Produced:" + i);
				sharedQueue.add(i);
			
				sharedQueue.notifyAll();
			}

		}
	}
}

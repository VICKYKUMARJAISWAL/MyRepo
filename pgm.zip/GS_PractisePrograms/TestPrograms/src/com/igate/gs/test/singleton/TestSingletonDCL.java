/**
 * 
 */
package com.igate.gs.test.singleton;

/**
 * @author br815792
 * 
 */
public class TestSingletonDCL {

	private static TestSingletonDCL singletonObject;

	private TestSingletonDCL() {
		System.out
				.println("TestSingletonDCL object instantiated inside the TestSingletonDCL class");
	}

	// The following method depicts double checked locking and is a way of lazy
	// initialization
	public static TestSingletonDCL getInstance() {
		if (singletonObject == null) {
			synchronized (TestSingletonDCL.class) {
				if (singletonObject == null) {
					singletonObject = new TestSingletonDCL();
				}
			}
		}

		return singletonObject;
	}

}

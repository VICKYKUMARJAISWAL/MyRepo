package com.igate.gs.test.singleton;

public class TestSingletonEarlyLoading {

	private static final TestSingletonEarlyLoading singletonObject = new TestSingletonEarlyLoading();

	private TestSingletonEarlyLoading() {
		System.out
				.println("Inside TestSingletonEarlyLoading constructor -- object initialized when class is loaded");
	}

	// The below method depicts early loading since the object has already been
	// eagerly initialized above
	public static TestSingletonEarlyLoading getInstance() {
		return singletonObject;
	}
}

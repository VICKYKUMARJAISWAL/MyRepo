package com.igate.gs.test.singleton;

public class TestSingletonWithoutCloning implements Cloneable {
	private static TestSingletonWithoutCloning singletonObject = new TestSingletonWithoutCloning();

	private TestSingletonWithoutCloning() {
		System.out
				.println("Inside TestSingletonWithoutCloning constructor -- object initialized when class is loaded");
	}

	public static TestSingletonWithoutCloning getInstance() {
		return singletonObject;
	}

	// This method need not be given unless this class's superclass implements
	// Cloneable
	// Otherwise cloning is by default prevented unless your class implement
	// Cloneable
	public Object clone() throws CloneNotSupportedException {
		System.out
				.println("TestSingletonWithoutCloning Class cannot be cloned since it is a singleton class");
		throw new CloneNotSupportedException();
	}

}

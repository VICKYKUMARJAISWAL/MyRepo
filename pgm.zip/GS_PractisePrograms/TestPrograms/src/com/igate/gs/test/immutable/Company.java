package com.igate.gs.test.immutable;

public final class Company {

	private final String companyName;
	private final Employee employee;
	
	public Company(String companyName,Employee employee)
	{
		this.companyName = companyName;
		this.employee = employee;
	}
	
	/*public Company(String companyName) {
		this.companyName = companyName;
	}
	
	public Company(Employee employee) {
		this.employee = employee;
	}*/

	public String getCompanyName() {
		return companyName;
	}

	public Employee getEmployee() {
		return employee;
	}

}

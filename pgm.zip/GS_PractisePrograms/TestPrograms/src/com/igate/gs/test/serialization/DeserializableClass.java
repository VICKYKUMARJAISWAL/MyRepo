package com.igate.gs.test.serialization;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.Timestamp;
import java.util.Date;

public class DeserializableClass {

	public static void main(String[] args) {
		Company company = new Company();
		Employee emp = new Employee();
		FileInputStream fIn = null;
		ObjectInputStream in = null;
		Date date = null;
		Timestamp time = null;
		try {
			fIn = new FileInputStream("./employee.txt");
			in = new ObjectInputStream(fIn);
			emp = (Employee) in.readObject();
			company = (Company) in.readObject();
					
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} finally {
			try {
				fIn.close();
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		System.out.println("Deserialized Output  " + emp.firstName + "  "
				+ emp.lastName + "\nCompany details   " + company.companyName
				+ "   " + company.companyType);
	}

}

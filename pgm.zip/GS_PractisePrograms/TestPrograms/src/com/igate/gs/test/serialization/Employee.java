package com.igate.gs.test.serialization;


public class Employee extends Company{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String firstName;
	public String lastName;
	public Address address;

}

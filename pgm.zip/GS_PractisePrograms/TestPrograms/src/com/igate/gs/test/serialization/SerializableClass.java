package com.igate.gs.test.serialization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Timestamp;
import java.util.Date;

public class SerializableClass {

	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.firstName = "Bhavana";
		emp.lastName = "Rao";

		Company company = new Company();
		company.companyName = "Igate";
		company.companyType = "Servicing";
		Date date = null;
		Timestamp time = null;
		FileOutputStream fOut = null;
		ObjectOutputStream out = null;

		System.out.println("Input to be serialized    " + emp.firstName + "   "
				+ emp.lastName);
		try {
			fOut = new FileOutputStream("./employee.txt");
			out = new ObjectOutputStream(fOut);
			date = new Date();
			time = new Timestamp(date.getTime());
			out.flush();
			out.writeObject(emp);
			out.flush();
			out.writeObject(company);
		} catch (IOException exception) {
			exception.printStackTrace();
		} finally {
			try {
				out.flush();
				out.close();
				fOut.close();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
		}

		System.out.println("Company details  " + company.companyName + "   "
				+ company.companyType);

	}

}

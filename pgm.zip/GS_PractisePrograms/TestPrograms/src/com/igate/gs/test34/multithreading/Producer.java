package com.igate.gs.test34.multithreading;

public class Producer extends Thread {

	ProducerConsumerImpl pcImpl;

	public Producer(ProducerConsumerImpl pc) {
		super();
		this.pcImpl = pc;
	}

	@Override
	public void run() {
		try {
			pcImpl.put();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}

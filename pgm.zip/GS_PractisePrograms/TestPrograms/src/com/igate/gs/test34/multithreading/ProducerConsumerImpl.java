package com.igate.gs.test34.multithreading;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ProducerConsumerImpl {

	private final static int capacity = 5;
	private final Queue sharedQueue = new LinkedList();

	Lock aLock = new ReentrantLock();
	private final Condition isQueueEmpty = aLock.newCondition();
	private final Condition isQueuefull = aLock.newCondition();

	public void put() throws InterruptedException {
		aLock.lock();
		
		try
		{
		for (int i = 0; i <= 7; i++) {

			while (sharedQueue.size() == capacity) {
				System.out
						.println("Queue is full. Waiting for elements to be removed :  "
								+ Thread.currentThread().getName());
				isQueuefull.await();
			}
			
			
			boolean isAdded = sharedQueue.offer(i);
			
			if(isAdded)
			{
				System.out.println("Element has been added to Queue: " + i);
				isQueueEmpty.signal();
			}
		}
			}
		finally
		{
			aLock.unlock();
		}
	}
	
	
	
	public void get() throws InterruptedException {
		aLock.lock();
		
		try
		{
			while (sharedQueue.size() == 0) {
				System.out
						.println("Queue is empty. Waiting for elements to be aded :  "
								+ Thread.currentThread().getName());
				isQueueEmpty.await();
			}
			
			
			Integer value = (Integer) sharedQueue.poll();
			
			if(value != null)
			{
				System.out.println("Element has been removed from queue:  " + value);
				isQueuefull.signal();
			}
			}
		finally
		{
			aLock.unlock();
		}
	}
	
	

}

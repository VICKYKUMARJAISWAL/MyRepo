package com.igate.gs.test34.multithreading;

public class Consumer extends Thread {
	ProducerConsumerImpl pcImpl;

	public Consumer(ProducerConsumerImpl pc) {
		super();
		this.pcImpl = pc;
	}

	@Override
	public void run() {
		try {
			pcImpl.get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}

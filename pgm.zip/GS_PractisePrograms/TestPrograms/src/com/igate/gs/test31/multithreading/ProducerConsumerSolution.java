package com.igate.gs.test31.multithreading;

import java.util.Vector;

public class ProducerConsumerSolution {

	public static void main(String[] args) {
		System.out.println("Testing ProducerConsumerSolution in main method");

		Vector sharedQueue = new Vector();
		int size = 5;

		Thread prodThread = new Thread(new Producer(sharedQueue, size));
		Thread conThread = new Thread(new Consumer(sharedQueue, size));
		prodThread.start();
		conThread.start();
		
	}

}

package com.igate.gs.test31.multithreading;

import java.util.Vector;

public class Consumer implements Runnable {

	private final Vector sharedQueue;
	private final int size;

	public Consumer(Vector sharedQueue, int size) {
		super();
		this.sharedQueue = sharedQueue;
		this.size = size;
	}

	public void run() {
		while (true) {
			try {

				System.out.println("Consumer:" + consume());
				Thread.sleep(50);

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public int consume() throws InterruptedException {
		if (sharedQueue.isEmpty()) {
			synchronized (sharedQueue) {
				System.out.println("Queue is empty"
						+ Thread.currentThread().getName() + "is waiting");

				sharedQueue.wait();
			}
		}

		synchronized (sharedQueue) {
			sharedQueue.notifyAll();
			return (Integer) sharedQueue.remove(0);
		}
	}

}

/**
 * 
 */
package com.igate.gs.test23.cloning.shallowclone;

import com.igate.gs.test23.cloning.Address;
import com.igate.gs.test23.cloning.Employee;

/**
 * @author br815792
 *
 */
public class TestShallowCloning {
	
	public static void main(String[] args)
	{
		System.out.println("Test Shallow Cloning");
		Employee emp = new Employee();
		Address address = new Address("whitefield", "Bangalore", "Karnataka");
		Address address1 = new Address("magarpatta", "Pune", "Maharastra");

		emp.setEmpName("Bhavana");
		emp.setAddress(address);

		System.out.println("Before Cloning -- EMployee details  "
				+ emp.getEmpName() + "  " + emp.getAddress().getStreet());

		Employee emp1 = (Employee) emp.clone(emp);

		emp1.setEmpName("Pradeep");
		emp1.setAddress(address1);

		System.out.println("After Cloning -- EMployee details  "
				+ emp1.getEmpName() + "  " + emp1.getAddress().getStreet());
		
	}

}

/**
 * 
 */
package com.igate.gs.test23.cloning;

import java.io.Serializable;

/**
 * @author br815792
 * 
 */
public class Employee implements Serializable,Cloneable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	
	public String empName;
	public Address address;

	public Employee() {
		super();
	}

	public Employee(String empName, Address address) {
		super();
		this.empName = empName;
		this.address = address;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public Object clone(Object o)
	{
		try
		{
		return super.clone();
		}catch(CloneNotSupportedException e)
		{
			e.printStackTrace();
			return null;
		}
	}

}

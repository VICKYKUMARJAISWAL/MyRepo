package com.igate.gs.test44.stack;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class TestReverseCollection {

	public static void main(String[] args) {
		System.out.println("Testinf reverse Collection operation using Stack");

		StackImpl stImpl = new StackImpl();

		List<String> list = new ArrayList<String>();

		list.add("a");
		list.add("b");
		list.add("c");
		list.add("d");

		Stack<String> st = new Stack<String>();
		Stack<String> reverseStack = new Stack<String>();

		for (String addValue : list) {
			stImpl.showPush(st, addValue);
		}

		System.out
				.println("The stack value after pushing the Collection into it --"
						+ st);

		System.out.println("Peek a value from on top of the stack -- "
				+ stImpl.showPeek(st));

		for (int i = 0; i < list.size(); i++) {
			reverseStack.push(stImpl.showPop(st));
		}

		System.out.println("Reverse Collection value --" + reverseStack);

	}

}

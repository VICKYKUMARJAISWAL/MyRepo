package com.igate.gs.test44.stack;

import java.util.Stack;

public class StackImpl {
	
	public void showPush(Stack<String> st,String value)
	{
		System.out.println("Push Operation --" + value);
		st.push(value);
		System.out.println("Stack value after push  "+st);
	}
	
	
	public String showPop(Stack<String> st)
	{
		System.out.println("Pop Opertaion ");
		String returnValue = st.pop();
		System.out.println("Stack Value after Pop --" + st);
		System.out.println(returnValue);
		return returnValue;
	}
	
	public String showPeek(Stack<String> st)
	{
		System.out.println("Peek Opertaion ");
		String returnValue = st.peek();
		System.out.println("Value peeked  "+returnValue);
		System.out.println("Stack Value after Peek --" + st);
		return returnValue;
	}
	
	
	
}

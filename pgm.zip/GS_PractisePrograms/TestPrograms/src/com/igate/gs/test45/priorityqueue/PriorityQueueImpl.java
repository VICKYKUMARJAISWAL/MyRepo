package com.igate.gs.test45.priorityqueue;

public class PriorityQueueImpl {

	private Comparable[] pQueue;
	private int index;

	public PriorityQueueImpl() {
		pQueue = new Comparable[5];
	}

	public void insert(Comparable value) {
		if (index == pQueue.length) {
			System.out.println("Queue is full. Cannot be inserted");
		} else {
			pQueue[index] = value;
			index++;
			System.out.println(value + "  added to Queue" + "  Index " + index);
		}

	}

	public Comparable remove() {
		if (index == 0) {
			System.out.println("Queue is empty cannot remve value");
			return null;
		}

		int maxIndex = 0;

		for (int i = 1; i < index; i++) {
			if (pQueue[i].compareTo(pQueue[maxIndex]) > 0) {
				maxIndex = i;
			}
		}

		Comparable result = pQueue[maxIndex];
		System.out.println("Value removed from Queue  " + result);
		index--;
		pQueue[maxIndex] = pQueue[index]; // Replace the index of the value
											// removed with the last value to
											// maintain the order

		return result;

	}

	public static void main(String[] args) {
		System.out.println("Testing priority queue");
		PriorityQueueImpl pq = new PriorityQueueImpl();

		pq.insert(1);
		pq.insert(2);
		pq.insert(5);
		pq.insert(4);
		pq.insert(3);
		pq.remove();
		pq.remove();
		pq.remove();
		pq.remove();
		pq.remove();
		pq.remove();
	}

}

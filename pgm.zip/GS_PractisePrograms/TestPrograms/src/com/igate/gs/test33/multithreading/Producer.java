/**
 * 
 */
package com.igate.gs.test33.multithreading;

import java.util.Vector;

/**
 * @author br815792
 * 
 */
public class Producer implements Runnable {

	Boolean isProducing;
	private final Vector sharedQueue;
	private int size;

	public Producer(Vector sharedQueue, int size) {
		super();
		this.sharedQueue = sharedQueue;
		this.size = size;
		isProducing = true;
	}

	public void run() {
		for (int i = 0; i <= size; i++) {
			System.out.println("Producer is producing:" + i);
			sharedQueue.add(i);
			try {
 				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

		isProducing = false;
 	}
}

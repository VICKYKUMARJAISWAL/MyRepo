package com.igate.gs.test33.multithreading;

import java.util.Vector;

public class ProducerConsumerWithoutWaitNotify {

	public static void main(String[] args) {
		System.out
				.println("Testing producer consumer prob without using Wait and Notify");

		Vector sharedQueue = new Vector(); // ArrayList can be used
											// alternatively
		int size = 5;

		Producer prod = new Producer(sharedQueue, size);
		Consumer con = new Consumer(sharedQueue, size, prod);

		Thread prodThread = new Thread(prod,"prodThread");
		Thread consThread = new Thread(con,"consThread");

		prodThread.start();
		consThread.start();
	}

}

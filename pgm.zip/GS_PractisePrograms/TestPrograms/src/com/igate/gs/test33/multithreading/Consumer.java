package com.igate.gs.test33.multithreading;

import java.util.Vector;

public class Consumer implements Runnable {

	private final Vector sharedQueue;
	private final int size;
	Producer prod;

	public Consumer(Vector sharedQueue, int size, Producer prod) {
		super();
		this.sharedQueue = sharedQueue;
		this.size = size;
		this.prod = prod;
	}

	public void run() {
		if (this.prod.isProducing == true) {
			System.out
					.println("Producer is still producing: Consumer is waiting");
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			for (int j = 0; j <= size; j++) {
				System.out.println("Consumer is consuming:"
						+ (Integer) sharedQueue.remove(0));
			}

		}
	}

}

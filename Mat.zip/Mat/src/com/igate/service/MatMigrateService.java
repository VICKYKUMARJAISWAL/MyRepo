package com.igate.service;

import java.util.List;

import com.igate.dao.MigratorDao;
import com.igate.modal.MatMigrator;
import com.igate.modal.MigratorRules;

public class MatMigrateService {

	private MigratorDao migratorDao;

	public void setMigratorDao(MigratorDao migratorDao) {
		this.migratorDao = migratorDao;
	}
	

	/**
	 * To get RuleIds from the database and returning the list of ruleid to controller
	 * @param sourceLanguage
	 * @return
	 */
	public List<MigratorRules> getRulesFromDataBase(String sourceLanguage) {

		
		List<MigratorRules> matTol = migratorDao
				.getRulesFromDataBase(sourceLanguage);
		
			return matTol;

	}



	public void saveFile(String originalFilename, String pathSorce1,
			String subjectSelected) {
		// TODO Auto-generated method stub
		
	}

}

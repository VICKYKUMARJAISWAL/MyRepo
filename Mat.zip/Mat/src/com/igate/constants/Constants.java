package com.igate.constants;

public class Constants {
	public static final String insertFirstRule = "RULE51";
	public static final String commentSecondRule = "RULE52";
	public static final String replaceThirdRule = "RULE53";
}

package com.igate.handler;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.igate.mapper.DBScanMapper;
import com.igate.mapper.MatMapper;
import com.igate.modal.CCARuleDescDTO;
import com.igate.modal.ComplexityAnalyzer;
import com.igate.modal.UserDetails;

public class DBScanHandler {
	
	@Autowired DBScanMapper matMapper;
	
	

	public Model getDetails(Model model,HttpSession sessionObj,MultipartFile file,String Language,String destLanguage,String name) {
		// TODO Auto-generated method stub
		return matMapper.getDetails(model, sessionObj, file, Language, destLanguage, name);
	}
	
	

}

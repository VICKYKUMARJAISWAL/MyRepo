package com.igate.handler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.igate.mapper.MigratorMapper;
import com.igate.modal.AddingRules;
import com.igate.modal.ComplexityAnalyzer;
import com.igate.modal.Language_Platform;
import com.igate.modal.MatMigrator;
import com.igate.modal.MigratorRules;

public class MigratorHandler {

	private static int countLines = 0;
	private static int impactLinenum =0;
	private static String suggestion="";
	private static String comment="";
	private static String endComment ="";
	private static String temp="" ;
	private static String auditString="";
	private static boolean skip=true;
	private static String lineSeperator=System.getProperty("line.separator");
	//                 String eol = System.getProperty("line.separator");
    //static String lineSeperator = System.lineSeparator();
	
	@Autowired
	MigratorMapper migratorMapper;

	public MatMigrator getLanguage() {
		return migratorMapper.getLanguage();
	}
	//static boolean relase=false;
	
	public static boolean recurringComments(String outPut){
	if(outPut.contains("/*")){
			skip=false;
			return skip;
		}
		if(skip==false){
			if(outPut.contains("*/")){
				skip=true;
			} 
		}
		return skip;
	}
	/**
	 * To replace and insert the group by if contains order by
	 * 
	 * @param outPut
	 * @return
	 */
	public static String processRules(String outPut, List<MigratorRules> list) {

		
		
		if(recurringComments(outPut)){
		if(!outPut.contains("--") && !outPut.contains("*/")){
		countLines++;
			
		for (MigratorRules mr : list) {
			
			String source = mr.getSOURCE_STRING();
			System.out.println(source);
			String destination = mr.getDESTINATION_STRING();
			String flag = mr.getFLAG();
			comment=mr.getSTART_COMMENT();
			endComment = mr.getEND_COMMENT();		
			 
			
			
			boolean found = false;
			
			if (outPut != null) {					
				//StringTokenizer outputTokens = new StringTokenizer(outPut, " ");	
				outPut=outPut.replaceAll("\\s+", " ");
//				outPut = outPut.toLowerCase();
				outPut = outPut.toUpperCase();
				Pattern pattern = Pattern.compile("(\\s|^)"+source+"(\\s|$)", Pattern.CASE_INSENSITIVE);
				Matcher m=pattern.matcher(outPut);
				found=m.find();
				//found = outPut.contains(source);

			}

			if (found) {
				impactLinenum++;
				
				if(flag.equals("S"))
					
				{
					 
					suggestion=suggestion+lineSeperator+"For "+source+ " at Line number "+countLines+" "+destination+lineSeperator;
					
				}
				else if(flag.equals("R")){					
		
				temp = comment+outPut+endComment;	
				auditString=auditString+source+ " Occured at Line number "+countLines+" "+lineSeperator;
				outPut = outPut.replaceAll("(\\s|^)"+source+"(\\s|$)", " "+destination+" ");			 						
				} else if(flag.equals("U")){
					auditString=auditString+source+ " Occured at Line number "+countLines+" "+lineSeperator;					
					outPut=addingOrderBy(outPut, mr);
				}
			}

		}
	}
	}
		return outPut;
	}
	/**
	 * venkatesh adding the Group by to Group by order by <name> group by<name>
	 * @param outPut
	 * @return
	 */
	public static String addingOrderBy(String outPut,MigratorRules mr) {

		
		comment=mr.getSTART_COMMENT();
		endComment=mr.getEND_COMMENT();
		boolean orderby = false;
		String putData = "";
		int count = 0;
		if (outPut != null) {
			StringBuffer strbuff = new StringBuffer();
			StringTokenizer strtk = new StringTokenizer(outPut.trim(), " ");
			orderby = outPut.contains(mr.getDESTINATION_STRING());
			if (orderby == false) {
				
				temp = comment+outPut+endComment;
				while (strtk.hasMoreElements()) {
					String getValueByspace = (String) strtk.nextElement();
					strbuff.append(getValueByspace + " ");
					if (getValueByspace.equalsIgnoreCase("group")) {
						count++;
					}
					if (getValueByspace.equalsIgnoreCase("by")) {
						count++;
					}
					if (count == 2) {
						String temp = (String) strtk.nextElement();
						strbuff.append(temp +" "+ mr.getDESTINATION_STRING() +" "+ temp);
					}
				}
			} else if (orderby) {
				strbuff.append(outPut);
			} 
			putData = strbuff.toString();
		}
		return putData;
	}

	
	
	 /** rule one to convert file from sybase 12.5 to sybase 15.x
	 * 
	 * @param source
	 * @param dest
	 * @param temp
	 * @return
	 * @throws IOException
	 */
	public static File applyRule(File source, File dest, File auditFile,List<MigratorRules> list)
			throws IOException {

		String verify, putData,codeline;
		FileReader fr = null;
		BufferedReader br = null;
		FileWriter fw,fi= null;
		BufferedWriter bw = null;
		BufferedWriter bwImpact = null;
		fr = new FileReader(source);
		
		br = new BufferedReader(fr);
		fw = new FileWriter(dest);
		fi = new FileWriter(auditFile);
		bw = new BufferedWriter(fw);
		bwImpact=new BufferedWriter(fi);
		 
		while ((verify = br.readLine()) != null) {
			putData = processRules(verify, list);
			if (temp !=null && temp !=""){
			bw.write(temp);		
			bw.newLine();
			}
			bw.write(putData.toLowerCase());
			bw.newLine();
			temp =null;
		}
		
		codeline="Number of code line affected due to conversion " +impactLinenum;
				
		auditString="Audit Log"+lineSeperator+"---------"+lineSeperator+auditString;
		bwImpact.write(auditString);	
		bwImpact.newLine();
		if (suggestion!="" && suggestion!=null){
		suggestion="Suggestions"+lineSeperator+"-----------"+lineSeperator+suggestion+lineSeperator;
		bwImpact.write(suggestion);
		}
		bwImpact.newLine();
		bwImpact.write(codeline.toUpperCase());
		//bwImpact.write(codeline.toLowerCase());
		
		suggestion = "";
		auditString="";
		comment="";
		endComment="";
		countLines=0;
		impactLinenum=0;	
		skip=true;
		
		bw.flush();
		bwImpact.flush();
		fr.close();
		br.close();
		bw.close();
		bwImpact.close();
		fw.close();
		fi.close();
		
		return dest;

	}

	/**
	 * rule two to convert file from sybase 12.5 to sybase 15.x
	 * 
	 * @param source
	 * @param dest
	 * @param temp
	 * @return
	 * @throws IOException
	 */
	/*
	 * public static String ruleTwo(File source, File dest, File temp) throws
	 * IOException {
	 * 
	 * System.out.println("in method" + dest+" "+source.length()); String
	 * verify, putData; FileReader fr = null; BufferedReader br = null;
	 * FileWriter fw = null; BufferedWriter bw = null; fr = new
	 * FileReader(dest); br = new BufferedReader(fr); FileWriter fwTemp = new
	 * FileWriter(temp); BufferedWriter bwTemp = new BufferedWriter(fwTemp);
	 * System.out.println("bbb" + dest.length());
	 * System.out.println(temp.length()); System.out.println(source.length());
	 * 
	 * while ((verify = br.readLine()) != null) { String i =
	 * verify.replace("cursor", "insensitive cursor"); bwTemp.write(i);
	 * bwTemp.newLine(); } fr.close(); br.close(); bwTemp.flush(); fr = null; br
	 * = null; fr = new FileReader(temp); br = new BufferedReader(fr); fw = new
	 * FileWriter(dest, false); bw = new BufferedWriter(fw);
	 * 
	 * while ((verify = br.readLine()) != null) { bw.write(verify);
	 * bw.newLine(); } fr.close(); br.close(); bw.flush(); bw.close();
	 * fw.close();
	 * 
	 * return null;
	 * 
	 * }
	 */

	public List<String> getUploadedLanguages() {
		// TODO Auto-generated method stub
		return migratorMapper.getUploadedLanguages();
	}

	public void saveFile(String originalFilename, String pathSorce1,
			String description,String subjectSelected) {
		// TODO Auto-generated method stub
		migratorMapper.saveFile(originalFilename, pathSorce1,
				description,subjectSelected);
	}

	public List<Map<String,Object>> getDescriptions(String sub) {
		// TODO Auto-generated method stub
		return migratorMapper.getDescriptions(sub);
	}

	public void deleteFile(String filename) {
		// TODO Auto-generated method stub
		migratorMapper.deleteFile(filename);
	}

	public List<String> getfileNames(String subjectSelected) {
		// TODO Auto-generated method stub
		System.out.println("inside handler "+migratorMapper.getfileNames(subjectSelected));
		return migratorMapper.getfileNames(subjectSelected);
	}

	public int insertRules(AddingRules add) {
		// TODO Auto-generated method stub
		return migratorMapper.insertRules(add);
	}
	public List<Language_Platform> getAllValues() {
		// TODO Auto-generated method stub
		return migratorMapper.getAllvalues();
	}

	public List<String> getSourceStrings() {
		// TODO Auto-generated method stub
		return migratorMapper.getSourceStrings();
	}

	public int deleteRules(String sselected) {
		// TODO Auto-generated method stub
		return migratorMapper.deleteRules(sselected);
	}

}

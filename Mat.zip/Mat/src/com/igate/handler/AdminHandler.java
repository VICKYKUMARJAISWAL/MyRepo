package com.igate.handler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.igate.mapper.AdminMapper;
import com.igate.modal.AddingCCARules;
import com.igate.modal.AddingRules;
import com.igate.modal.DBScan;
import com.igate.modal.Language_Platform;
import com.igate.modal.MigratorRules;
import com.igate.modal.UserDetails;


public class AdminHandler {

	@Autowired
	AdminMapper amapper;
	public List<Language_Platform> getAllValues() {
		// TODO Auto-generated method stub
		return amapper.getAllValues();
	}
	public int insertCCA(AddingCCARules addCCA) {
		// TODO Auto-generated method stub
		return amapper.insertCCA(addCCA);
	}
	public List<AddingCCARules> getKeyWords() {
		// TODO Auto-generated method stub
		return amapper.getKeyWords();
	}
	public int deleteCCA(String keyword) {
		// TODO Auto-generated method stub
		return amapper.deleteCCA(keyword);
	}
	public AddingRules getDetails(String sString) {
		// TODO Auto-generated method stub
		return amapper.getDetails(sString);
	}
	public int doUpdate(AddingRules add) {
		// TODO Auto-generated method stub
		return amapper.doUpdate(add);
	}
	public AddingCCARules getKeywordDetails(String kWord) {
		// TODO Auto-generated method stub
		return amapper.getKeywordDetails(kWord);
	}
	public int doUpdateCCA(AddingCCARules addCCA) {
		// TODO Auto-generated method stub
		return amapper.doUpdateCCA(addCCA);
	}
	public List<String> getKeyWord() {
		// TODO Auto-generated method stub
		return amapper.getKeyWord();
	}
	public List<MigratorRules> getRulesFromDataBase() {
		// TODO Auto-generated method stub
		return amapper.getRulesFromDataBase();
	}
	public List<UserDetails> getUsers() {
		// TODO Auto-generated method stub
		return amapper.getUsers();
	}
	public int insertUser(UserDetails user1) {
		// TODO Auto-generated method stub
		return amapper.insertUser(user1);
	}
	public int deleteUser(String uSelected) {
		// TODO Auto-generated method stub
		return amapper.deleteUser(uSelected);
	}
	public int updateUser(UserDetails userB, String uname) {
		// TODO Auto-generated method stub
		return amapper.updateUser(userB,uname);
	}
	/**
	 * @return
	 */
	public List<DBScan> getCodeScanRules() {
		// TODO Auto-generated method stub
		return amapper.getCodeScanRules();
	}
	/**
	 * @param dScan
	 * @return
	 */
	public int insertCodeRules(DBScan dScan) {
		// TODO Auto-generated method stub
		return amapper.insertCodeRules(dScan);
	}
	/**
	 * @param kword
	 * @return
	 */
	public int deleteCode(String kword) {
		// TODO Auto-generated method stub
		return amapper.deleteCode(kword);
	}
	/**
	 * @param userB
	 * @param kName
	 * @return
	 */
	public int updateCodeUser(DBScan userB, String kName) {
		// TODO Auto-generated method stub
		return amapper. updateCodeUser(userB,kName);
	}

}

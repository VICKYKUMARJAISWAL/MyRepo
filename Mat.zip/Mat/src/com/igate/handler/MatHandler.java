package com.igate.handler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.igate.mapper.MatMapper;
import com.igate.modal.CCARuleDescDTO;
import com.igate.modal.ComplexityAnalyzer;
import com.igate.modal.MatDBRange;
import com.igate.modal.Remote;
import com.igate.modal.RuleDescDTO;
import com.igate.modal.UserDetails;

public class MatHandler {
	
	@Autowired MatMapper matMapper;
	
	
	public boolean login(UserDetails userDetails){
		
		return matMapper.login(userDetails);
		
	}
	
	public List<RuleDescDTO> getRulesDescription(String lang){		
		return matMapper.getRulesDescription(lang);
	}
	
	public ComplexityAnalyzer  getLanguage() {
		return matMapper.getLanguage();
	}
	
	public List<MatDBRange>  getComplexity() {
		return matMapper.getComplexity();
	}

	

	public String getRole(UserDetails userDetails) {
		// TODO Auto-generated method stub
		return matMapper.getRole(userDetails);
	}
	
	public List<String> getDBData(Remote remote) {
		// TODO Auto-generated method stub
		return matMapper.getDBData(remote);
	}

}

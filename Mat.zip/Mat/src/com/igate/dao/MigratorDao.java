package com.igate.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.igate.modal.AddingRules;
import com.igate.modal.Language_Platform;
import com.igate.modal.MigratorRules;


public class MigratorDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	private static Set<String> setLanguages = new HashSet<String>();

	public static Set<String> getSetLanguages() {
		return setLanguages;
	}

	public static void setSetLanguages(Set<String> setLanguages) {
		MigratorDao.setLanguages = setLanguages;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<String> getLanguage() {

		return jdbcTemplate
				.query("select TYPE,SOURCE_LANGUAGE,DESTN_LANGUAGE from matdb_lookup where SCREEN=? ",
						new Object[] { "CM" }, new RowMapper<String>() {

							public String mapRow(ResultSet rs, int rownumber)
									throws SQLException {

								if (rs.getString(1)
										.equalsIgnoreCase("language")) {

									setLanguages.add(rs.getString(3));
									// setLanguages.add(rs.getString(2));
									// return
									// rs.getString(2)+" "+rs.getString(3);
									return rs.getString(2);

								} /*
								 * else {
								 * setSourcePlatform.add(rs.getString(2));
								 * 
								 * }
								 */
								return null;

							}
						});

	}

	/**
	 * To get RuleIds from the database and returning the list of ruleid to controller
	 * @param sourceLanguage
	 * @return
	 */

public List<MigratorRules> getRulesFromDataBase(String sourceLanguage) {
		
		
		return jdbcTemplate.query("select SOURCE_STRING,DESTINATION_STRING,FLAG,START_COMMENT,END_COMMENT from MIGRATOR_RULES where DESTINATION_LANGUAGE = ?",new Object[]{sourceLanguage},new RowMapper<MigratorRules>(){
		
			public MigratorRules mapRow(ResultSet rs, int rownumber) throws SQLException {
				//System.out.println("Inside-1 "+rs.getString(1)+rs.getString(2)+rs.getString(3));
			
			MigratorRules mr = new MigratorRules();
			mr.setSOURCE_STRING(rs.getString(1));
			mr.setDESTINATION_STRING(rs.getString(2));
			mr.setFLAG(rs.getString(3));
			mr.setSTART_COMMENT(rs.getString(4));
			mr.setEND_COMMENT(rs.getString(5));
			
			return mr;
				
				
		}});
		


	}
	public void save(String originalFilename, String filename,
			String description,String language) {
		/*for(String g:filename)
			System.out.println(g);
String sql1="insert into mat_db_knoweldge_files values (?,?,?)";
		jdbcTemplate
				.update(sql1,filename[0],filename[1],filename[2]);
						*/


		System.out.println(originalFilename);
		// TODO Auto-generated method stub
		
		String query = "insert into MAT_DB_KNOWELDGE_FILES (FILENAME, PATH, DESCRIPTION,language) values (?,?,?,?)";
        Object[] args = new Object[] { filename,originalFilename,description,language};
         
        int out = jdbcTemplate.update(query, args);
         
        if(out !=0){
            System.out.println(" saved with id="+originalFilename);
        }else System.out.println("not save failed with id="+originalFilename);
				
	}
	
	
	
	public String getDescription(String originalFilename) {

		return jdbcTemplate
				.query("select DESCRIPTION from MAT_DB_KNOWELDGE_FILES where FILENAME=? ",
						new Object[] {originalFilename }, new RowMapper<String>() {

							public String mapRow(ResultSet rs, int rownumber)
									throws SQLException {
								System.out.println(""+ rs.getString(1));
									// rs.getString(2)+" "+rs.getString(3);
									return rs.getString(1);

							}
						}).get(0);


	}

	
	public List<String> getUploadedLanguages() {
		System.out.println(" inside");
		List<String> languagesReturned = new ArrayList<String>();
		List<Map<String, Object>> lang = jdbcTemplate
				.queryForList("select language from MAT_DB_LANGUAGE");
		System.out.println(lang);
		for (Map<String, Object> row : lang) {
			languagesReturned.add((String) row.get("language"));
		}
		
		return languagesReturned;
	}

	public List<Map<String, Object>> getDescriptions(String sub) {
		// TODO Auto-generated method stub
		 Object[] args = new Object[] {sub};
		List<Map<String, Object>> lang = jdbcTemplate
				.queryForList("select filename,description from MAT_DB_KNOWELDGE_FILES where language=?",args);
		System.out.println(lang);
		return lang;
	}

	public void deleteFile(String filename) {
		// TODO Auto-generated method stub
		System.out.println("deleting"+" "+filename);
		String sql="delete from MAT_DB_KNOWELDGE_FILES where filename=?";
		int out1 = jdbcTemplate.update(sql,filename);
		System.out.println("deleted");
	}

	public List<String> getfileNames(String subjectSelected) {
		// TODO Auto-generated method stub
		String sql="select filename from MAT_DB_KNOWELDGE_FILES where language=?";
		Object[] args = new Object[] {subjectSelected};
		List<String> fileNames = new ArrayList<String>();
		List<Map<String, Object>> lang = jdbcTemplate
				.queryForList(sql,args);
		System.out.println("inside filenames "+lang);
		for (Map<String, Object> row : lang) {
			fileNames.add((String) row.get("filename"));
			System.out.println(row.get("filename"));
		}
		System.out.println("fileNames::"+fileNames);
		return fileNames;
	}
	
	public int insertRules(AddingRules add) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO MIGRATOR_RULES  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Object[] params = new Object[] { add.getSource_language(),
				add.getEnd_comment(), add.getDestination_language(),
				add.getSource_platform(), add.getDestination_platform(),
				add.getSource_string(), add.getDestination_string(),
				add.getFlag(), add.getStart_comment() };
		for(Object o:params)
			System.out.println(o);
		return jdbcTemplate.update(query, params);
	}
	

	/*public List<String> getSourceLanguages() {
		// TODO Auto-generated method stub
		String queryForSLanguage="select source_language from language_platform";
		
		List<String> sLanguages = new ArrayList<String>();
		List<Map<String, Object>> lang = jdbcTemplate.queryForList(queryForSLanguage);
		System.out.println("inside filenames " + lang);
		for (Map<String, Object> row : lang) {
			sLanguages.add((String) row.get("source_language"));
			//System.out.println(row.get("filename"));
		}
		System.out.println("fileNames::" + sLanguages);
		return sLanguages;
	}

	public List<String> getDestinationLanguages() {
		// TODO Auto-generated method stub
		String queryForDLanguage="select destination_language from language_platform";
		
		List<String> dLanguages = new ArrayList<String>();
		List<Map<String, Object>> lang = jdbcTemplate.queryForList(queryForDLanguage);
		System.out.println("inside filenames " + lang);
		for (Map<String, Object> row : lang) {
			dLanguages.add((String) row.get("destination_language"));
			//System.out.println(row.get("filename"));
		}
		System.out.println("fileNames::" + dLanguages);
		return dLanguages;
	}

	public List<String> getSourcePlatform() {
		// TODO Auto-generated method stub
		String queryForSPlatform="select source_platform from language_platform";
		
		List<String> sPlatform = new ArrayList<String>();
		List<Map<String, Object>> lang = jdbcTemplate.queryForList(queryForSPlatform);
		System.out.println("inside filenames " + lang);
		for (Map<String, Object> row : lang) {
			sPlatform.add((String) row.get("source_platform"));
			//System.out.println(row.get("filename"));
		}
		System.out.println("fileNames::" + sPlatform);
		return sPlatform;
	}

	public List<String> getDestinationPlatform() {
		// TODO Auto-generated method stub
		String queryForDPlatform="select destination_platform from language_platform";
		
		List<String> dPlatform = new ArrayList<String>();
		List<Map<String, Object>> lang = jdbcTemplate.queryForList(queryForDPlatform);
		System.out.println("inside filenames " + lang);
		for (Map<String, Object> row : lang) {
			dPlatform.add((String) row.get("destination_platform"));
			//System.out.println(row.get("filename"));
		}
		System.out.println("fileNames::" + dPlatform);
		return dPlatform;
	}*/

	public List<Language_Platform> getAllvalues() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(
				"select * from Language_Platform",
			 new RowMapper<Language_Platform>() {
					public Language_Platform mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						Language_Platform scan = new Language_Platform();
						scan.setSource_language(rs.getString(1));
						scan.setDestination_language(rs.getString(2));
						System.out.println(scan.getDestination_language());
						scan.setSource_platform(rs.getString(3));
						scan.setDestination_platform(rs.getString(4));
						return scan;
					}
				});
	}

	public List<String> getSourceStrings() {
		// TODO Auto-generated method stub
		return jdbcTemplate
				.query("select source_string from MIGRATOR_RULES",
						new Object[] {}, new RowMapper<String>() {

							public String mapRow(ResultSet rs, int rownumber)
									throws SQLException {
								return rs.getString(1);
							}
						});
	}

	public int deleteRules(String sselected) {
		// TODO Auto-generated method stub
		String queryForDelete="delete from migrator_rules where source_string=?";
		Object[] delete={sselected};
		return jdbcTemplate.update(queryForDelete, delete);
	}
}

package com.igate.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import sun.reflect.ReflectionFactory.GetReflectionFactoryAction;

import com.igate.modal.AddingCCARules;
import com.igate.modal.AddingRules;
import com.igate.modal.DBScan;
import com.igate.modal.Language_Platform;
import com.igate.modal.MigratorRules;
import com.igate.modal.UserDetails;

public class AdminDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Language_Platform> getAllValues() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from Language_Platform",
				new RowMapper<Language_Platform>() {
					public Language_Platform mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						Language_Platform scan = new Language_Platform();
						scan.setSource_language(rs.getString(1));
						scan.setDestination_language(rs.getString(2));
						System.out.println(scan.getDestination_language());
						scan.setSource_platform(rs.getString(3));
						scan.setDestination_platform(rs.getString(4));
						return scan;
					}
				});
	}

	public int insertCCA(AddingCCARules add) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO MATDB_CCA_NEW_RULES  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Object[] params = new Object[] { add.getPlatform(), add.getLanguage(),
				add.getRule_desc(), add.getKeyword(), add.getScan_flag(),
				add.getSimple(), add.getMedium(), add.getComplex(),
				add.getSimple_return_value(), add.getMedium_return_value(),
				add.getComplex_return_value(), add.getRule_id() };
		for (Object o : params)
			System.out.println(o);
		return jdbcTemplate.update(query, params);

	}

	public List<AddingCCARules> getKeyWords() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from MATDB_CCA_NEW_RULES",
				new RowMapper<AddingCCARules>() {
					public AddingCCARules mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						AddingCCARules scan = new AddingCCARules();
						scan.setPlatform(rs.getString("platform"));
						scan.setLanguage(rs.getString("language"));
						scan.setRule_desc(rs.getString("rule_desc"));
						scan.setKeyword(rs.getString("keyword"));
						scan.setScan_flag(rs.getString("scan_flag"));
						scan.setSimple(rs.getInt("simple"));
						scan.setMedium(rs.getInt("medium"));
						scan.setComplex(rs.getInt("complex"));
						scan.setSimple_return_value(rs
								.getInt("simple_return_value"));
						scan.setMedium_return_value(rs
								.getInt("medium_return_value"));
						scan.setComplex_return_value(rs
								.getInt("complex_return_value"));
						scan.setRule_id(rs.getString("rule_id"));
						return scan;
					}
				});
	}

	public int doUpdateCCA(AddingCCARules addCCA) {
		// TODO Auto-generated method stub
		String queryForUpdateCCA = "update MATDB_CCA_NEW_RULES set platform=?, language=?,rule_desc=?,scan_flag=?,"
				+ "simple=?,medium=?,complex=?,simple_return_value=?,medium_return_value=?,complex_return_value=?,"
				+ "rule_id=?  where keyword=?";
		Object[] updateCCA = { addCCA.getPlatform(), addCCA.getLanguage(),
				addCCA.getRule_desc(), addCCA.getScan_flag(),
				addCCA.getSimple(), addCCA.getMedium(), addCCA.getComplex(),
				addCCA.getSimple_return_value(),
				addCCA.getMedium_return_value(),
				addCCA.getComplex_return_value(), addCCA.getRule_id(),
				addCCA.getKeyword() };
		return jdbcTemplate.update(queryForUpdateCCA, updateCCA);
	}

	public int deleteCCA(String keyword) {
		// TODO Auto-generated method stub
		String queryForDeleteCCA = "delete from MATDB_CCA_NEW_RULES where keyword=?";
		Object[] deleteCCA = { keyword };
		return jdbcTemplate.update(queryForDeleteCCA, deleteCCA);
	}

	public AddingRules getDetails(String sString) {
		// TODO Auto-generated method stub
		String queryForUpdate = "select * from migrator_rules where source_string=?";
		AddingRules add = (AddingRules) getJdbcTemplate().queryForObject(
				queryForUpdate, new Object[] { sString },
				new BeanPropertyRowMapper<AddingRules>(AddingRules.class));
		return add;
	}

	public int doUpdate(AddingRules add) {
		// TODO Auto-generated method stub
		String queryForUpdate = "update migrator_rules set source_language=?,end_comment=?,destination_language=?,"
				+ "source_platform=?,destination_platform=?,destination_string=?,flag=?,start_comment=? where source_string=?";
		Object[] update = { add.getSource_language(), add.getEnd_comment(),
				add.getDestination_language(), add.getSource_platform(),
				add.getDestination_platform(), add.getDestination_string(),
				add.getFlag(), add.getStart_comment(), add.getSource_string() };
		return jdbcTemplate.update(queryForUpdate, update);
	}

	public AddingCCARules getKeywordDetails(String kWord) {
		// TODO Auto-generated method stub
		String queryForUpdate = "select * from MATDB_CCA_NEW_RULES where keyword=?";
		AddingCCARules add = (AddingCCARules) getJdbcTemplate()
				.queryForObject(
						queryForUpdate,
						new Object[] { kWord },
						new BeanPropertyRowMapper<AddingCCARules>(
								AddingCCARules.class));
		return add;
	}

	public List<String> getKeyWord() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select keyword from MATDB_CCA_NEW_RULES",
				new Object[] {}, new RowMapper<String>() {

					public String mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						return rs.getString(1);
					}
				});
	}

	public List<MigratorRules> getRulesFromDataBase() {

		return jdbcTemplate.query("select * from MIGRATOR_RULES ",
				new RowMapper<MigratorRules>() {

					public MigratorRules mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						System.out.println("Inside-1 " + rs.getString(1)
								+ rs.getString(2) + rs.getString(3));

						MigratorRules mr = new MigratorRules();
						mr.setSOURCE_LANGUAGE(rs.getString(1));
						mr.setEND_COMMENT(rs.getString(2));
						mr.setDESTINATION_LANGUAGE(rs.getString(3));
						mr.setSOURCE_PLATFORM(rs.getString(4));
						mr.setDESTINATION_PLATFORM(rs.getString(5));
						mr.setSOURCE_STRING(rs.getString(6));
						mr.setDESTINATION_STRING(rs.getString(7));
						mr.setFLAG(rs.getString(8));
						mr.setSTART_COMMENT(rs.getString(9));
						return mr;
					}
				});

	}

	public List<UserDetails> getUsers() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from MATDB_AUTH",
				new RowMapper<UserDetails>() {

					public UserDetails mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						System.out.println("Inside-1 " + rs.getString(1)
								+ rs.getString(2) + rs.getString(3));

						UserDetails user = new UserDetails();
						user.setName(rs.getString(1));
						user.setPassword(rs.getString(2));
						user.setRole(rs.getString(3));
						return user;

					}
				});
	}

	public int insertUser(UserDetails user1) {
		// TODO Auto-generated method stub
		String queryForInsertUser = "INSERT INTO MATDB_AUTH VALUES(?, ?, ?)";
		Object[] user = { user1.getName(), user1.getPassword(), user1.getRole() };
		return jdbcTemplate.update(queryForInsertUser, user);
	}

	public int deleteUser(String uSelected) {
		// TODO Auto-generated method stub

		String sqlForDeleteUser = "delete from matdb_auth where user_name=?";
		Object[] dUser = { uSelected };
		return jdbcTemplate.update(sqlForDeleteUser, dUser);
	}

	public int updateUser(UserDetails userB, String uname) {
		// TODO Auto-generated method stub
		String queryForUpdateUser = "update matdb_auth set user_name=?,mat_pwd=?,user_type=? where user_name=?";
		Object[] updateUser = { userB.getName(), userB.getPassword(),
				userB.getRole(), uname };
		return jdbcTemplate.update(queryForUpdateUser, updateUser);
	}

	public List<DBScan> getCodeScanRules() {
		return jdbcTemplate.query("select * from MATDB_CA_SCAN",
				new RowMapper<DBScan>() {

					public DBScan mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						System.out.println("Inside-1 " + rs.getString(1)
								+ rs.getString(2) + rs.getString(3));

						DBScan db = new DBScan();
						db.setLang(rs.getString(1));
						db.setKeyword(rs.getString(2));
						db.setSubKeyword(rs.getString(3));
						db.setInnerSearch(rs.getString(4));
						db.setStartSeparator(rs.getString(5));
						db.setEndSeparator(rs.getString(6));
						db.setFieldSeparator(rs.getString(7));
						db.setEndResult(rs.getString(8));
						db.setDesc(rs.getString(9));
						return db;

					}
				});
	}

	/**
	 * @param dScan
	 * @return
	 */
	public int insertCodeRules(DBScan dScan) {
		// TODO Auto-generated method stub

		String SqlForCodeScanner = "insert into matdb_ca_scan values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Object[] coderules = { dScan.getLang(), dScan.getKeyword(),
				dScan.getSubKeyword(), dScan.getInnerSearch(),
				dScan.getStartSeparator(), dScan.getEndSeparator(),
				dScan.getFieldSeparator(), dScan.getEndResult(),
				dScan.getDesc() };
		return jdbcTemplate.update(SqlForCodeScanner, coderules);
	}

	/**
	 * @param kword
	 * @return
	 */
	public int deleteCode(String kword) {
		// TODO Auto-generated method stub

		String QueryForDeleteCodeScane = "delete from matdb_ca_scan where keyword=?";
		Object[] deleteCode = { kword };
		return jdbcTemplate.update(QueryForDeleteCodeScane, deleteCode);
	}

	/**
	 * @param userB
	 * @param kName
	 * @return
	 */
	public int updateCodeUser(DBScan userB, String kName) {
		// TODO Auto-generated method stub
		String QueryForUpdateCode = "update matdb_ca_scan set LANGUAGE=?, KEYWORD=?, SUB_KEYWORDS=?, " +
				"INNER_SEARCH_FLAG=?,START_SEPARATOR=?,END_SEPARATOR=?,FIELD_SEPARATOR=?,END_RESULT=?,"
				+ "DESCR=? where KEYWORD=?";
		Object[] CodeUpdate = {

		userB.getLang(), userB.getKeyword(), userB.getSubKeyword(),
				userB.getInnerSearch(), userB.getStartSeparator(),
				userB.getEndSeparator(), userB.getFieldSeparator(),
				userB.getEndResult(), userB.getDesc(), kName };
		return jdbcTemplate.update(QueryForUpdateCode, CodeUpdate);
	}
}

package com.igate.dao;

import java.sql.*;
import java.util.*;

import org.springframework.jdbc.core.*;

import com.igate.modal.*;
import com.sybase.jdbc3.jdbc.SybDriver;

public class MatDao {
	private static Set<String> setPlatform=new HashSet<String>();
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public static Set<String> getSetPlatform() {
		return setPlatform;
	}

	public List<UserDetails> getDetails(String name, String password) {

		return jdbcTemplate.query(
				"select * from matdb_auth where  USER_NAME=? and MAT_PWD=?",
				new Object[] { name, password }, new RowMapper<UserDetails>() {

					public UserDetails mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						UserDetails bean = new UserDetails();
						bean.setName(rs.getString(1));
						bean.setPassword(rs.getString(2));
						return bean;

					}
				});

	}

	public List<String> getLanguage() {

		return jdbcTemplate.query(
				"select TYPE,SOURCE_LANGUAGE from matdb_lookup where SCREEN=? ",
				new Object[] { "CCA" }, new RowMapper<String>() {

					public String mapRow(ResultSet rs, int rownumber)
							throws SQLException {

						if (rs.getString(1).equalsIgnoreCase("language")) {

							return rs.getString(2);

						} else {
							setPlatform.add(rs.getString(2));
						}
						return null;

					}
				});

	}

	
	/**
	 * Method to fetch rules from DB tables - matdb_cca_rules , matdb_rule_lookup in order to set the Weightage values in the UI
	 * @param lang
	 * @return 
	 */
	public List<RuleDescDTO> getRuleDescription(String lang) {
		
		//System.out.println("in dao " + lang);
		return jdbcTemplate.query(
				"SELECT * from MATDB_CCA_NEW_RULES where language=?",
				new Object[] { lang }, new RowMapper<RuleDescDTO>() {
					
					public RuleDescDTO mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						RuleDescDTO ru=new RuleDescDTO();
						ru.setPlatform(rs.getString(1));
						ru.setKeyword(rs.getString(4));
						ru.setSimpleRange(rs.getInt(6));
						ru.setMediumRange(rs.getInt(7));
						ru.setComplexRange(rs.getInt(8));
						ru.setSimpleReturnValue(rs.getInt(9));
						ru.setMediumReturnValue(rs.getInt(10));
						ru.setComplexReturnValue(rs.getInt(11));
						ru.setRuleId(rs.getString(12));
						ru.setRuleDesc(rs.getString(3));
						ru.setScanFlag(rs.getString(5));
						System.out.println(ru+"rules in DAO");
						return ru;
					}
				});
		
	} 
	
	
public List<MatDBRange> getCodeComplexity() {		
		return jdbcTemplate.query(
				"Select complexity,min_limit,max_limit from matdb_range ",new RowMapper<MatDBRange>() 
				{					
					public MatDBRange mapRow(ResultSet rs, int rownumber)
							throws SQLException 
	{	
						MatDBRange mat=new MatDBRange();
						mat.setCOMPLEXITY(rs.getString(1));
						mat.setMIN_LIMIT(rs.getInt(2));
						mat.setMAX_LIMIT(rs.getInt(3));
						
						return mat;						
					}
				});

}



public String getRole(String uName) {
	// TODO Auto-generated method stub
	return jdbcTemplate.query(
			"Select user_type from matdb_auth  where user_name=?",new Object[] { uName}, new RowMapper<String>() {					
				public String mapRow(ResultSet rs, int rownumber)
						throws SQLException {	
					System.out.println(" comp:"+ rs.getString(1));
					return rs.getString(1);						
				}
			}).get(0);
}

	public List<String> getSyBaseDB(Remote remote){
		   List<String> l = new ArrayList<String>();
		   String url = "jdbc:sybase:Tds:10.212.6.12:5000";
		   //servername = BLRWF6681.igate.corp.com portnumber = 5000
		   SybDriver sybDriver = null;
		   Connection conn;
		try 
		   {
		      sybDriver=(SybDriver)Class.forName("com.sybase.jdbc3.jdbc.SybDriver").newInstance();
		      System.out.println("Driver Loaded");
		      conn = DriverManager.getConnection(url,"sa","igate123");// username = sa / password = igate123
		      Statement stmt = conn.createStatement();
		      ResultSet rs = stmt.executeQuery("select name from master..sysdatabase");
		      rs.next();
		      l.add(rs.getString(2));
		      System.out.println(rs.getString(2));
		   }
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return l;
	
	}
	
	public List<String> getOracleDB(Remote remote){
		
		   Connection conn;
		   
		   String servername = remote.getServername();//10.212.6.88
		   String portnumber = remote.getPortnumber();//1521
		   String username = remote.getUsername();
		   String password = remote.getPassword();
		   List<String> database = remote.getDatabase();
		   
		   List<String> l = new ArrayList<String>();
		   
		   String url = "jdbc:oracle:thin:@"+servername+":"+portnumber+":"+"oradb";//jdbc:oracle:thin:@10.212.6.88:1521:oradb
		   
		   String sql = "select * from all".concat("_").concat("objects where object").concat("_").concat("type ").concat("IN('PROCEDURE','PACKAGE') and owner = 'MATDB'");
		   //select * from all_objects where object_type IN( 'PROCEDURE','PACKAGE') and owner = 'MATDB'
		   System.out.println("servername "+servername+" portnumber "+portnumber+" username "+username+" password "+password);
		try 
		   {
		      Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		      System.out.println("Driver Loaded");
		      conn = DriverManager.getConnection(url,username,password);
		      Statement stmt = conn.createStatement();
		      ResultSet rs = stmt.executeQuery(sql);
		      while(rs.next())
		      {
		    	  l.add(rs.getString(2));
		    	  System.out.println(rs.getString(1));
		      }
		   }
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return l;
	}
}

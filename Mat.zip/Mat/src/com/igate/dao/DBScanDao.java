package com.igate.dao;

import java.sql.*;
import java.util.*;

import org.springframework.jdbc.core.*;

import com.igate.modal.*;

public class DBScanDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	

		
		public List<DBScan> getDetails(String Language) {
		return jdbcTemplate.query(
				"select * from MATDB_CA_SCAN where LANGUAGE=? ",
				new Object[] { Language }, new RowMapper<DBScan>() {
					public DBScan mapRow(ResultSet rs, int rownumber)
							throws SQLException {
						DBScan scan = new DBScan();
						scan.setKeyword(rs.getString(2));
						scan.setSubKeyword(rs.getString(3));
						scan.setInnerSearch(rs.getString(4));
						scan.setStartSeparator(rs.getString(5));
						scan.setEndSeparator(rs.getString(6));
						scan.setFieldSeparator(rs.getString(7));
						scan.setEndResult(rs.getString(8));
						scan.setDesc(rs.getString(9));
						return scan;
					}
				});

	}
		
		
		public Boolean isimpacted(String Language, String destLanguage, String keyword) {
			System.out.println("called Language "+Language+" :dest "+destLanguage);
			return !jdbcTemplate.query(
					"select * from MIGRATOR_RULES where SOURCE_LANGUAGE=? and SOURCE_STRING=? and DESTINATION_LANGUAGE=? ",
					new Object[] { Language, keyword,  destLanguage}, new RowMapper<Boolean> () {
						public Boolean mapRow(ResultSet rs, int rownumber)
								throws SQLException {						
							return rs.next();
						}
					}).isEmpty();

		}

		
		public Comments getComments(String Language) {
			return jdbcTemplate.query(
					"select * from MATDB_COMMENTS where LANGUAGE=? ",
					new Object[] { Language }, new RowMapper<Comments>() {
						public Comments mapRow(ResultSet rs, int rownumber)
								throws SQLException {
							Comments scan = new Comments();
							scan.setLanguage(rs.getString(1));
							scan.setSingleLine(rs.getString(2));
							scan.setMultiple(rs.getString(3));
							return scan;
						}
					}).get(0);

		}
			
	
}

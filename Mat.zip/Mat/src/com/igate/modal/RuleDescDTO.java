package com.igate.modal;

public class RuleDescDTO {
	
	 String ruleId;
	 String ruleDesc;
	 String scanFlag;
	 String platform;
	 String language;
	 String keyword;
	 int simpleRange;
	 int mediumRange;
	 int complexRange;
	 int simpleReturnValue;
	 int mediumReturnValue;
	 int complexReturnValue;
	
	 
	
public RuleDescDTO()
{
	
}


public String getRuleId() {
	return ruleId;
}


public void setRuleId(String ruleId) {
	this.ruleId = ruleId;
}


public String getRuleDesc() {
	return ruleDesc;
}


public void setRuleDesc(String ruleDesc) {
	this.ruleDesc = ruleDesc;
}


public String getScanFlag() {
	return scanFlag;
}


public void setScanFlag(String scanFlag) {
	this.scanFlag = scanFlag;
}


public String getPlatform() {
	return platform;
}


public void setPlatform(String platform) {
	this.platform = platform;
}


public String getLanguage() {
	return language;
}


public void setLanguage(String language) {
	this.language = language;
}


public String getKeyword() {
	return keyword;
}


public void setKeyword(String keyword) {
	this.keyword = keyword;
}


public int getSimpleRange() {
	return simpleRange;
}


public void setSimpleRange(int simpleRange) {
	this.simpleRange = simpleRange;
}


public int getMediumRange() {
	return mediumRange;
}


public void setMediumRange(int mediumRange) {
	this.mediumRange = mediumRange;
}


public int getComplexRange() {
	return complexRange;
}


public void setComplexRange(int complexRange) {
	this.complexRange = complexRange;
}


public int getSimpleReturnValue() {
	return simpleReturnValue;
}


public void setSimpleReturnValue(int simpleReturnValue) {
	this.simpleReturnValue = simpleReturnValue;
}


public int getMediumReturnValue() {
	return mediumReturnValue;
}


public void setMediumReturnValue(int mediumReturnValue) {
	this.mediumReturnValue = mediumReturnValue;
}


public int getComplexReturnValue() {
	return complexReturnValue;
}


public void setComplexReturnValue(int complexReturnValue) {
	this.complexReturnValue = complexReturnValue;
}


@Override
public String toString() {
	return "RuleDescDTO [ruleId=" + ruleId + ", ruleDesc=" + ruleDesc
			+ ", scanFlag=" + scanFlag + ", platform=" + platform
			+ ", language=" + language + ", keyword=" + keyword
			+ ", simpleRange=" + simpleRange + ", mediumRange=" + mediumRange
			+ ", complexRange=" + complexRange + ", simpleReturnValue="
			+ simpleReturnValue + ", mediumReturnValue=" + mediumReturnValue
			+ ", complexReturnValue=" + complexReturnValue + "]";
}


	
}

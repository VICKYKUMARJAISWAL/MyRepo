package com.igate.modal;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Remote {
	
	private String servername,portnumber,username,password;
	private List<String> database;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getServername() {
		return servername;
	}

	public void setServername(String servername) {
		this.servername = servername;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPortnumber() {
		return portnumber;
	}

	public void setPortnumber(String portnumber) {
		this.portnumber = portnumber;
	}

	public List<String> getDatabase() {
		return database;
	}

	public void setDatabase(List<String> database) {
		this.database = database;
	}
}

package com.igate.modal;

import org.springframework.stereotype.Component;

@Component
public class DBScan {
	private String desc;
	private String lang;
	private String keyword;
	private String subKeyword;
	private String innerSearch;
	private String startSeparator;
	private String endSeparator;
	private String fieldSeparator;
	private String endResult;
	
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getSubKeyword() {
		return subKeyword;
	}
	public void setSubKeyword(String subKeyword) {
		this.subKeyword = subKeyword;
	}	
	public String getInnerSearch() {
		return innerSearch;
	}
	public void setInnerSearch(String innerSearch) {
		this.innerSearch = innerSearch;
	}
	public String getStartSeparator() {
		return startSeparator;
	}
	public void setStartSeparator(String startSeparator) {
		this.startSeparator = startSeparator;
	}
	public String getEndSeparator() {
		return endSeparator;
	}
	public void setEndSeparator(String endSeparator) {
		this.endSeparator = endSeparator;
	}
	public String getFieldSeparator() {
		return fieldSeparator;
	}
	public void setFieldSeparator(String fieldSeparator) {
		this.fieldSeparator = fieldSeparator;
	}
	public String getEndResult() {
		return endResult;
	}
	public void setEndResult(String endResult) {
		this.endResult = endResult;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
	
}

package com.igate.modal;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class ComplexityAnalyzer {

	private List<String> language;
	private List<String> platform;
	public List<String> getLanguage() {
		return language;
	}
	public void setLanguage(List<String> language) {
		this.language = language;
	}
	public List<String> getPlatform() {
		return platform;
	}
	public void setPlatform(List<String> platform) {
		this.platform = platform;
	}

}

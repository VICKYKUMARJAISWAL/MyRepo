package com.igate.modal;


public class CCARuleDescDTO extends RuleDescDTO {
	
	/*public int weightage;
	public int ruleConstant;
	public String inputReq;
	

	public CCARuleDescDTO(String ruleId, String ruleDesc, int weightage,
			int ruleConstant, String inputReq) {
		super(ruleId, ruleDesc);
		this.weightage = weightage;
		this.ruleConstant = ruleConstant;
		this.inputReq = inputReq;
	}

	public int getWeightage() {
		return weightage;
	}
	
	public void setWeightage(int weightage) {
		this.weightage = weightage;
	}
	
	public int getRuleConstant() {
		return ruleConstant;
	}
	
	public void setRuleConstant(int ruleConstant) {
		this.ruleConstant = ruleConstant;
	}
	
	public String getInputReq() {
		return inputReq;
	}
	
	public void setInputReq(String inputReq) {
		this.inputReq = inputReq;
	}*/

		
}

package com.igate.modal;

public class MigratorRules {
	
	

	
	public String SOURCE_LANGUAGE;
	public String END_COMMENT;
	public String DESTINATION_LANGUAGE;
	public String SOURCE_PLATFORM;
	public String DESTINATION_PLATFORM;
	public String SOURCE_STRING;
	public String DESTINATION_STRING;
	public String FLAG;
	public String START_COMMENT;
	
	
	
	public MigratorRules(String SOURCE_LANGUAGE,String END_COMMENT,String DESTINATION_LANGUAGE,String SOURCE_PLATFORM,String DESTINATION_PLATFORM,String SOURCE_STRING,String DESTINATION_STRING,String FLAG,String START_COMMENT ){
		this.SOURCE_LANGUAGE = SOURCE_LANGUAGE;
		this.END_COMMENT = END_COMMENT;
		this.DESTINATION_LANGUAGE =DESTINATION_LANGUAGE;
		this.SOURCE_PLATFORM =SOURCE_PLATFORM;
		this.DESTINATION_PLATFORM=DESTINATION_PLATFORM;
		this.SOURCE_STRING=SOURCE_STRING;
		this.DESTINATION_STRING=DESTINATION_STRING;
		this.FLAG=FLAG;
		this.START_COMMENT=START_COMMENT;
	}
	public MigratorRules() {
		// TODO Auto-generated constructor stub
	}
	public String getSOURCE_LANGUAGE() {
		return SOURCE_LANGUAGE;
	}
	public void setSOURCE_LANGUAGE(String sOURCE_LANGUAGE) {
		SOURCE_LANGUAGE = sOURCE_LANGUAGE;
	}
	public String getEND_COMMENT() {
		return END_COMMENT;
	}
	public void setEND_COMMENT(String eND_COMMENT) {
		END_COMMENT = eND_COMMENT;
	}
	public String getDESTINATION_LANGUAGE() {
		return DESTINATION_LANGUAGE;
	}
	public void setDESTINATION_LANGUAGE(String dESTINATION_LANGUAGE) {
		DESTINATION_LANGUAGE = dESTINATION_LANGUAGE;
	}
	public String getSOURCE_PLATFORM() {
		return SOURCE_PLATFORM;
	}
	public void setSOURCE_PLATFORM(String sOURCE_PLATFORM) {
		SOURCE_PLATFORM = sOURCE_PLATFORM;
	}
	public String getDESTINATION_PLATFORM() {
		return DESTINATION_PLATFORM;
	}
	public void setDESTINATION_PLATFORM(String dESTINATION_PLATFORM) {
		DESTINATION_PLATFORM = dESTINATION_PLATFORM;
	}
	public String getSOURCE_STRING() {
		return SOURCE_STRING;
	}
	public void setSOURCE_STRING(String sOURCE_STRING) {
		SOURCE_STRING = sOURCE_STRING;
	}
	public String getDESTINATION_STRING() {
		return DESTINATION_STRING;
	}
	public void setDESTINATION_STRING(String dESTINATION_STRING) {
		DESTINATION_STRING = dESTINATION_STRING;
	}
	public String getFLAG() {
		return FLAG;
	}
	public void setFLAG(String fLAG) {
		FLAG = fLAG;
	}
	public String getSTART_COMMENT() {
		return START_COMMENT;
	}
	public void setSTART_COMMENT(String sTART_COMMENT) {
		START_COMMENT = sTART_COMMENT;
	}
	@Override
	public String toString() {
		return "MigratorRules [SOURCE_STRING=" + SOURCE_STRING
				+ ", DESTINATION_STRING=" + DESTINATION_STRING + ", FLAG="
				+ FLAG + "]";
	}
	
	
	 
	
	

}

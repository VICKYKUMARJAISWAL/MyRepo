package com.igate.modal;

public class DBText {

	private String text;

	public DBText(String text) {
		// TODO Auto-generated constructor stub
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}

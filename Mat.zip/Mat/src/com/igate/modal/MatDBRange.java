package com.igate.modal;

public class MatDBRange {
	public int MIN_LIMIT;
	public int MAX_LIMIT;
	public String COMPLEXITY;
	
	public MatDBRange()
	{
		
	}
	public MatDBRange(int MIN_LIMIT,int MAX_LIMIT,String COMPLEXITY){
		this.MIN_LIMIT= MIN_LIMIT;
		this.MAX_LIMIT = MAX_LIMIT;
		this.COMPLEXITY= COMPLEXITY;
	}
	
	public long getMIN_LIMIT() {
		return MIN_LIMIT;
	}
	public void setMIN_LIMIT(int mIN_LIMIT) {
		MIN_LIMIT = mIN_LIMIT;
	}
	public long getMAX_LIMIT() {
		return MAX_LIMIT;
	}
	public void setMAX_LIMIT(int mAX_LIMIT) {
		MAX_LIMIT = mAX_LIMIT;
	}
	public String getCOMPLEXITY() {
		return COMPLEXITY;
	}
	public void setCOMPLEXITY(String cOMPLEXITY) {
		COMPLEXITY = cOMPLEXITY;
	}
	
	
	
	
}

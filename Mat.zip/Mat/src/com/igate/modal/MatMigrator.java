package com.igate.modal;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class MatMigrator {
	@Override
	public String toString() {
		return "MatMigrator [sourceLanguage=" + sourceLanguage
				+ ", sourcePlatform=" + sourcePlatform
				+ ", destinationLanguage=" + destinationLanguage
				+ ", destinationPlatform=" + destinationPlatform + ", rules=" + rules +"]";
	}

	private List<String> sourceLanguage;
	private List<String> sourcePlatform;
	private List<String> destinationLanguage;
	private List<String> destinationPlatform;
	private RuleDescDTO rules;
	
	

	public RuleDescDTO getRules() {
		return rules;
	}

	public void setRules(RuleDescDTO rules) {
		this.rules = rules;
	}

	public MatMigrator() {
		// TODO Auto-generated constructor stub
	}

	public List<String> getSourceLanguage() {
		return sourceLanguage;
	}

	public void setSourceLanguage(List<String> sourceLanguage) {
		this.sourceLanguage = sourceLanguage;
	}

	public List<String> getSourcePlatform() {
		return sourcePlatform;
	}

	public void setSourcePlatform(List<String> sourcePlatform) {
		this.sourcePlatform = sourcePlatform;
	}

	public List<String> getDestinationLanguage() {
		return destinationLanguage;
	}

	public void setDestinationLanguage(List<String> destinationLanguage) {
		this.destinationLanguage = destinationLanguage;
	}

	public List<String> getDestinationPlatform() {
		return destinationPlatform;
	}

	public void setDestinationPlatform(List<String> destinationPlatform) {
		this.destinationPlatform = destinationPlatform;
	}

}

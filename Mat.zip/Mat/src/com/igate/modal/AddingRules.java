package com.igate.modal;

import org.springframework.stereotype.Component;

@Component
public class AddingRules {

	private String source_language,end_comment,destination_language,source_platform,
	destination_platform,source_string,destination_string,flag,start_comment;

	public String getSource_language() {
		return source_language;
	}

	public void setSource_language(String source_language) {
		this.source_language = source_language;
	}

	public String getEnd_comment() {
		return end_comment;
	}

	public void setEnd_comment(String end_comment) {
		this.end_comment = end_comment;
	}

	public String getDestination_language() {
		return destination_language;
	}

	public void setDestination_language(String destination_language) {
		this.destination_language = destination_language;
	}

	public String getSource_platform() {
		return source_platform;
	}

	public void setSource_platform(String source_platform) {
		this.source_platform = source_platform;
	}

	public String getDestination_platform() {
		return destination_platform;
	}

	public void setDestination_platform(String destination_platform) {
		this.destination_platform = destination_platform;
	}

	public String getSource_string() {
		return source_string;
	}

	public void setSource_string(String source_string) {
		this.source_string = source_string;
	}

	public String getDestination_string() {
		return destination_string;
	}

	public void setDestination_string(String destination_string) {
		this.destination_string = destination_string;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getStart_comment() {
		return start_comment;
	}

	public void setStart_comment(String start_comment) {
		this.start_comment = start_comment;
	}
	
}

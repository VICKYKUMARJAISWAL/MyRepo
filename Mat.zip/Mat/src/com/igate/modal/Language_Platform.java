package com.igate.modal;

import org.springframework.stereotype.Component;

@Component
public class Language_Platform {

	private String source_language,destination_language,source_platform,destination_platform;

	public String getSource_language() {
		return source_language;
	}

	public void setSource_language(String source_language) {
		this.source_language = source_language;
	}

	public String getDestination_language() {
		return destination_language;
	}

	public void setDestination_language(String destination_language) {
		this.destination_language = destination_language;
	}

	public String getSource_platform() {
		return source_platform;
	}

	public void setSource_platform(String source_platform) {
		this.source_platform = source_platform;
	}

	public String getDestination_platform() {
		return destination_platform;
	}

	public void setDestination_platform(String destination_platform) {
		this.destination_platform = destination_platform;
	}
	
}

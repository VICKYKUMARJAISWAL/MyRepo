package com.igate.modal;

import org.springframework.stereotype.Component;

@Component
public class AddingCCARules {

	private String platform,language,rule_desc,keyword,scan_flag,rule_id;
	private int simple,medium,complex,simple_return_value,medium_return_value,complex_return_value;
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getRule_desc() {
		return rule_desc;
	}
	public void setRule_desc(String rule_desc) {
		this.rule_desc = rule_desc;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getScan_flag() {
		return scan_flag;
	}
	public void setScan_flag(String scan_flag) {
		this.scan_flag = scan_flag;
	}
	public String getRule_id() {
		return rule_id;
	}
	public void setRule_id(String rule_id) {
		this.rule_id = rule_id;
	}
	public int getSimple() {
		return simple;
	}
	public void setSimple(int simple) {
		this.simple = simple;
	}
	public int getMedium() {
		return medium;
	}
	public void setMedium(int medium) {
		this.medium = medium;
	}
	public int getComplex() {
		return complex;
	}
	public void setComplex(int complex) {
		this.complex = complex;
	}
	public int getSimple_return_value() {
		return simple_return_value;
	}
	public void setSimple_return_value(int simple_return_value) {
		this.simple_return_value = simple_return_value;
	}
	public int getMedium_return_value() {
		return medium_return_value;
	}
	public void setMedium_return_value(int medium_return_value) {
		this.medium_return_value = medium_return_value;
	}
	public int getComplex_return_value() {
		return complex_return_value;
	}
	public void setComplex_return_value(int complex_return_value) {
		this.complex_return_value = complex_return_value;
	}
	
}

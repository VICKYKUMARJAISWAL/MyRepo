package com.igate.modal;

public class Comments {
	String language;
	String singleLine;
	String multiple;
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getSingleLine() {
		return singleLine;
	}
	public void setSingleLine(String singleLine) {
		this.singleLine = singleLine;
	}
	public String getMultiple() {
		return multiple;
	}
	public void setMultiple(String multiple) {
		this.multiple = multiple;
	}
	
}

package com.igate.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.igate.dao.MatDao;
import com.igate.handler.MatHandler;
import com.igate.handler.MigratorHandler;
import com.igate.modal.MatDBRange;
import com.igate.modal.Remote;
import com.igate.modal.RuleDescDTO;
import com.igate.modal.UserDetails;
import com.igate.util.Util;

@Controller
@RequestMapping(value = "Home")
public class MatController {

	@Autowired
	UserDetails userDetails;
	@Autowired
	MatHandler matHandler;
	@Autowired
	MigratorHandler migratorHandler;

	/*@Autowired
	Remote remote;*/

	@Autowired
	MatDao dao;

	@Autowired
	ServletContext context;
	
	
	Util util=new Util();

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String hello(Model model) {
		model.addAttribute("userdetails", userDetails);
		return "login";
	}

	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String login(@ModelAttribute("userDetails") UserDetails userDetails,
			Model model, HttpSession sessionObj) {
		
		if (matHandler.login(userDetails)) {
			String roleUser = matHandler.getRole(userDetails);
			// System.out.println(roleUser);
			model.addAttribute("user", userDetails.getName());
			sessionObj.setAttribute("username", userDetails.getName());
			model.addAttribute("uploadedLanguages",
					migratorHandler.getUploadedLanguages());
			// model.addAttribute("fileName_description",
			// migratorHandler.getDescriptions());
			// sessionObj.setAttribute("fileName_description",
			// migratorHandler.getDescriptions());
			model.addAttribute("complexityAnalyzer", matHandler.getLanguage());
			sessionObj.setAttribute("user",userDetails.getName());
			sessionObj.setAttribute("userName", userDetails.getName());
			sessionObj.setAttribute("userRole", roleUser);
			sessionObj.setAttribute("uploadedLanguages",migratorHandler.getUploadedLanguages());
			return "help";
		} else {
			return "failure";
		}
	
	}
	@RequestMapping("complexityAnalyzer")
	public String goTabAnalyzer(Model model, HttpSession sessionObj) {
		model.addAttribute("complexityAnalyzer", matHandler.getLanguage());
		model.addAttribute("user", sessionObj.getAttribute("userName"));
		model.addAttribute("uploadedLanguages",
				migratorHandler.getUploadedLanguages());

		return "screen2";
	}
	
	@RequestMapping(value = "screen3", method = RequestMethod.POST)
	public String screen3(Model model, HttpSession sessionObj, boolean Lines,
			@RequestParam("language") String language) {
		// sessionObj.setAttribute("UPLOADED_FILE", file);
		// sessionObj.setAttribute("name", name);
		model.addAttribute("user", sessionObj.getAttribute("userName"));
		sessionObj.setAttribute("language", language);
		System.out.println("____" + language);
		model.addAttribute("rules", matHandler.getRulesDescription(language));
		List<RuleDescDTO> ex=matHandler.getRulesDescription(language);
		for(RuleDescDTO r:ex)
			System.out.println("+"+r.getRuleDesc());
		System.out.println(ex+"rules");
		model.addAttribute("rules", matHandler.getRulesDescription(language));
		sessionObj.setAttribute("rules", matHandler.getRulesDescription(language));
		
		model.addAttribute("user", sessionObj.getAttribute("userName"));
		return "screen3";
	}

	@RequestMapping(value = "help")
	public String helpScreen(Model model, HttpSession sessionObj) {
		model.addAttribute("user", sessionObj.getAttribute("userName"));
		return "help";

	}

	@RequestMapping(value = "screen4", method = RequestMethod.POST)
	public String screen4(Model model, HttpSession sessionObj,
			@RequestParam("rulesid") String rulesid,
			@RequestParam("rulesdesc") String rulesdesc,
			@RequestParam("rulesweighttage") String rulesweighttage,
			@RequestParam("scanflag")String scanflag,
			@RequestParam("file") MultipartFile file,
			@RequestParam("name") String name) throws IOException {
		model.addAttribute("user", sessionObj.getAttribute("userName"));
		//String lang = sessionObj.getAttribute("language").toString();
		// MultipartFile file =
		// (MultipartFile)sessionObj.getAttribute("UPLOADED_FILE");
		System.out.println(rulesid + "rulesArrayyyyyyyyyyy ");

		float finalValue = 0;
		int loc = 0;
		CodeComplexityMatrix ccm = new CodeComplexityMatrix();

		int numberOfFunction = 0;
		ArrayList<RuleDescDTO> rules = (ArrayList<RuleDescDTO>) sessionObj
				.getAttribute("rules");
		// System.out.println(" Setence keywords :"+sentence[1]);
		int numberOfKeywords = 0;
		model.addAttribute("keywords", numberOfKeywords);

		//int cyclocomplex = ccm.getCycloComplexity(file, name);

		String[] RulesArray = rulesid.split("_");
		

		
		ArrayList<String> rulesList = new ArrayList<String>();
		String[] weightageArray = rulesweighttage.split("_");
		for (String s : weightageArray) {
			
			System.out.println(s + "weightage array");
		}
		float total = 0;
		
		for (RuleDescDTO rules1 : rules)
		{

			if (rules1.getScanFlag().equalsIgnoreCase("Y"))
			{
				

				numberOfFunction = new Util().getFunctions(file, name,
						rules1.getKeyword());
				rulesList.add("It has " + numberOfFunction + " "
						+ rules1.getRuleDesc());
				//System.out.println(rules1.toString());
				if ((numberOfFunction <= rules1.getSimpleRange()) && (numberOfFunction!=0)) 
				{
					
					total = total + ((rules1.getSimpleReturnValue())* ((Float.parseFloat(weightageArray[Integer.parseInt(rules1.getRuleId())-1])) / 100));
					System.out.println(total+ "in 1st "+rules1.getRuleDesc());

				} 
				else if ((numberOfFunction > rules1.getSimpleRange())&& (numberOfFunction <= rules1.getMediumRange()))
				{
					System.out.println(total+ "in 2nd "+rules1.getRuleDesc());
					total = total + (((rules1.getMediumReturnValue())* ((Float.parseFloat(weightageArray[Integer.parseInt(rules1.getRuleId())-1]))) / 100));
					System.out.println(total+ "in 2nd "+rules1.getRuleDesc());
				} else if ((numberOfFunction > rules1.getMediumRange()) && (numberOfFunction <= rules1.getComplexRange())) 
				{
					total = total + ((rules1.getComplexReturnValue())* ((Float.parseFloat(weightageArray[Integer.parseInt(rules1.getRuleId())-1]))/ 100));
					System.out.println(total+ "in 3rd "+ rules1.getRuleDesc());
				} else if(numberOfFunction>rules1.getComplexRange())
					total = total
							+ (10 * ((Float.parseFloat(weightageArray[Integer.parseInt(rules1.getRuleId())-1]) / 100)));

				
			}
			else
			{
				loc = ccm.getLOC(file, name);
               if (loc <= rules1.getSimpleRange()) {
					
					total = total + rules1.getSimpleReturnValue()
							* ((Float.parseFloat(weightageArray[Integer.parseInt(rules1.getRuleId())-1]) / 100));
					System.out.println(total+ "in 1st"+rules1.getRuleDesc());

				} else if (loc > rules1.getSimpleRange()
						&& loc <= rules1.getMediumRange()) {
					total = total + rules1.getMediumReturnValue()
							* ((Float.parseFloat(weightageArray[Integer.parseInt(rules1.getRuleId())-1]) / 100));
					System.out.println(total+ "in 2nd"+rules1.getRuleDesc());
				} else if (loc > rules1.getMediumRange()
						&& loc <= rules1.getComplexRange()) {
					total = total + rules1.getComplexReturnValue()
							* ((Float.parseFloat(weightageArray[Integer.parseInt(rules1.getRuleId())-1]) / 100));
					System.out.println(total+ "in 3rd"+rules1.getRuleDesc());
				} else
					total = total
							+ (10 * ((Float.parseFloat(weightageArray[Integer.parseInt(rules1.getRuleId())-1]) / 100)));
				rulesList.add("It has " + loc + " lines ");
			}
			
		
		}

		System.out.println();
		// String[] weightageArray = rulesweighttage.split("_");
		model.addAttribute("loc", loc);
		model.addAttribute("functions", numberOfFunction);
		//model.addAttribute("cyclo", cyclocomplex);
		model.addAttribute("rulesList", rulesList);
		String compString="";
		List<MatDBRange> complexityRange=dao.getCodeComplexity();
		for(MatDBRange range:complexityRange)
		{
			if(total>range.MIN_LIMIT && finalValue<=range.MAX_LIMIT)
				compString=range.getCOMPLEXITY();
		}			
		sessionObj.setAttribute("compString", compString);
		System.out.println("total copmpelx" +total);
		/*
		 * int finalValue =ccm.CalculateCodeComplexity(file,name, rulesid,
		 * rulesweighttage,lang); model.addAttribute("result",
		 * matHandler.getComplexity(finalValue));
		 */
		return "screen4";
		
	}

	@RequestMapping(value = "logout")
	public String Logout(HttpSession sessionObj, HttpServletResponse response,
			Model model, @ModelAttribute("userdetails") UserDetails user) {
		sessionObj.invalidate();
		File file2 = new File(context.getRealPath("/")
				+ context.getInitParameter("ReportPathDestUpload") + "/"
				+ "file2.txt");

		file2.delete();

		File audit = new File(context.getRealPath("/")
				+ context.getInitParameter("ReportPathDest") + "/"
				+ "Audit.txt");
		audit.delete();

		return "logout";

	}
	
}

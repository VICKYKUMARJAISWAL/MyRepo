package com.igate.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.igate.handler.AdminHandler;
import com.igate.handler.MigratorHandler;
import com.igate.modal.AddingCCARules;
import com.igate.modal.AddingRules;
import com.igate.modal.DBScan;
import com.igate.modal.UserDetails;

@Controller
@RequestMapping(value = "admin")
public class AdminController {

	@Autowired
	ServletContext context;
	@Autowired
	AddingCCARules addccarules;
	@Autowired
	AdminHandler ahandler;
	@Autowired
	AddingRules addRules;
	@Autowired
	MigratorHandler migratorHandler;
	@Autowired
	UserDetails userA;
	@Autowired
	DBScan dbscan;

	@RequestMapping(value = "addCCARules")
	public String addCCARules(HttpSession hs, Model m) {
		m.addAttribute("addcca", addccarules);
		hs.removeAttribute("messagesuccess");
		List<AddingCCARules> lcca = ahandler.getKeyWords();
		System.out.println(lcca.size());
		List<String> lcca1 = ahandler.getKeyWord();
		System.out.println(lcca1);
		hs.setAttribute("allValuesCCA", ahandler.getAllValues());
		return "addCCARules";

	}

	@RequestMapping(value = "insertCCARules")
	public String insertCCARules(
			@ModelAttribute("addcca") AddingCCARules addCCA, HttpSession hs) {
		hs.setAttribute("user", hs.getAttribute("userName"));
		List<String> lcc = ahandler.getKeyWord();
		System.out.println(lcc);
		for (String acc : lcc) {
			System.out.println("inside insertCCARules " + acc);
			if (acc != null)
				if (acc.equalsIgnoreCase(addCCA.getKeyword())) {

					hs.setAttribute("messagesuccess",
							"keyword is  already present.please enter another keyword");
					return "addCCARules";
				}
		}
		int result = ahandler.insertCCA(addCCA);
		if (result == 1) {
			hs.setAttribute("messagesuccess", "CCA Rules Added Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess", "CCA Rules Not Added Sucessfully");
			return "addCCARules";
		}
	}

	@RequestMapping(value = "deleteCCARules")
	public String deleteCCARules(HttpSession hs) {
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("keywordList", ahandler.getKeyWords());
		return "deleteCCARules";
	}

	@RequestMapping(value = "removeCCARules")
	public String removeCCARules(
			@RequestParam("keywordSelected") String keyword, HttpSession hs) {
		int result = ahandler.deleteCCA(keyword);
		hs.setAttribute("user", hs.getAttribute("userName"));
		if (result == 1) {
			hs.setAttribute("messagesuccess", "CCA Rules Deleted Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess",
					"CCA Rules Not Deleted Sucessfully");
			return "deleteCCARules";
		}
	}

	@RequestMapping(value = "updateRules")
	public String updateRules(HttpSession hs, Model m) {
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("sourceString", migratorHandler.getSourceStrings());
		return "updateRules";

	}

	@RequestMapping(value = "doUpdate")
	public String doUpdate(HttpSession hs,
			@RequestParam("sourceStringSelected") String sString, Model m) {
		hs.setAttribute("resultBean", ahandler.getDetails(sString));
		hs.setAttribute("allValues", migratorHandler.getAllValues());
		hs.removeAttribute("messagesuccess");
		m.addAttribute("addRules", addRules);
		return "updateRulesPage";
	}

	@RequestMapping(value = "doUpdateMigratorRules")
	public String doUpdateMigrator(@ModelAttribute("addRules") AddingRules add,
			HttpSession hs, @RequestParam("sStrings") String sstring) {
		add.setSource_string(sstring);
		hs.setAttribute("user", hs.getAttribute("userName"));
		System.out.println(add.getSource_string());
		int uCount = ahandler.doUpdate(add);
		if (uCount == 1) {
			hs.setAttribute("messagesuccess",
					"Migrator Rules Updated Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess",
					"Migrator Rules Not Updated Sucessfully");
			return "updateRules";
		}

	}

	@RequestMapping(value = "updateCCARules")
	public String updateCCARules(HttpSession hs, Model m) {
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("keywordList", ahandler.getKeyWords());
		return "updateCCARules";

	}

	@RequestMapping(value = "doUpdateCCA")
	public String doUpdateCCA(HttpSession hs,
			@RequestParam("keywordSelected") String kWord, Model m) {
		hs.setAttribute("resultBeanCCA", ahandler.getKeywordDetails(kWord));
		hs.setAttribute("allValuesCCA", ahandler.getAllValues());
		hs.removeAttribute("messagesuccess");
		m.addAttribute("addCCARules", addccarules);
		return "updateCCARulesPage";
	}

	@RequestMapping(value = "doUpdateCCARules")
	public String doUpdateCCARules(
			@ModelAttribute("addCCARules") AddingCCARules addCCA,
			HttpSession hs, @RequestParam("keyword") String kwrd) {
		addCCA.setKeyword(kwrd);
		int uCount = ahandler.doUpdateCCA(addCCA);
		if (uCount == 1) {
			hs.setAttribute("messagesuccess", "CCA Rules Updated Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess",
					"CCA Rules Not Updated Sucessfully");
			return "updateCCARules";
		}

	}

	@RequestMapping(value = "listMigrator")
	public String listMigrator(HttpSession hs) {
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("migratorAllRules", ahandler.getRulesFromDataBase());
		return "listMigrator";
	}

	@RequestMapping(value = "listCCA")
	public String listCCA(HttpSession hs) {
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("ccaAllRules", ahandler.getKeyWords());
		return "listCCA";
	}

	@RequestMapping(value = "deleteMigratorRules")
	public String deleteRules(
			@RequestParam("sourceStringSelected") String sselected,
			HttpSession hs) {
		int result = migratorHandler.deleteRules(sselected);
		hs.setAttribute("sourceString", migratorHandler.getSourceStrings());
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("migratorAllRules", ahandler.getRulesFromDataBase());
		if (result == 1) {
			hs.setAttribute("messagesuccess",
					"Migrator Rules Deleted Sucessfully");
			return "listMigrator";
		} else {
			hs.setAttribute("messagesuccess",
					"Migrator Rules Not Deleted Sucessfully");
			return "listMigrator";
		}
	}

	@RequestMapping(value = "removeCCARules1")
	public String removeCCARules1(
			@RequestParam("keywordSelected") String keyword, HttpSession hs) {
		int result = ahandler.deleteCCA(keyword);
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("ccaAllRules", ahandler.getKeyWords());
		if (result == 1) {
			hs.setAttribute("messagesuccess", "CCA Rules Deleted Sucessfully");
			return "listCCA";
		} else {
			hs.setAttribute("messagesuccess",
					"CCA Rules Not Deleted Sucessfully");
			return "listCCA";
		}
	}

	@RequestMapping(value = "addUser")
	public String addUser(Model m, HttpSession hs) {
		m.addAttribute("userA", userA);
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		return "addUser";
	}

	@RequestMapping(value = "insertUser")
	public String insertUser(@ModelAttribute("userA") UserDetails user1,
			HttpSession hs) {
		List<UserDetails> uDetails = ahandler.getUsers();
		//System.out.println("adding user " + uname);
		//int count = 0;
		for (UserDetails uD : uDetails) {
				if (uD.getName().equalsIgnoreCase(user1.getName())) {	
					hs.setAttribute("messagesuccess",
							"Username is  already present.Please enter another Username");
					return "addUser";
				}	
		}
		hs.setAttribute("user", hs.getAttribute("userName"));
		int result = ahandler.insertUser(user1);
		if (result == 1) {
			hs.setAttribute("messagesuccess", "USER Added Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess", "USER Not Added Sucessfully");
			return "addUser";
		}

	}
	@RequestMapping(value="insertUser1")
	public String insertUser1(@ModelAttribute("userA") UserDetails user1,@RequestParam("uname1")
	String uname,
			HttpSession hs)
	{
		List<UserDetails> uDetails = ahandler.getUsers();
		System.out.println("adding user " + uname);
		int count = 0;
		for (UserDetails uD : uDetails) {
			
				if (uD.getName().equalsIgnoreCase(uname)) {
					
					hs.setAttribute("messagesuccess",
							"Username is  already present.Please enter another Username");
					return "addUser";
				}
				else
					count++;
			
		}
		if(count==uDetails.size())
		{
			hs.setAttribute("messagesuccess",
					"Username is  available");
			hs.setAttribute("selectedName", user1.getName());
			return "addUser";
		}
		else
		{
			hs.setAttribute("messagesuccess",
					"Username is Not available. PLease Select Another Username");
			hs.setAttribute("selectedName", user1.getName());
			return "addUser";
		}
		
	}
	
	@RequestMapping(value="deleteUser")
	public String deleteUser(HttpSession hs)
	{
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("totalusers", ahandler.getUsers());
		return "deleteUser";
	}
	
	@RequestMapping(value="doDeleteUser")
	public String deleteUSER(@RequestParam("userSelected")String uSelected,HttpSession hs)
	{
		int count=ahandler.deleteUser(uSelected);
		if (count == 1) {
			hs.setAttribute("messagesuccess", "USER Deleted Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess", "USER Not Deleted Sucessfully");
			return "deleteUser";
		}
	}
	
	@RequestMapping(value="doDeleteUser1")
	public String deleteUSER1(@RequestParam("userSelected")String uSelected,HttpSession hs)
	{
		int count=ahandler.deleteUser(uSelected);
		hs.setAttribute("totalusers", ahandler.getUsers());
		if (count == 1) {
			hs.setAttribute("messagesuccess", "USER Deleted Sucessfully");
			return "listUsers";
		} else {
			hs.setAttribute("messagesuccess", "USER Not Deleted Sucessfully");
			return "deleteUser";
		}
	}
	@RequestMapping(value="listUsers")
	public String listUsers(HttpSession hs)
	{
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("totalusers", ahandler.getUsers());
		return "listUsers";
	}
	
	@RequestMapping("updateUser")
	public String updateUser(HttpSession hs)
	{
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("username", hs.getAttribute("username"));
		hs.setAttribute("totalusers", ahandler.getUsers());
		return "updateUser";
	}
	
	@RequestMapping(value="doUpdateUser")
	public String doUpdateUser(@RequestParam("userSelected")String user,HttpSession hs,Model m)
	{
		List<UserDetails> udd=(List<UserDetails>) hs.getAttribute("totalusers");
		List<UserDetails> uda = new ArrayList<UserDetails>();
		for(UserDetails a:udd)
		{
			if(!a.getName().equalsIgnoreCase(user))
				uda.add(a);
		}
		hs.setAttribute("resultES", uda);
		UserDetails userResult=new UserDetails();
		m.addAttribute("userA", userA);
		for(UserDetails u:udd)
		{
		
				if(u.getName().equalsIgnoreCase(user))
				{
					userResult.setName(u.getName());
					userResult.setPassword(u.getPassword());
					userResult.setRole(u.getRole());
				}
		}
		hs.setAttribute("userSelected", userResult);
		return "updateUsersPage";
	}
	
	@RequestMapping(value="doUpdateUserRules")
	public String doUpdate(@ModelAttribute("userA")UserDetails userB,@RequestParam("uName1")String uname,
			@RequestParam("upwd")String pwd,HttpSession hs)
	{
		userB.setPassword(pwd);
		List<UserDetails> udd=(List<UserDetails>) hs.getAttribute("resultES");
		for(UserDetails u:udd)
		{
		if(u.getName().equalsIgnoreCase(userB.getName()))
		{
			hs.setAttribute("userSelected", hs.getAttribute("userSelected"));
			hs.setAttribute("messagesuccess",
					"You entered "+userB.getName()+" A User is  already present with This Username.Please Enter Another Username");
			return "updateUsersPage";
		}
		}
		int count=ahandler.updateUser(userB,uname);
		if (count == 1) {
			hs.setAttribute("messagesuccess", "USER Updated Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess",
					"USER Not Updated Sucessfully");
			return "updateUser";
		}
		
	}
	
	@RequestMapping(value="addCodeRules")
	public String addCodeRules(HttpSession hs,Model m)
	{
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("username", hs.getAttribute("username"));
		hs.setAttribute("allValuesCode", ahandler.getAllValues());
		m.addAttribute("dbscan", dbscan);
		return "addCodeRules";
	}
	
	@RequestMapping(value="insertCodeScanRules")
	public String insertCodeScanRules(@ModelAttribute("dbscan")DBScan dScan,HttpSession hs)
	{
		List<DBScan> DBSCANVALUES=ahandler.getCodeScanRules();
		for(DBScan ds:DBSCANVALUES)
		{
			if(dScan.getKeyword().equalsIgnoreCase(ds.getKeyword()))
			{
				hs.setAttribute("messagesuccess",
						"Keyword Is Already Present.Please Enter Another Keyword");
				hs.setAttribute("allValuesCode", ahandler.getAllValues());
				return "addCodeRules";
			}
		}
		
		int resultScan=ahandler.insertCodeRules(dScan);
		if (resultScan == 1) {
			hs.setAttribute("messagesuccess", "Code Scanenr Rules Added Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess", "Code Scanenr Rules Not Added Sucessfully");
			return "addCodeRules";
		}
	}
	
	@RequestMapping(value="deleteCodeRules")
	public String DeleteCodeRules(HttpSession hs)
	{
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("allValuesCACode", ahandler.getCodeScanRules());
		return "deleteCode";
	}
	
	@RequestMapping(value="deleteCodeScannerRules")
	public String deleteCodeScannerRules(@RequestParam("keywordSelected")String kword,HttpSession hs)
	{
		if(ahandler.deleteCode(kword)==1)
		{
			hs.setAttribute("messagesuccess",
					"Code Scanner Rule Deletd Successfully!!!!");
			hs.setAttribute("allValuesCACode", hs.getAttribute("allValuesCACode"));
			return "sucess";
		}
		else
		{
			hs.setAttribute("messagesuccess",
					"Code Scanner Rule Not Deletd Successfully!!!!");
			hs.setAttribute("allValuesCACode", hs.getAttribute("allValuesCACode"));
			return "deleteCode";
		}
	}
	
	@RequestMapping("UpdateCodeRules")
	public String updateCodeRules(HttpSession hs)
	{
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("username", hs.getAttribute("username"));
		hs.setAttribute("allValuesCACode", ahandler.getCodeScanRules());
		return "updateCodeRules";
	}
	
	@RequestMapping(value="doupdateCodeRules")
	public String updateCodeRules(@RequestParam("keywordSelected")String user,HttpSession hs,Model m)
	{
		List<DBScan> udd=(List<DBScan>) hs.getAttribute("allValuesCACode");
		List<DBScan> uda = new ArrayList<DBScan>();
		for(DBScan a:udd)
		{
			if(!a.getKeyword().equalsIgnoreCase(user))
				uda.add(a);
		}
		hs.setAttribute("exceptSelected", uda);
		hs.setAttribute("resultES", uda);
		DBScan userResult=new DBScan();
		m.addAttribute("userD", dbscan);
		for(DBScan u:udd)
		{
				if(u.getKeyword().equalsIgnoreCase(user))
				{
					userResult.setLang(u.getLang());
					userResult.setKeyword(u.getKeyword());
					userResult.setSubKeyword(u.getSubKeyword());
					userResult.setInnerSearch(u.getInnerSearch());
					userResult.setStartSeparator(u.getStartSeparator());
					userResult.setEndSeparator(u.getEndSeparator());
					userResult.setFieldSeparator(u.getFieldSeparator());
					userResult.setEndResult(u.getEndResult());
					userResult.setDesc(u.getDesc());
				}
		}
		hs.setAttribute("userSelected1", userResult);
		return "updateCodeUsersPage";
	}
	
	@RequestMapping(value="doUpdateCoderRules1")
	public String doUpdateCoderRules1(@ModelAttribute("userD")DBScan userB,@RequestParam("kSelected")String kName,
			HttpSession hs)
	{
		userB.setKeyword(kName);
		System.out.println("in admin code scanner updation "+kName);
		//List<DBScan> udd=(List<DBScan>) hs.getAttribute("allValuesCACode");
		List<DBScan> uds=(List<DBScan>) hs.getAttribute("exceptSelected");
		for(DBScan u:uds)
		{
		if(u.getKeyword().equalsIgnoreCase(userB.getKeyword()))
		{
			hs.setAttribute("userSelected", hs.getAttribute("userSelected"));
			hs.setAttribute("messagesuccess",
					"You entered "+userB.getKeyword()+" Keyword is Already Present.Please Enter Another Keyword");
			return "updateCodeUsersPage";
		}
		}
		int count=ahandler.updateCodeUser(userB,kName);
		if (count == 1) {
			hs.setAttribute("messagesuccess", "Code Scanner Rule Updated Sucessfully");
			return "sucess";
		} else {
			hs.setAttribute("messagesuccess",
					"Code Scanner Rule Not Updated Sucessfully");
			hs.setAttribute("allValuesCACode", ahandler.getCodeScanRules());
			return "updateCodeRules";
		}
		
	}
	
	@RequestMapping(value="listCode")
	public String listCode(HttpSession hs,Model m)
	{
		hs.removeAttribute("messagesuccess");
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.setAttribute("username", hs.getAttribute("username"));
		hs.setAttribute("allValuesCACode", ahandler.getCodeScanRules());
		return "listCode";
	}
	
	@RequestMapping(value="deleteCodeScannerRules1")
	public String deleteCodeScannerRules1(@RequestParam("keywordSelected")String kword,HttpSession hs)
	{
		if(ahandler.deleteCode(kword)==1)
		{
			hs.setAttribute("messagesuccess",
					"Code Scanner Rule Deletd Successfully!!!!");
			hs.setAttribute("allValuesCACode", hs.getAttribute("allValuesCACode"));
			return "listCode";
		}
		else
		{
			hs.setAttribute("messagesuccess",
					"Code Scanner Rule Not Deletd Successfully!!!!");
			hs.setAttribute("allValuesCACode", hs.getAttribute("allValuesCACode"));
			return "deleteCode";
		}
	}
}

/*package com.igate.controller;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.igate.dao.MatDao;
import com.igate.handler.MatHandler;
import com.igate.modal.MatDBRange;

public class CodeComplexityMatrix {
	
	@Autowired MatHandler matHandler;
	
	
	
	public int getLOC(MultipartFile file,String name) throws IOException{
		int i=0;
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream =
             new BufferedOutputStream(new FileOutputStream(new File(name)));
		stream.write(bytes);
		
		//BufferedOutputStream stream2 = new BufferedOutputStream(new FileOutputStream)
		
		stream.close();
		if (!file.isEmpty()) {
			BufferedReader br = null;
			
				String t;
				br = new BufferedReader(new FileReader(name));
				
				boolean isEOF=false;
				do{
					t=br.readLine();
					if(t!=null){
					isEOF=true;
					t=t.replaceAll("\\n|\\t|\\s", "");
					if((!t.equals("")) && (!t.startsWith("//"))) {
					i = i + 1;}}
					else {
						isEOF=false;
						}
						}while(isEOF);
						br.close();
						System.out.println("lines of code"+ i );
					}
		return i;
	}
	
	private static int getFunctionsJava(MultipartFile file,String name) throws IOException { 
		int j =0;
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream =
	         new BufferedOutputStream(new FileOutputStream(new File(name)));
		stream.write(bytes);
		
		stream.close();
		if (!file.isEmpty()) {
			BufferedReader br = null;
			
				String t;
				br = new BufferedReader(new FileReader(name));
				
				boolean isEOF=false;
		do{
			t=br.readLine();
			if(t!=null){
			isEOF=true;
			t=t.replaceAll("\\n|\\t|\\s", "");
			String s=t.toString();
		if((s.contains("){"))|(s.contains(")throws"))|(s.contains(") {"))){
		j = j + 1;
		}
		}
		else {
		isEOF=false;
		}
		}while(isEOF);
		br.close();
		}
		return j;
		}
	
	public int	getFunctions(MultipartFile file,String name)throws IOException{
		int i =0;
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream =
	         new BufferedOutputStream(new FileOutputStream(new File(name)));
		stream.write(bytes);
		
		stream.close();
		if (!file.isEmpty()) {
			BufferedReader br = null;
			
				String t;
				br = new BufferedReader(new FileReader(name));
				
				boolean isEOF=false;
				do{
					t=br.readLine();
					if(t!=null){
					isEOF=true;
					t=t.replaceAll("\\n|\\t|\\s", "");
					String s=t.toString();
					if((s.contains("FUNCTION")||s.contains("PROCEDURE"))){
					i = i + 1;}}
					else {
						isEOF=false;
						}
						}while(isEOF);
						br.close();
					
					}
		return i;
		}
	
	public static void patternmatch(String pattern,String line,List<Integer> myList) {
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(line);
		if (m.find( )) {
			
			if(m.group().equals("END IF")){
				myList.add(4);
			}
			else if(m.group().equals("IF")){
				myList.add(1);
			}
			else if(m.group().equals("ELSIF")){
				
				myList.add(2);
			}
			else if(m.group().equals("ELSE")){
				myList.add(3);
			}
			else if(m.group().equals("WHEN")){
				myList.add(5);
			}
			
		}
		//System.out.println("List="+myList);
		}
	
	public int getCycloComplexity(MultipartFile file,String name)throws IOException{
		try 
		{
			List<Integer> myList = new ArrayList<Integer>();
			int complex=1;
			String sCurrLine,pattern;
			//String message;
			BufferedReader br = new BufferedReader(new FileReader(name));
			while((sCurrLine = br.readLine()) != null){
				//System.out.println(sCurrLine);
				pattern="IF|ELSE|ELSIF|END\\s?IF|WHEN";
				patternmatch(pattern,sCurrLine.toUpperCase(),myList);
				
			}
			
			for (int i = 0; i < myList.size(); i++) {
				if(myList.get(i)==4){
					if(myList.get(i-1)==1){
						continue;
					}
					else {
						complex++;
					}
				
				}
				if(myList.get(i)==2){
					complex++;
				}
				if(myList.get(i)==5){
						complex++;
				}
				if(myList.get(i)==3 && myList.get(i-1)==5){
					complex++;
				}
			}
			
			br.close();
			return complex; 
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return 1;
	}
	
	public int	getKeywords(MultipartFile file,String name,String keyword)throws IOException{
		String[] keys= getString(keyword);
		int i =0;
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream =
	         new BufferedOutputStream(new FileOutputStream(new File(name)));
		stream.write(bytes);
		
		stream.close();
		if (!file.isEmpty()) {
			BufferedReader br = null;
			
				String t;
				br = new BufferedReader(new FileReader(name));
				
				boolean isEOF=false;
				do{
					t=br.readLine();
					if(t!=null){
					isEOF=true;
					t=t.replaceAll("\\n|\\t|\\s", "");
					String s=t.toString();
					
					for(int j=0;j<keys.length;j++){
						keys[j]=keys[j].replaceAll("\\n|\\t|\\s", "");
					if((s.contains(keys[j]))){
					i = i + 1;}
					}}
					else {
						isEOF=false;
						}
						}while(isEOF);
						br.close();
					}
		return i;
		}
	
	public String[] getString(String key){
		
		return key.split(",");
		
	}
	
	public int CalculateCodeComplexity(MultipartFile file,String name,String rulesid,String rulesweighttage,String lang) throws IOException{
		
		int rule1Cal=0;
		int rule2Cal=0;
		int rule3Cal=0;
		int finalValue=0;
		String [] RulesArrayString = rulesid.split("_");
		String[] weightageArray = rulesweighttage.split("_");
		HashSet<String> RulesArray = new HashSet<String>(Arrays.asList(RulesArrayString));
for(int i=0;i<RulesArrayString.length;i++)
{
	if (RulesArray.contains("RULE1")) {
		int loc = getLOC(file, name);
		rule1Cal= (loc * Integer.parseInt(weightageArray[i]));
		
		
	}
	if (RulesArray.contains("RULE2")) {
		int numberOfFunction = getFunctions(file, name);
		rule2Cal= (numberOfFunction * Integer.parseInt(weightageArray[i]));
	}
	
	if(RulesArray.contains("RULE3")){
		int numberOfFunction = getFunctionsJava(file, name);
		rule2Cal= (numberOfFunction * Integer.parseInt(weightageArray[i]));
	}
System.out.println(RulesArrayString[i]+" weigh:"+weightageArray[i]);
}
	
		
		
		
		
		else if(RulesArray.contains("RULE2") && lang.equalsIgnoreCase("Java")) {
			int numberOfFunction = getFunctionsJava(file, name);
			rule2Cal= (numberOfFunction * Integer.parseInt(weightageArray[1]));
			
			
		}
		
		
			
		
		
		
		
		finalValue = rule1Cal+rule2Cal+rule3Cal;
		
		return finalValue;
		
		
	}
	
	
}
*/



package com.igate.controller;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.igate.dao.MatDao;
import com.igate.handler.MatHandler;
import com.igate.modal.MatDBRange;

public class CodeComplexityMatrix {
	
	@Autowired MatHandler matHandler;
	
	
	
	public int getLOC(MultipartFile file,String name) throws IOException{
		int i=0;
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream =
             new BufferedOutputStream(new FileOutputStream(new File(name)));
		stream.write(bytes);
		
		//BufferedOutputStream stream2 = new BufferedOutputStream(new FileOutputStream)
		
		stream.close();
		if (!file.isEmpty()) {
			BufferedReader br = null;
			
				String t;
				br = new BufferedReader(new FileReader(name));
				
				boolean isEOF=false;
				do{
					t=br.readLine();
					if(t!=null){
					isEOF=true;
					t=t.replaceAll("\\n|\\t|\\s", "");
					if((!t.equals("")) && (!t.startsWith("//")) && (!t.startsWith("--")) && (!t.startsWith("/*"))) {
					i = i + 1;}}
					else {
						isEOF=false;
						}
						}while(isEOF);
						br.close();
						
					}
		return i;
	}
	
	private static int getFunctionsJava(MultipartFile file,String name) throws IOException { 
		int j =0;
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream =
	         new BufferedOutputStream(new FileOutputStream(new File(name)));
		stream.write(bytes);
		
		stream.close();
		if (!file.isEmpty()) {
			BufferedReader br = null;
			
				String t;
				br = new BufferedReader(new FileReader(name));
				
				boolean isEOF=false;
		do{
			t=br.readLine();
			if(t!=null){
			isEOF=true;
			t=t.replaceAll("\\n|\\t|\\s", "");
			String s=t.toString();
		if((s.contains("){"))|(s.contains(")throws"))|(s.contains(") {"))){
		j = j + 1;
		}
		}
		else {
		isEOF=false;
		}
		}while(isEOF);
		br.close();
		}
		return j;
		}
	
	public int	getFunctions(MultipartFile file,String name)throws IOException{
		int i =0;
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream =
	         new BufferedOutputStream(new FileOutputStream(new File(name)));
		stream.write(bytes);
		
		stream.close();
		if (!file.isEmpty()) {
			BufferedReader br = null;
			
				String t;
				br = new BufferedReader(new FileReader(name));
				
				boolean isEOF=false;
				do{
					t=br.readLine();
					if(t!=null){
					isEOF=true;
					t=t.replaceAll("\\n|\\t|\\s", "");
					String s=t.toString();
					if((s.contains("FUNCTION")||s.contains("PROCEDURE"))){
					i = i + 1;}}
					else {
						isEOF=false;
						}
						}while(isEOF);
						br.close();
					
					}
		return i;
		}
	
	public static void patternmatch(String pattern,String line,List<Integer> myList) {
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(line);
		if (m.find( )) {
			
			if(m.group().equals("END IF")){
				myList.add(4);
			}
			else if(m.group().equals("IF")){
				myList.add(1);
			}
			else if(m.group().equals("ELSIF")){
				
				myList.add(2);
			}
			else if(m.group().equals("ELSE")){
				myList.add(3);
			}
			else if(m.group().equals("WHEN")){
				myList.add(5);
			}
			
		}
		//System.out.println("List="+myList);
		}
	
	public int getCycloComplexity(MultipartFile file,String name)throws IOException{
		try 
		{
			List<Integer> myList = new ArrayList<Integer>();
			int complex=1;
			String sCurrLine,pattern;
			//String message;
			BufferedReader br = new BufferedReader(new FileReader(name));
			while((sCurrLine = br.readLine()) != null){
				//System.out.println(sCurrLine);
				pattern="IF|ELSE|ELSIF|END\\s?IF|WHEN";
				patternmatch(pattern,sCurrLine.toUpperCase(),myList);
				
			}
			
			for (int i = 0; i < myList.size(); i++) {
				if(myList.get(i)==4){
					if(myList.get(i-1)==1){
						continue;
					}
					else {
						complex++;
					}
				
				}
				if(myList.get(i)==2){
					complex++;
				}
				if(myList.get(i)==5){
						complex++;
				}
				if(myList.get(i)==3 && myList.get(i-1)==5){
					complex++;
				}
			}
			
			br.close();
			return complex; 
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return 1;
	}
	
	public int	getKeywords(MultipartFile file,String name,String keyword)throws IOException{
		String[] keys= getString(keyword);
		int i =0;
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream =
	         new BufferedOutputStream(new FileOutputStream(new File(name)));
		stream.write(bytes);
		
		stream.close();
		if (!file.isEmpty()) {
			BufferedReader br = null;
			
				String t;
				br = new BufferedReader(new FileReader(name));
				
				boolean isEOF=false;
				do{
					t=br.readLine();
					if(t!=null){
					isEOF=true;
					t=t.replaceAll("\\n|\\t|\\s", "");
					String s=t.toString();
					
					for(int j=0;j<keys.length;j++){
						keys[j]=keys[j].replaceAll("\\n|\\t|\\s", "");
					if((s.contains(keys[j]))){
					i = i + 1;}
					}}
					else {
						isEOF=false;
						}
						}while(isEOF);
						br.close();
					}
		return i;
		}
	
	public String[] getString(String key){
		
		return key.split(",");
		
	}
	
	public int CalculateCodeComplexity(MultipartFile file,String name,String rulesid,String rulesweighttage,String lang) throws IOException{
		
		int rule1Cal=0;
		int rule2Cal=0;
		int rule3Cal=0;
		int finalValue=0;
		String [] RulesArrayString = rulesid.split("_");
		String[] weightageArray = rulesweighttage.split("_");
//		HashSet<String> RulesArray = new HashSet<String>(Arrays.asList(RulesArrayString));
		
		
for(int i=0;i<RulesArrayString.length;i++)
{
	if (RulesArrayString[i].equalsIgnoreCase(("RULE1"))) {
		int loc = getLOC(file, name);
		rule1Cal= (loc * Integer.parseInt(weightageArray[i]));
		System.out.println(rule1Cal+ " rule1");
		
	} else if (RulesArrayString[i].equalsIgnoreCase(("RULE2"))) {
		int numberOfFunction = getFunctions(file, name);
		rule2Cal= (numberOfFunction * Integer.parseInt(weightageArray[i]));
		System.out.println(rule2Cal+" rule2");
	} 
	
	/*if(RulesArray.contains("RULE3")){
		//int numberOfFunction = getFunctionsJava(file, name);
		String sentence [] =  rulesinput.split("\\|");	
		int numberOfKeywords= getKeywords(file, name, sentence[1]);
		rule3Cal= (numberOfFunction * Integer.parseInt(weightageArray[i]));
	}*/
System.out.println(RulesArrayString[i]+" weigh:"+weightageArray[i]);
}
	
		
		
		
		
		/*else if(RulesArray.contains("RULE2") && lang.equalsIgnoreCase("Java")) {
			int numberOfFunction = getFunctionsJava(file, name);
			rule2Cal= (numberOfFunction * Integer.parseInt(weightageArray[1]));
			
		}
		*/
		
			
		
		
		
		
		finalValue = rule1Cal+rule2Cal+rule3Cal;
		System.out.println(finalValue + " finallllllllllllllllllllll ");
		
		return finalValue;
		
		
	}
	
	
}

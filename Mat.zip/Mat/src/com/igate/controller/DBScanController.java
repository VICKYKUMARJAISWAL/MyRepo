package com.igate.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.igate.handler.DBScanHandler;
import com.igate.handler.MatHandler;
import com.igate.handler.MigratorHandler;
import com.igate.util.PDFUtil;


@Controller
@RequestMapping(value="DBScan")

public class DBScanController {

	@Autowired MatHandler matHandler;
	@Autowired DBScanHandler dbScanHandler;
	@Autowired MigratorHandler migratorHandler;
	
	@RequestMapping(value="dbScanAnalyzer", method=RequestMethod.GET)
	public String goTabDBScanAnalyzer(Model model, HttpSession sessionObj) {
		model.addAttribute("complexityAnalyzer", matHandler.getLanguage());
		model.addAttribute("user", sessionObj.getAttribute("userName"));
		model.addAttribute("matMigrator", migratorHandler.getLanguage());
		sessionObj.setAttribute("uploadedLanguages",migratorHandler.getUploadedLanguages());
		return "dbScanAnalyser";
	}
	
	@RequestMapping(value="dbScanUpload", method=RequestMethod.POST)
	public String dbScanUpload(Model model,HttpSession sessionObj,@RequestParam("file") MultipartFile file,@RequestParam("name") String name,@RequestParam("language") String language,@RequestParam("destlanguage") String destlanguage) throws IOException{
		model.addAttribute("user",sessionObj.getAttribute("userName"));				
		System.out.println(" file :"+file+" language:"+language+" dest:"+destlanguage);
		model = dbScanHandler.getDetails(model, sessionObj,file,language, destlanguage, name);
		sessionObj.setAttribute("uploadedLanguages",migratorHandler.getUploadedLanguages());
		
		return "dbScanResult";
		
	}
	
	@RequestMapping(value="pdf", method=RequestMethod.GET)
	public String dbScanPDF(Model model,HttpSession sessionObj,HttpServletResponse response) throws IOException{
		
		
		
		String user = sessionObj.getAttribute("userName").toString();				
		Map<String, List<Map<String, String>>> res = (Map<String, List<Map<String, String>>>) sessionObj
				.getAttribute("result");
		Map<String, String> objectCountMap = (Map<String, String>) sessionObj
				.getAttribute("impacted");
		ServletContext servContext = sessionObj.getServletContext();
		String pathSorce = (String) servContext
				.getInitParameter("ReportPathDest");	
		String pdfname = servContext.getRealPath("/") + pathSorce + "/"+user+".pdf";
		PDFUtil.exportToPDF(res,objectCountMap, pdfname);
		
		model.addAttribute("user",sessionObj.getAttribute("userName"));		

		return "pdfReport";
		
	}
	
}

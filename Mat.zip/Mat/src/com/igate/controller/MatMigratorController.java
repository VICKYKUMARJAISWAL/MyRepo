package com.igate.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.igate.handler.MatHandler;
import com.igate.handler.MigratorHandler;
import com.igate.modal.AddingRules;
import com.igate.modal.ComplexityAnalyzer;
import com.igate.modal.MatMigrator;
import com.igate.modal.MigratorRules;
import com.igate.modal.UserDetails;
import com.igate.service.MatMigrateService;

@Controller
@RequestMapping("MigratorHome")
public class MatMigratorController {

	@Autowired
	ServletContext context;

	private MatMigrateService matMigrateService;

	public void setMatMigrateService(MatMigrateService matMigrateService) {
		this.matMigrateService = matMigrateService;
	}

	@Autowired
	MatMigrator matMigrator;
	MatMigrator matMigrator1;
	@Autowired
	UserDetails userDetails;
	@Autowired
	MigratorHandler migratorHandler;

	@Autowired
	ComplexityAnalyzer complexityAnalyzer;

	@Autowired
	MatHandler matHandler;
	
	@Autowired
	AddingRules addrules;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String gomigrator(Model model, HttpSession sessionObj) {
		 
		String name=(String)sessionObj.getAttribute("userName");
		 
		  if (name==null)
		  {

		    return "errorPage";
		  }
		else
		{
		model.addAttribute("matMigrator", migratorHandler.getLanguage());
		model.addAttribute("matMigrator1", matHandler.getLanguage());
		
		
		  complexityAnalyzer.setPlatform(matHandler.getLanguage().getPlatform())
		  ; model.addAttribute("matMigrator1",complexityAnalyzer);
		 

		model.addAttribute("user", sessionObj.getAttribute("userName"));
		
		  model.addAttribute("matMigrator",matMigrator);
		 model.addAttribute("matMigrator1",matMigrator1);
		 
		return "MatMigrator1";
		}
	}

	@RequestMapping(value = "migrator")
	public String goTabMigrator(Model model, HttpSession sessionObj) {
		File file2 = new File(context.getRealPath("/") + context.getInitParameter("ReportPathDest") + "/"
				+ "file2.txt");	
		file2.delete();
		
		File audit = new File(context.getRealPath("/") + context.getInitParameter("ReportPathDest") + "/"
				+ "Audit.txt");	
		audit.delete();
		new File(context.getRealPath("/") + context.getInitParameter("ReportPathDest") + "/"
				+ "inputFile.txt").delete();
		
		model.addAttribute("matMigrator", migratorHandler.getLanguage());
		model.addAttribute("matMigrator1", matHandler.getLanguage());
		model.addAttribute("uploadedLanguages",
				migratorHandler.getUploadedLanguages());
		System.out.println("igate");
		sessionObj.setAttribute("uploadedLanguages",migratorHandler.getUploadedLanguages());
		//System.out.println(migratorHandler.getUploadedLanguages());
		String uname = (String) sessionObj.getAttribute("userName");
		System.out.println(uname + " in migrator");
		model.addAttribute("user", sessionObj.getAttribute("userName"));
		return "MatMigrator1";
	}

	/**
	 * convert the file sybase12.5 to sybase 15x using some sort of rules
	 * 
	 * @param model
	 * @param sessionObj
	 * @param file
	 * @param language
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "migrator2", method = RequestMethod.POST)
	public String goMigrator2(Model model, HttpSession sessionObj,
			@RequestParam("file") MultipartFile file,
			@RequestParam("destinationLanguage") String language,
			HttpServletRequest request) {

		HttpSession htsession = request.getSession();
		ServletContext servContext = htsession.getServletContext();
		String pathSorce = (String) servContext.getInitParameter("ReportPathUpload");
		String pathDest = (String) servContext
				.getInitParameter("ReportPathDest");
//		System.out.println(pathSorce);
//		System.out.println(pathDest);
		
		if (!file.isEmpty()) {
			try {
	//			System.out.println(context.getRealPath(""));

				File convFile = new File(context.getRealPath("/") + pathSorce
						+ "/" + "inputFile.txt");
				
				
				file.transferTo(convFile);

				File file2 = new File(context.getRealPath("/") + pathDest + "/"
						+ "file2.txt");

				
				File auditFile = new File(context.getRealPath("/") + pathDest + "/"
						+ "Audit.txt");
				
			
				//Modified in Phase-2 by Hari ,Ankit and Siddhu
				List<MigratorRules> ruleIdList1 = matMigrateService
						.getRulesFromDataBase(language);
				
				
					file2 = MigratorHandler.applyRule(convFile, file2,auditFile,ruleIdList1);					
		 
				
				sessionObj.setAttribute("UPLOADED_FILE",
						"inputFile.txt");
				System.out.println(sessionObj.getAttribute("UPLOADED_FILE")+" file name");
				
				model.addAttribute("user", sessionObj.getAttribute("userName"));
				
				return "MatMigrator2";
			} catch (Exception e) {
				return "You failed to upload file" + e.getMessage();
			}
		} else {
			return "You failed to upload file because the file was empty.";
		}

	}
	
	@RequestMapping(value = "goOutput")
	public void showOutput(HttpServletRequest request,
			HttpServletResponse response, Model model, HttpSession sessionObj)
			throws IOException {

		model.addAttribute("user", sessionObj.getAttribute("userName"));
		
				
		if("Save Impacted File".equalsIgnoreCase(request.getParameter("ImpactedFile"))){

			saveAuditResult(request,response,model,sessionObj);
		}
		else 
			display(request,response,model,sessionObj);
	}  

//	@RequestMapping(value = "displayresult")
	public void display(HttpServletRequest request,
			HttpServletResponse response, Model model, HttpSession sessionObj)
			throws IOException {

		int BUFFER_SIZE = 4096;
		String filePath = "/resources/css/file2.txt";
		ServletContext context = request.getServletContext();
		String appPath = context.getRealPath("");
		System.out.println("appPath = " + appPath);

		String fullPath = appPath + filePath;
		File downloadFile = new File(fullPath);
		FileInputStream inputStream = new FileInputStream(downloadFile);

		String mimeType = context.getMimeType(fullPath);
		if (mimeType == null) {
			// set to binary type if MIME mapping not found
			mimeType = "application/octet-stream";
		}
		System.out.println("MIME type: " + mimeType);

		// set content attributes for the response
		response.setContentType(mimeType);
		response.setContentLength((int) downloadFile.length());

		// set headers for the response
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				downloadFile.getName());
		response.setHeader(headerKey, headerValue);

		// get output stream of the response
		OutputStream outStream = response.getOutputStream();

		byte[] buffer = new byte[BUFFER_SIZE];
		int bytesRead = -1;

		// write bytes read from the input stream into the output stream
		while ((bytesRead = inputStream.read(buffer)) != -1) {
			outStream.write(buffer, 0, bytesRead);
		}
		
		inputStream.close();
		outStream.close();
		response.flushBuffer();
		model.addAttribute("user", sessionObj.getAttribute("userName"));

	}

	
//	@RequestMapping(value = "saveAuditResult")
	public void saveAuditResult(HttpServletRequest request,
			HttpServletResponse response, Model model, HttpSession sessionObj)
			throws IOException {

		int BUFFER_SIZE = 4096;
		String filePath = "/resources/css/Audit.txt";
		ServletContext context = request.getServletContext();
		String appPath = context.getRealPath("");
		System.out.println("appPath = " + appPath);

		String fullPath = appPath + filePath;
		File downloadFile = new File(fullPath);
		FileInputStream inputStream = new FileInputStream(downloadFile);

		String mimeType = context.getMimeType(fullPath);
		if (mimeType == null) {
			// set to binary type if MIME mapping not found
			mimeType = "application/octet-stream";
		}
		System.out.println("MIME type: " + mimeType);

		// set content attributes for the response
		response.setContentType(mimeType);
		response.setContentLength((int) downloadFile.length());

		// set headers for the response
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",
				downloadFile.getName());
		response.setHeader(headerKey, headerValue);

		// get output stream of the response
		OutputStream outStream = response.getOutputStream();

		byte[] buffer = new byte[BUFFER_SIZE];
		int bytesRead = -1;

		// write bytes read from the input stream into the output stream
		while ((bytesRead = inputStream.read(buffer)) != -1) {
			outStream.write(buffer, 0, bytesRead);
		}
		
		inputStream.close();
		outStream.close();
		response.flushBuffer();
		model.addAttribute("user", sessionObj.getAttribute("userName"));
	
	}
	
	@RequestMapping(value = "java")
	public String java(@RequestParam("subject")String sub,Model m, HttpSession hs) {
		/*
		 * m.addAttribute("Java",1); m.addAttribute("Sybase",2);
		 */
		m.addAttribute("subject", sub);
		hs.setAttribute("subjectSelect",sub);
		hs.setAttribute("uploadedLanguages",migratorHandler.getUploadedLanguages());
		hs.setAttribute("fileName_description", migratorHandler.getDescriptions(sub));
		hs.removeAttribute("message1");
		System.out.println(sub);
		m.addAttribute("user", hs.getAttribute("userName"));
		ServletContext servContext = hs.getServletContext();
		String pathSorce = (String) servContext
				.getInitParameter("ReportPath");
		File f = new File(context.getRealPath("/") + pathSorce);
		String[] sr;
		m.addAttribute("file added successfully", "");
		sr = f.list();
		List<String> filenames=migratorHandler.getfileNames(sub);
		System.out.println("inside controller "+ migratorHandler.getfileNames(sub));
		hs.setAttribute("sizeOfFilenames", filenames.size());
	//	m.addAttribute("resultsFiles", filenames);
		hs.setAttribute("resultFiles",filenames);
		// List str=new ArrayList<String>();
		/*if(sr.length!=0)
		for(String filefg:sr)
			System.out.println(filefg);*/
		System.out.println("going to upload");
		return "upload";
	}

	

	@RequestMapping(value = "uploadFile", method = RequestMethod.POST)
	public String uploadFile(Model model, HttpSession hs,
			@RequestParam("file1") MultipartFile file1,@RequestParam("description")String description,
			HttpServletRequest request) {

		HttpSession htsession = request.getSession();
		model.addAttribute("user", htsession.getAttribute("userName"));
		model.addAttribute("file added successfully", "message1");
		hs.setAttribute( "message1","file added successfully");
		ServletContext servContext = htsession.getServletContext();
		String subjectSelected=(String) hs.getAttribute("subjectSelect");
		hs.setAttribute("fileName_description", migratorHandler.getDescriptions(subjectSelected));
		hs.setAttribute("subjectSelect", subjectSelected);
		String pathSorce1 = (String) servContext
				.getInitParameter("ReportPath");
		String pathDest1 = (String) servContext
				.getInitParameter("ReportPathDest");
		System.out.println(pathSorce1);
		System.out.println(pathDest1);
		String fileFolder=context.getRealPath("/")+pathDest1+"/"+file1.getOriginalFilename();
		hs.setAttribute("fileFolder",fileFolder);
		if (!file1.isEmpty()) {
			try {
				System.out.println(context.getRealPath(""));
				File convFile = new File(context.getRealPath("/") + pathDest1+ "/" + file1.getOriginalFilename());
			migratorHandler.saveFile(fileFolder,file1.getOriginalFilename(),description,subjectSelected);
				System.out.println(convFile);
				file1.transferTo(convFile);

			} catch (Exception e) {
				System.out.println(e.getMessage());
			return "You failed to upload file" + e.getMessage();
				//return "upload";
			}
		} else {
			return "You failed to upload file because the file was empty.";
		}

		String pathSorce = (String) servContext
				.getInitParameter("ReportPathDest");
		File f = new File(context.getRealPath("/") + pathSorce);
		String[] sr = f.list();
		List<String> filenames=migratorHandler.getfileNames(subjectSelected);
		hs.setAttribute("resultFiles", filenames);
		hs.setAttribute("sizeOfFilenames", filenames.size());
		return "upload";
	}
	
	@RequestMapping(value ="deleteFile")
	public String deleteFile(@RequestParam("nameFile")String filename,HttpServletRequest request,Model model)
	{
		HttpSession htsession = request.getSession();
		model.addAttribute("user", htsession.getAttribute("userName"));
		ServletContext servContext = htsession.getServletContext();
		String subjectSelected=(String) htsession.getAttribute("subjectSelect");
		htsession.setAttribute( "message1","file deleted successfully");
		String pathSorce = (String) servContext
				.getInitParameter("ReportPathDest");
		File f = new File(context.getRealPath("/") + pathSorce);
		migratorHandler.deleteFile(filename);
		File removablaeFile=new File(f+"/"+filename);
		removablaeFile.delete();
		System.out.println(filename);
		List<String> filenames=migratorHandler.getfileNames(subjectSelected);
		System.out.println(filenames);
		String[] sr = f.list();
		htsession.setAttribute("resultFiles",filenames);
		htsession.setAttribute("sizeOfFilenames", filenames.size());
		return "upload";
	}
	
	@RequestMapping(value = "addRules")
	public String addRules(Model m, HttpSession htsession) {
		htsession.setAttribute("uploadedLanguages",
				migratorHandler.getUploadedLanguages());
		htsession.removeAttribute("messagesuccess");
		htsession.setAttribute("allValues", migratorHandler.getAllValues());
		m.addAttribute("user", htsession.getAttribute("userName"));
		m.addAttribute("addrules", addrules);
		return "addRules";
	}

	@RequestMapping(value = "insertMigratorRules")
	public String insertRules(Model m,
			@ModelAttribute("addrules") AddingRules add,HttpSession hs) {
		add.setSource_string(add.getSource_string().toUpperCase());
		add.setDestination_string(add.getDestination_string().toUpperCase());
	List<String>ls=migratorHandler.getSourceStrings();
		for(String s:ls)
		{
			if(s.equalsIgnoreCase(add.getSource_string()))
			{
				hs.setAttribute("messagesuccess", "Source String Already Present.Please Enter Another Source String");
				return "addRules";
			}
		}
		hs.setAttribute("allValues", migratorHandler.getAllValues());
		int result = migratorHandler.insertRules(add);
		if (result == 1)
		{
			hs.setAttribute("messagesuccess", "Migrator Rules Added Sucessfully");
			return "sucess";
		}
		else
		{
			hs.setAttribute("messagesuccess", "Migrator Rules Not Added Sucessfully");
			return "addRules";
		}
	}
	
	@RequestMapping(value="deleteRules")
	public String deleteRules(HttpSession hs)
	{
		hs.setAttribute("sourceString", migratorHandler.getSourceStrings());
		hs.setAttribute("user", hs.getAttribute("userName"));
		hs.removeAttribute("messagesuccess");
		return "deleteRules";
	}
	
	@RequestMapping(value="deleteMigratorRules")
	public String deleteRules(@RequestParam("sourceStringSelected")String sselected,HttpSession hs)
	{
		int result=migratorHandler.deleteRules(sselected);
		hs.setAttribute("sourceString", migratorHandler.getSourceStrings());
		if(result==1)
		{
			hs.setAttribute("messagesuccess", "Migrator Rules Deleted Sucessfully");
		return "sucess";
		}
		else
		{
			hs.setAttribute("messagesuccess", "Migrator Rules Not Deleted Sucessfully");
			return "deleteRules";
		}
	}
	
}

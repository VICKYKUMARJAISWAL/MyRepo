package com.igate.controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import com.igate.handler.MatHandler;
import com.igate.modal.Remote;

@Controller
@RequestMapping(value = "Remote")
public class RemoteController {
	
	@Autowired
	Remote remote;
	
	@Autowired
	MatHandler matHandler;
	
	@RequestMapping("remote")
	public String remoteTarget(@ModelAttribute("remote") Remote remote,Model model, HttpSession sessionObj) {
		model.addAttribute("remote", remote);
		return "remote";
	}
	
	@RequestMapping("remote1")
	public String remote(@ModelAttribute("remote") Remote remoteT,Model model,HttpSession sessionObj,
			@RequestParam("servername") String servername,
			@RequestParam("portnumber") String portnumber,
			@RequestParam("username") String username,
			@RequestParam("password") String password) {
		
		remote.setServername(servername);
		remote.setPortnumber(portnumber);
		remote.setUsername(username);
		remote.setPassword(password);
		
		model.addAttribute("remote", remote);

		List<String> database =matHandler.getDBData(remote);
		if(null!=database)
		{
		Iterator<String> itr = database.iterator();
	      while(itr.hasNext())
	      {
		      if(itr.next() == null) 
		      { 
		    	  itr.remove();
		    	  
		      }
		 }
		}
	    remote.setDatabase(database);
		return "remote";
	}
}

package com.igate.mapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.igate.dao.DBScanDao;
import com.igate.dao.MatDao;
import com.igate.modal.CCARuleDescDTO;
import com.igate.modal.ComplexityAnalyzer;
import com.igate.modal.DBScan;
import com.igate.modal.UserDetails;
import com.igate.util.Util;

public class DBScanMapper {

	@Autowired DBScanDao dao;
	

	public Model getDetails(Model model,HttpSession sessionObj,MultipartFile file,String Language,String destLanguage,String name) {
		// TODO Auto-generated method stub
		List<DBScan> DBScanList = dao.getDetails(Language);
			return new Util().getDBScanResult(model,sessionObj, dao,file, Language, destLanguage, name, DBScanList);
//			return Util.getFunctions(file,name,DBScanList);

	}
	

}

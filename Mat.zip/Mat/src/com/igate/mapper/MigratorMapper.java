package com.igate.mapper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.igate.dao.MigratorDao;
import com.igate.modal.AddingRules;
import com.igate.modal.Language_Platform;
import com.igate.modal.MatMigrator;
import com.igate.modal.UserDetails;

public class MigratorMapper {

	
	@Autowired
	MatMigrator matMigrator;
	@Autowired
	MigratorDao migratorDao;
	
	public MatMigrator  getLanguage() {
		List<String> sourceLanguage = migratorDao.getLanguage();
		System.out.println(sourceLanguage);
		Iterator<String> itr = sourceLanguage.iterator();
	      while(itr.hasNext())
	      {
		      if(itr.next() == null) 
		      { 
		    	  itr.remove();
		    	  
		      }
		 }
		List<String> destinationLanguage = new ArrayList(MigratorDao.getSetLanguages());
		matMigrator.setSourceLanguage(sourceLanguage);
		matMigrator.setDestinationLanguage(destinationLanguage);
		return matMigrator;
	}
	
	
	public List<String> getUploadedLanguages() {
		// TODO Auto-generated method stub
		List<String> language = migratorDao.getUploadedLanguages();
	      return language;
	}
	public void saveFile(String originalFilename, String pathSorce1,
			String description,String subjectSelected) {
		// TODO Auto-generated method stub
		migratorDao.save(originalFilename,pathSorce1,description,subjectSelected);
	}


	public List<Map<String, Object>> getDescriptions(String sub) {
		// TODO Auto-generated method stub
		return migratorDao.getDescriptions(sub);
	}


	public void deleteFile(String filename) {
		// TODO Auto-generated method stub
		migratorDao.deleteFile(filename);
	}


	public List<String> getfileNames(String subjectSelected) {
		// TODO Auto-generated method stub
		System.out.println("inside mapper "+migratorDao.getfileNames(subjectSelected));
		return migratorDao.getfileNames(subjectSelected);
	}


	public int insertRules(AddingRules add) {
		// TODO Auto-generated method stub
		return migratorDao.insertRules(add);
	}


	/*public List<String> getSourceLanguages() {
		// TODO Auto-generated method stub
		return migratorDao.getSourceLanguages();
	}


	public List<String> getDestinationLanguages() {
		// TODO Auto-generated method stub
		return migratorDao.getDestinationLanguages();
	}


	public List<String> getSourcePlatform() {
		// TODO Auto-generated method stub
		return migratorDao.getSourcePlatform();
	}
	
	public List<String> getDestinationPlatform() {
		// TODO Auto-generated method stub
		return migratorDao.getDestinationPlatform();
	}
*/

	public List<Language_Platform> getAllvalues() {
		// TODO Auto-generated method stub
		return migratorDao.getAllvalues();
	}


	public List<String> getSourceStrings() {
		// TODO Auto-generated method stub
		return migratorDao.getSourceStrings();
	}


	public int deleteRules(String sselected) {
		// TODO Auto-generated method stub
		return migratorDao.deleteRules(sselected);
	}
}

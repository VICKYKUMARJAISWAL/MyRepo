package com.igate.mapper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.igate.dao.MatDao;
import com.igate.modal.CCARuleDescDTO;
import com.igate.modal.ComplexityAnalyzer;
import com.igate.modal.DBText;
import com.igate.modal.MatDBRange;
import com.igate.modal.Remote;
import com.igate.modal.RuleDescDTO;
import com.igate.modal.UserDetails;

public class MatMapper {

	@Autowired MatDao dao;
	@Autowired ComplexityAnalyzer complexityAnalyzer;
	
	public boolean login(UserDetails userDetails){	
		List<UserDetails> list = dao.getDetails(userDetails.getName(),userDetails.getPassword());
		if(list.size()>0) {
			return true;
		} else {
			return false;
		}
	}
	
	
	public ComplexityAnalyzer  getLanguage() {
		List<String> language = dao.getLanguage();
		Iterator<String> itr = language.iterator();
	      while(itr.hasNext())
	      {
		      if(itr.next() == null) 
		      { 
		    	  itr.remove();
		    	  
		      }
		 }
		List<String> platform = new ArrayList(MatDao.getSetPlatform());
		complexityAnalyzer.setLanguage(language);
		complexityAnalyzer.setPlatform(platform);
		return complexityAnalyzer;
	}
	
	public List<RuleDescDTO> getRulesDescription(String lang){
		List<RuleDescDTO> ls=dao.getRuleDescription(lang);
		return ls;
	}
	
	public List<MatDBRange>  getComplexity() {
		return dao.getCodeComplexity();
	}


	


	public String getRole(UserDetails userDetails) {
		// TODO Auto-generated method stub
		
		return dao.getRole(userDetails.getName());
	}
	
	public List<String> getDBData(Remote remote) {
		// TODO Auto-generated method stub
		
		//return dao.getSyBaseDB(remote);
		  return dao.getOracleDB(remote);
	}
}

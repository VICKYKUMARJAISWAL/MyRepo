package com.igate.mapper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.igate.dao.AdminDao;
import com.igate.handler.MigratorHandler;
import com.igate.modal.AddingCCARules;
import com.igate.modal.AddingRules;
import com.igate.modal.DBScan;
import com.igate.modal.Language_Platform;
import com.igate.modal.MigratorRules;
import com.igate.modal.UserDetails;

public class AdminMapper {

	
	@Autowired
	AdminDao adao;
	public List<Language_Platform> getAllValues() {
		// TODO Auto-generated method stub
		return adao.getAllValues();
	}
	public int insertCCA(AddingCCARules addCCA) {
		// TODO Auto-generated method stub
		return adao.insertCCA(addCCA);
	}
	public List<AddingCCARules> getKeyWords() {
		// TODO Auto-generated method stub
		return adao.getKeyWords();
	}
	public int deleteCCA(String keyword) {
		// TODO Auto-generated method stub
		return adao.deleteCCA(keyword);
	}
	public AddingRules getDetails(String sString) {
		// TODO Auto-generated method stub
		return adao.getDetails(sString);
	}
	public int doUpdate(AddingRules add) {
		// TODO Auto-generated method stub
		return adao.doUpdate(add);
	}
	public AddingCCARules getKeywordDetails(String kWord) {
		// TODO Auto-generated method stub
		return adao.getKeywordDetails(kWord);
	}
	public int doUpdateCCA(AddingCCARules addCCA) {
		// TODO Auto-generated method stub
		return adao.doUpdateCCA(addCCA);
	}
	public List<String> getKeyWord() {
		// TODO Auto-generated method stub
		return adao.getKeyWord();
	}
	public List<MigratorRules> getRulesFromDataBase() {
		// TODO Auto-generated method stub
		return adao.getRulesFromDataBase();
	}
	public List<UserDetails> getUsers() {
		// TODO Auto-generated method stub
		return adao.getUsers();
	}
	public int insertUser(UserDetails user1) {
		// TODO Auto-generated method stub
		return adao.insertUser(user1);
	}
	public int deleteUser(String uSelected) {
		// TODO Auto-generated method stub
		return adao.deleteUser(uSelected);
	}
	public int updateUser(UserDetails userB, String uname) {
		// TODO Auto-generated method stub
		return adao.updateUser(userB,uname);
	}
	/**
	 * @return
	 */
	public List<DBScan> getCodeScanRules() {
		// TODO Auto-generated method stub
		return adao.getCodeScanRules();
	}
	/**
	 * @param dScan
	 * @return
	 */
	public int insertCodeRules(DBScan dScan) {
		// TODO Auto-generated method stub
		return adao.insertCodeRules(dScan);
	}
	/**
	 * @param kword
	 * @return
	 */
	public int deleteCode(String kword) {
		// TODO Auto-generated method stub
		return adao.deleteCode(kword);
	}
	/**
	 * @param userB
	 * @param kName
	 * @return
	 */
	public int updateCodeUser(DBScan userB, String kName) {
		// TODO Auto-generated method stub
		return adao. updateCodeUser(userB,kName);
	}

}

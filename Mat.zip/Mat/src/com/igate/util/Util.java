package com.igate.util;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import com.igate.dao.DBScanDao;
import com.igate.modal.Comments;
import com.igate.modal.DBScan;

public class Util {

	private int ObjectCount = 0;
	private  Map<String, String> objectCountMap = new HashMap<String, String>();
	private  boolean isObject = false;

	public int getFunctions(MultipartFile file, String name,
			String searchword) throws IOException {
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream = new BufferedOutputStream(
				new FileOutputStream(new File(name)));
		stream.write(bytes);
		stream.close();
		int count = 0;
		try {
			int LineCount = 0;
			String line = "";
			BufferedReader bReader = new BufferedReader(new FileReader(name));
			System.out.println(line);
			while ((line = bReader.readLine()) != null) {
				LineCount++;
				line = line.replaceAll("\\n|\\t|\\s", "").toUpperCase();
				int posFound = line.indexOf(searchword.replaceAll(
						"\\n|\\t|\\s", "").toUpperCase());
				if (posFound > -1) {
					count++;
				}
			}
			bReader.close();
			return count;
		} catch (IOException e) {
			System.out.println("Error: " + e.toString());
		}
		return count;
	}

	public  Model getDBScanResult(Model model, HttpSession sessionObj,DBScanDao dao,
			MultipartFile file, String lang, String destLanguage, String name,
			List<DBScan> dbScanList) {
		try {
			Comments comments = dao.getComments(lang);
			List<String> QUERYLIST = getQueriesForSybase("CREATE", comments, file, name);
			return getKeywordSearch(model, sessionObj, dao, lang, destLanguage, dbScanList, QUERYLIST);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	private static List<String> getQueriesForSybase(String searchword, Comments comments,
			MultipartFile file, String name) throws IOException {
		byte[] bytes = file.getBytes();
		BufferedOutputStream stream = new BufferedOutputStream(
				new FileOutputStream(new File(name)));
		stream.write(bytes);
		stream.close();
		List<String> QUERYLIST = new ArrayList<String>();
		try {
			String line = "";
			String entity = "";
			boolean start = true;
			BufferedReader bReader = new BufferedReader(new FileReader(name));
			boolean skip = false;
			String comment[] = comments.getMultiple().split(",");
			String startComments = comment[0];
			String endComments = comment[1];			
			while ((line = bReader.readLine()) != null) {
				if(line.contains(startComments)) {
					skip = true;
				}
				if(skip !=true) {
					if(!line.contains(comments.getSingleLine())) {
						if (!line.toUpperCase().contains("CREATE") || start == true) {
							entity = entity +" "+ line;
							start = false;
						} else {
							start = true;
							QUERYLIST.add(entity.trim());
							entity = " "+line;
						}					}
					
				}				
				if(line.contains(endComments)) {
					skip = false;
				}
			}
			QUERYLIST.add(entity.trim());
			bReader.close();
		} catch (IOException e) {
			System.out.println("Error: " + e.toString());
		}
		return QUERYLIST;
	}

	private  Model getKeywordSearch(Model model, HttpSession sessionObj, DBScanDao dao,
			String lang, String destLanguage, List<DBScan> searchlist, List<String> querylist) {
		Map<String, List<Map<String, String>>> res = new HashMap<String, List<Map<String, String>>>();

		for (DBScan key : searchlist) {
			res.put(key.getDesc(), getQuerySearch(dao, lang, destLanguage, key, querylist));		
			objectCountMap.put(key.getDesc(), String.valueOf(ObjectCount));
			ObjectCount = 0;
		}
		for (Entry result : objectCountMap.entrySet()) {
			System.out.println(result.getKey() + " object count:"
					+ result.getValue());

		}

		model.addAttribute("result", res);
		model.addAttribute("impacted", objectCountMap);		
		sessionObj.setAttribute("result",res);
		sessionObj.setAttribute("impacted",objectCountMap);
		
		return model;

	}

	private  List<Map<String, String>> getQuerySearch(DBScanDao dao,
			String lang, String destLanguage, DBScan keyword, List<String> querylist) {
		List<Map<String, String>> res = new ArrayList<Map<String, String>>();
		for (String query : querylist) {
			if (query.toLowerCase().contains(keyword.getKeyword().toLowerCase())) {				
				if (keyword.getInnerSearch().equals("YES")) {
					res.add(getSubkeywordSearch(dao, lang, destLanguage,
							keyword.getSubKeyword(), query));
				}
			}
		}
		return res;

	}

	private  Map<String, String> getSubkeywordSearch(DBScanDao dao,
			String lang, String destLanguage,String subkeyword, String Query) {
		String objectName = Query.split("[\\s\\(]+")[2];
		System.out.println(" object name:" + objectName);
		Map<String, String> res = new HashMap<String, String>();
		res.put("name", objectName);
		boolean impcheck = false;
		StringTokenizer subkeywordTokens = new StringTokenizer(subkeyword, ",");
		while (subkeywordTokens.hasMoreElements()) {
			String keyword = subkeywordTokens.nextElement().toString();
			System.out.println(keyword + " : " + dao.isimpacted(lang, destLanguage, keyword));
			String searchkey = keyword.replaceAll("\\n|\\t|\\s", "");
			Query = Query.replaceAll("\\n|\\t|\\s", "");
			int count = 0;
			int lastIndex = 0;
			while (lastIndex != -1) {
				lastIndex = Query.toLowerCase().indexOf(searchkey.toLowerCase(), lastIndex);
				if (lastIndex != -1) {
					if (!res.containsKey(keyword)) {
						res.put(keyword, String.valueOf(++count));
					} else {
						count = Integer.parseInt((res.get(keyword)));
						res.put(keyword, String.valueOf(++count));
					}
					if (dao.isimpacted(lang, destLanguage, keyword)) {
						if (!impcheck) {
							ObjectCount++;
							isObject = true;
						}
						impcheck = true;
					}
					lastIndex += searchkey.length();
				}
			}
		}
		if (isObject) {
			objectCountMap.put(objectName, String.valueOf(1));
			isObject = false;
		}
		return res;

	}

	
	
}

package com.igate.day6.jdbc.businesslogic;

import java.io.IOException;

public class Staff extends Parking {

	/*
	 * Declaring required static variables and method
	 */

	static Staff staff;
	

	
	public static Staff getStaffObj(String parkingName, int slotCount)
			throws IOException {
		// Creating object only if no object is available
		if (staff == null)
			staff = new Staff(parkingName, slotCount);

		return staff;
	}

	// Constructor is private: Only 1 object required
	private Staff(String parkingName, int slotCount) throws IOException {
		super(parkingName, slotCount);
		// TODO Auto-generated constructor stub
	}

	public void calculateCharges() {
		// TODO Auto-generated method stub
		totalamt = totalamt + 1;
	}

}

package com.igate.day6.jdbc.businesslogic;

import com.igate.day6.jdbc.integration.exception.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;
import java.util.TreeMap;

public class Parking {
	String parkingName;
	public String getParkingName() {
		return parkingName;
	}

	public void setParkingName(String parkingName) {
		this.parkingName = parkingName;
	}

	public int slotCount; // total number of slots

	public static int totalamt;
	Connection connection;
	PreparedStatement preparedStatement;
	Statement statement;
	ResultSet resultSet;

	/*
	 * Constructor to create slots in parking Since database is getting used
	 * here, we have removed all initializations of TreeMap and FileStreams from
	 * below code and we have database initialization code here.
	 */
	public Parking(String parkingName, int slotCount) {
		this.parkingName = parkingName;
		this.slotCount = slotCount;
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@172.21.17.5:1521:oraten", "lab04trg1",
					"lab04oracle");
			preparedStatement = connection
					.prepareStatement("insert into slot(slotno,isallocatedstatus) values(seq.nextval,?)");
			statement = connection.createStatement();

			statement.executeUpdate("delete from slot");
			statement.executeUpdate("delete from vehicle");
			connection.commit();
			// we have 100 slots, all unallocated and slot no. starts from 1.
			for (int i = 1; i <= 100; i++) {
			//	System.out.println(preparedStatement.toString());
				preparedStatement.setString(1,"n");
				//System.out.println(preparedStatement);
				preparedStatement.addBatch();
				}
			preparedStatement.executeBatch();

			connection.commit();
		} catch (SQLException e) {
			//e.printStackTrace();
			System.err.println("Cant proceed.. because of " + e.getMessage());
		}

	}

	// abstract method to calculate charges
	// public abstract void calculateCharges();
	// above declaration is now removed and is in interface IParking

	/*
	 * Method to check whether a slot is free
	 */
	public Slot getFreeSlot() throws SQLException {
		resultSet = statement.executeQuery("select * from slot");
		Slot slot=null;
		if (resultSet == null) {
			return null;
		}
		while (resultSet.next()) {
			if (resultSet.getString("isAllocatedStatus").equalsIgnoreCase("n")) {
				slot = new Slot();
				slot.setAllottedStatus(false);
				slot.setSlotNumber(resultSet.getInt("slotNo"));
				break;
			}
		}
		return slot;
	}

	/*
	 * Tasks to be done when vehicle departs
	 */
	public void vehicleDeparture(String vehRegNo) {
		int cnt = 0;
		try {
			preparedStatement=connection.prepareStatement("update slot set isallocatedstatus='n',vehregno=null where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			cnt = preparedStatement.executeUpdate();

			preparedStatement=connection.prepareStatement("delete from vehicle where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		if (cnt == 0) {
			try {
				throw new VehicleNotParkedException(
						"Please check Vehicle no. This vehicle not in parking");
			} catch (VehicleNotParkedException e) {
				// TODO Auto-generated catch block
				System.err.println(e.getMessage());
			}
		}
	}

	/*
	 * Method to check whether a slot is free
	 */
	public Vehicle findVehicle(String vehRegNo)
			throws VehicleNotParkedException {
		Vehicle vehicle = null;
		try {
			preparedStatement=connection.prepareStatement("select * from slot where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			int cnt = preparedStatement.executeUpdate();
			if (cnt == 0) {
				throw new VehicleNotParkedException(vehRegNo
						+ " Not in this parking");
			} else {
				// Now returning vehicle if it is available
				preparedStatement=connection.prepareStatement("select * from vehicle where vehregno=?");
				preparedStatement.setString(1, vehRegNo);
				resultSet=preparedStatement.executeQuery();
				
				resultSet.next();
				vehicle = new Vehicle(vehRegNo, resultSet
						.getString("arrival_time"));
				if (resultSet.getString("waitStatus").equals("y"))
					vehicle.setWaitStatus(true);
				else
					vehicle.setWaitStatus(false);
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return vehicle;
	}

	// search if slot is available,
	// if slot is available, put vehicle in it.
	// some more exceptions added in throws list
	public void vehicleArrival(String vehRegNo, String arrivalTime) {
		try {
			Vehicle newVehicle = new Vehicle(vehRegNo, arrivalTime);

			// Add vehicle entry at first empty position
			Slot free = getFreeSlot();

			if (free == null) {
				newVehicle.setWaitStatus(true); // requesting vehicle to wait
				System.out.println("Vehicle waiting: " + vehRegNo);
				throw new NoParkingAvailableException(vehRegNo);
			} else {
				calculateCharges();
				preparedStatement=connection.prepareStatement("insert into vehicle values(?,?,?)");
				preparedStatement.setString(1, vehRegNo);
				preparedStatement.setString(2, arrivalTime);
				preparedStatement.setString(3, "n");
				preparedStatement
						.executeUpdate();
				free.setVehicle(newVehicle); // allocate free slot to the new
												// vehicle
				free.setAllottedStatus(true); // mark slot as allocated
				int slotno = free.getSlotNumber();
				
				preparedStatement=connection.prepareStatement("insert into slot values(seq.nextval,?,?)");
				//preparedStatement.setInt(1, slotno);
				preparedStatement.setString(1, vehRegNo);
				if(this.getParkingName().trim().equalsIgnoreCase("Staff"))
				preparedStatement.setString(2, "s");
				else
					preparedStatement.setString(2,"v");
				
				preparedStatement.executeUpdate();
					connection.commit();
			}
		} catch (NoParkingAvailableException e1) {
			System.err.println(e1.getMessage());
		} catch (SQLException e2) {
			System.err.println(e2.getMessage());

		}
	}

	// To get slot occupation information
	// some more exceptions added in throws list
	public Vehicle getVehicleOnSlot(int slotNumber) {
		Vehicle vehicle = null;
		try {
			preparedStatement.executeQuery("select * from slot where slotno=?");
			preparedStatement.setInt(1, slotNumber);
			int cnt = preparedStatement.executeUpdate();
			if (cnt == 0)
				throw new NoParkingAvailableException("Not a valid slot number");
			else {
				resultSet = preparedStatement
						.executeQuery("select * from slot where slotno=?");
				preparedStatement.setInt(1, slotNumber);
				resultSet.next();
				String vehregno = resultSet.getString("vehregno");
				resultSet = preparedStatement
						.executeQuery("select * from vehicle where vehregno=?");
				preparedStatement.setString(1, vehregno);
				resultSet.next();
				vehicle = new Vehicle(vehregno, resultSet
						.getString("arrival_time"));
				if (resultSet.getString("waitStatus").equals("y"))
					vehicle.setWaitStatus(true);
				else
					vehicle.setWaitStatus(false);

			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		} catch (NoParkingAvailableException e) {
			System.err.print("No parking available at this slot number");
		}
		return vehicle;

	}

	// Getting slot number by providing vehicle number
	// some more exceptions added in throws list
	public Slot getAllotedSlot(String vehRegNo) {
		Slot slot = null;
		Vehicle vehicle = null;

		// //
		try {
			preparedStatement
					.executeQuery("select * from slot where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			int cnt = preparedStatement.executeUpdate();
			if (cnt == 0) {
				throw new VehicleNotParkedException(vehRegNo
						+ " Not in this parking");
			} else {
				// Now returning vehicle if it is available
				preparedStatement
						.executeQuery("select * from vehicle where vehregno=?");
				preparedStatement.setString(1, vehRegNo);
				resultSet = preparedStatement.executeQuery();
				resultSet.next();
				vehicle = new Vehicle(vehRegNo, resultSet
						.getString("arrival_time"));
				if (resultSet.getString("waitStatus").equals("y"))
					vehicle.setWaitStatus(true);
				else
					vehicle.setWaitStatus(false);
			}
			preparedStatement=connection.prepareStatement("select * from slot where vehregno=?");
			preparedStatement.setString(1,vehRegNo);
			resultSet = preparedStatement.executeQuery();
			resultSet.next();
			slot.setSlotNumber(resultSet.getInt("slotno"));
			if (resultSet.getString("isallocatedstatus").equals("y"))
				slot.setAllottedStatus(true);
			else
				slot.setAllottedStatus(false);
			slot.setVehicle(vehicle);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		} catch (VehicleNotParkedException e) {
			System.err.println(e.getMessage());
		}
		// //

		return slot;
	}

	public int getSlotCount() {
		return slotCount;
	}

	public int getTotalAmt() {
		return totalamt;
	}

	// To override only
	private void calculateCharges() {
		// TODO Auto-generated method stub
		if(this.getParkingName().equalsIgnoreCase("Staff"))
		{
			totalamt=totalamt+1;
		}
		else
			totalamt=totalamt+10;
	}

	public void getStaffCars()
	{
		//status s is for staff
		try {
			resultSet=statement.executeQuery("select * from slot where isallocatedstatus='s'");
			System.out.println("Staff cars are allocated at");
			System.out.println("SLOT NO. \t\t Vehicle NO. ");
			while(resultSet.next())
			{
				System.out.println(resultSet.getInt(1)+"\t\t"+resultSet.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void getVisitorCars()
	{
		//status v is for visitors.
		try {
			resultSet=statement.executeQuery("select * from slot where isallocatedstatus='v'");
			System.out.println("Staff cars are allocated at");
			System.out.println("SLOT NO. \t\t Vehicle NO. ");
			while(resultSet.next())
			{
				System.out.println(resultSet.getInt(1)+"\t\t"+resultSet.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
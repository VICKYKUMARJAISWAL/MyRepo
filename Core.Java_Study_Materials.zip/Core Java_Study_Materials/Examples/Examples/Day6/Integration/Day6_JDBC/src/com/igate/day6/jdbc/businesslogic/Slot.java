package com.igate.day6.jdbc.businesslogic;

import java.io.Serializable;

//Slot must implement Serializable as we are writing it on persistent storage
public class Slot implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*
	 * Slot has information about slotNumber,vehicle to which slot is allotted,
	 * and isAllottedStatus flag. isAllotedStatus will be true if a vehicle is
	 * allotted to that slot or else it will be false.
	 */
	int slotNumber;
	boolean isAllottedStatus;
	Vehicle vehicle;

	/*
	 * Slot(int slotNumber) Constructor to initialize Slot object. This should
	 * also set the isAllotedStatus flag to false and Vehicle object to null.
	 */
	public Slot(int slotNumber) {
		this.slotNumber = slotNumber;
		this.isAllottedStatus = false;
		this.vehicle = null;
	}

	public Slot() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * Getter/Setter methods for all variables
	 */
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public int getSlotNumber() {
		return slotNumber;
	}

	public void setSlotNumber(int slotNumber) {
		this.slotNumber = slotNumber;
	}

	public boolean isAllottedStatus() {
		return isAllottedStatus;
	}

	public void setAllottedStatus(boolean isAllottedStatus) {
		this.isAllottedStatus = isAllottedStatus;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

}

package com.igate.day6.jdbc.integration.exception;

public class VehicleNotParkedException extends Exception {

	String message;

	public VehicleNotParkedException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}

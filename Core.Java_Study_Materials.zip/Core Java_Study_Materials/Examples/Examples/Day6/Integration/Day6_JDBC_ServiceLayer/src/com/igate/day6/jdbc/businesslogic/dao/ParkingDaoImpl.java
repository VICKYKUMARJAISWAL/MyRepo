package com.igate.day6.jdbc.businesslogic.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.igate.day6.jdbc.businesslogic.pojo.Slot;
import com.igate.day6.jdbc.businesslogic.pojo.Vehicle;
import com.igate.day6.jdbc.integration.exception.NoParkingAvailableException;
import com.igate.day6.jdbc.integration.exception.VehicleNotParkedException;

public class ParkingDaoImpl implements IParkingDao {

	static Connection connection;
	PreparedStatement preparedStatement;
	Statement statement;
	ResultSet resultSet;
	Properties properties;
	FileInputStream fileinputstream;
	String parkingName;
	
	public ParkingDaoImpl() {
		doInitialization();
	}

	/*
	 * This method does the initalization tasks
	 */
	private void doInitialization() {
		// TODO Auto-generated method stub
		try {
			properties = new Properties();
			try {
				fileinputstream = new FileInputStream("database.properties");
				try {
					properties.load(fileinputstream);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.err.print(e.getMessage());
				}

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.err.print(e.getMessage());
			}

			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@172.21.17.5:1521:oraten", "lab04trg1",
					"lab04oracle");
			preparedStatement = connection
					.prepareStatement("insert into slot(slotno,isallocatedstatus) values(seq.nextval,?)");
			statement = connection.createStatement();

			statement.executeUpdate("delete from slot");
			statement.executeUpdate("delete from vehicle");
			connection.commit();
			// we have 100 slots, all unallocated and slot no. starts from 1.
			for (int i = 1; i <= 100; i++) {
			//	System.out.println(preparedStatement.toString());
				preparedStatement.setString(1,"n");
				//System.out.println(preparedStatement);
				preparedStatement.addBatch();
				}
			preparedStatement.executeBatch();

			connection.commit();
		} catch (SQLException e) {
			System.err.println("Cant proceed.. because of " + e.getMessage());
		}

	}

	@Override
	public Vehicle findVehicle(String vehRegNo) throws VehicleNotParkedException {
		// TODO Auto-generated method stub
		Vehicle vehicle = null;
		try {
			preparedStatement=connection.prepareStatement("select * from slot where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			int cnt = preparedStatement.executeUpdate();
			if (cnt == 0) {
				throw new VehicleNotParkedException(vehRegNo
						+ " Not in this parking");
			} else {
				// Now returning vehicle if it is available
				preparedStatement=connection.prepareStatement("select * from vehicle where vehregno=?");
				preparedStatement.setString(1, vehRegNo);
				resultSet=preparedStatement.executeQuery();
				
				resultSet.next();
				vehicle = new Vehicle(vehRegNo, resultSet
						.getString("arrival_time"));
				if (resultSet.getString("waitStatus").equals("y"))
					vehicle.setWaitStatus(true);
				else
					vehicle.setWaitStatus(false);
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return vehicle;
	}

	@Override
	public Vehicle findVehicle(int slotNumber) {
		// TODO Auto-generated method stub
		Vehicle vehicle = null;
		try {
			preparedStatement=connection.prepareStatement("select * from slot where slotno=?");
			preparedStatement.setInt(1, slotNumber);
			int cnt = preparedStatement.executeUpdate();
					if (cnt == 0)
				throw new NoParkingAvailableException("Not a valid slot number");
			else {
				preparedStatement=connection.prepareStatement("select * from slot where slotno=?");
				preparedStatement.setInt(1, slotNumber);
				resultSet = preparedStatement.executeQuery();
				resultSet.next();
				
				
				String vehregno = resultSet.getString("vehregno");
				
				preparedStatement=connection.prepareStatement("select * from vehicle where vehregno=?");
				preparedStatement.setString(1, vehregno);
				resultSet = preparedStatement.executeQuery();
				
				resultSet.next();
				vehicle = new Vehicle(vehregno, resultSet.getString("arrival_time"));
				if (resultSet.getString("waitStatus").equals("y"))
					vehicle.setWaitStatus(true);
				else
					vehicle.setWaitStatus(false);

			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		} catch (NoParkingAvailableException e) {
			System.err.print("No parking available at this slot number");
		}
		return vehicle;
	}

	@Override
	public Slot getAllocatedSlot(String vehRegNo) {
		// TODO Auto-generated method stub
		Slot slot = null;
		Vehicle vehicle = null;

		// //
		try {
			preparedStatement=connection.prepareStatement("select * from slot where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			int cnt = preparedStatement.executeUpdate();
			if (cnt == 0) {
				throw new VehicleNotParkedException(vehRegNo
						+ " Not in this parking");
			} else {
				// Now returning vehicle if it is available
				preparedStatement=connection.prepareStatement("select * from vehicle where vehregno=?");
				preparedStatement.setString(1, vehRegNo);
				resultSet = preparedStatement.executeQuery();
				resultSet.next();
				vehicle = new Vehicle(vehRegNo, resultSet
						.getString("arrival_time"));
				if (resultSet.getString("waitStatus").equals("y"))
					vehicle.setWaitStatus(true);
				else
					vehicle.setWaitStatus(false);
			}
			preparedStatement=connection.prepareStatement("select * from slot where vehregno=?");
			preparedStatement.setString(1,vehRegNo);
			resultSet = preparedStatement.executeQuery();
			resultSet.next();
			slot.setSlotNumber(resultSet.getInt("slotno"));
			if (!resultSet.getString("isallocatedstatus").equalsIgnoreCase("n"))
				slot.setAllottedStatus(true);
			else
				slot.setAllottedStatus(false);
			slot.setVehicle(vehicle);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		} catch (VehicleNotParkedException e) {
			System.err.println(e.getMessage());
		}
		// //

		return slot;

	}

	@Override
	public Slot getFreeSlot() {
		// Returning first free slot
		Slot slot = null;
		try {
			resultSet = statement.executeQuery("select * from slot");
			if (resultSet == null) {
				return null;
			}
			while (resultSet.next()) {
				if (resultSet.getString("isAllocatedStatus").equalsIgnoreCase(
						"n")) {
					slot = new Slot();
					slot.setAllottedStatus(true);
					slot.setSlotNumber(resultSet.getInt("slotNo"));
					return slot;
				}
			}
		} catch (SQLException e) {
			System.err.println("Error while initialization ... "
					+ e.getMessage());
		}
		return slot;

	}

	@Override
	public int insertSlot(Slot slot) {
		// TODO Auto-generated method stub
		int cnt = 0;
		int flag=0;
		try {
			//preparedStatement.clearParameters();
			preparedStatement=connection.prepareStatement("insert into slot values(seq.nextval,?,?)");
			preparedStatement.setString(1, slot.getVehicle().getVehRegNo());
			
			if(this.getParkingName().trim().equalsIgnoreCase("Staff"))
				flag=1;
			
			if (slot.isAllottedStatus() == true)
			{
				if(flag==1)
				preparedStatement.setString(2, "s");
				else
					preparedStatement.setString(2, "v");
			}
			else
				preparedStatement.setString(2, "n");
			cnt = preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			System.err.println("Error in inserting slot "+e.getMessage());
			//e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public int insertVehicle(Vehicle vehicle) {
		// TODO Auto-generated method stub
		int cnt = 0;
		try {
			preparedStatement=connection.prepareStatement("insert into vehicle values(?,?,?)");
			preparedStatement.setString(1, vehicle.getVehRegNo());
			preparedStatement.setString(2, vehicle.getArrivalTime());
						
			if (vehicle.isWaitStatus() == true)
				preparedStatement.setString(3, "y");
			else
				preparedStatement.setString(3, "n");
			cnt = preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			System.err.println("Error in inserting vehicle "+e.getMessage());
			//e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public int deleteVehicle(String vehRegNo) {
		// TODO Auto-generated method stub
		int cnt = 0;
		try {
			preparedStatement=connection.prepareStatement("update slot set vehregno=null where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			preparedStatement.executeUpdate();
			
			
			preparedStatement=connection.prepareStatement("delete from vehicle where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		if (cnt == 0) {
			try {
				throw new VehicleNotParkedException(
						"Please check Vehicle no. This vehicle not in parking");
			} catch (VehicleNotParkedException e) {
				// TODO Auto-generated catch block
				System.err.println("error while deleting vehicle "+e.getMessage());
				//e.printStackTrace();
			}
		}

		return cnt;
	}

	@Override
	public int makeSlotFree(String vehRegNo) {
		// TODO Auto-generated method stub
		int cnt = 0;
		try {
			preparedStatement=connection.prepareStatement("update slot set isallocatedstatus='n' where vehregno=?");
			preparedStatement.setString(1, vehRegNo);
			cnt = preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		if (cnt == 0) {
			try {
				throw new VehicleNotParkedException(
						"Please check Vehicle no. This vehicle not in parking");
			} catch (VehicleNotParkedException e) {
				// TODO Auto-generated catch block
				System.err.println("Error in updating slot "+e.getMessage());
				//e.printStackTrace();
			}
		}

		return cnt;
	}

	@Override
	public int getFreeSlotCount() {
		// TODO Auto-generated method stub
		int cnt = 0;
	    try {
			preparedStatement=connection.prepareStatement("select * from slot where vehregno=null");
			cnt = preparedStatement.executeUpdate();
			//System.out.println("Total free slots are "+cnt);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return cnt;
	}
	
	
	public void getStaffCars()
	{
		//status s is for staff
		try {
			resultSet=statement.executeQuery("select * from slot where isallocatedstatus='s'");
			System.out.println("Staff cars are allocated at");
			System.out.println("SLOT NO. \t\t Vehicle NO. ");
			while(resultSet.next())
			{
				System.out.println(resultSet.getInt(1)+"\t\t"+resultSet.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.print(e.getMessage());
		}
	}
	
	public void getVisitorCars()
	{
		//status v is for visitors.
		try {
			resultSet=statement.executeQuery("select * from slot where isallocatedstatus='v'");
			System.out.println("Staff cars are allocated at");
			System.out.println("SLOT NO. \t\t Vehicle NO. ");
			while(resultSet.next())
			{
				System.out.println(resultSet.getInt(1)+"\t\t"+resultSet.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.print(e.getMessage());
		}
		
	}

	@Override
	public String getParkingName() {
		// TODO Auto-generated method stub
		return parkingName;
	}
	
	public void setParkingName(String parkingName)
	{
		this.parkingName=parkingName;
	}

}
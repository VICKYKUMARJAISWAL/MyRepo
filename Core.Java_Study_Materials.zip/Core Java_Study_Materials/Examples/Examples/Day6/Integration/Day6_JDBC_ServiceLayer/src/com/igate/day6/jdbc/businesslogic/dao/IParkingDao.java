package com.igate.day6.jdbc.businesslogic.dao;

import com.igate.day6.jdbc.businesslogic.pojo.Slot;
import com.igate.day6.jdbc.businesslogic.pojo.Vehicle;
import com.igate.day6.jdbc.integration.exception.VehicleNotParkedException;

public interface IParkingDao {
	
	int insertVehicle(Vehicle vehicle);
	int insertSlot(Slot slot);
	Vehicle findVehicle(String vehRegNo) throws VehicleNotParkedException;
	Vehicle findVehicle(int slot);
	Slot getFreeSlot();
	Slot getAllocatedSlot(String vehRegNo);
	int makeSlotFree(String vehRegNo);
	int deleteVehicle(String vehRegNo);
	int getFreeSlotCount();
	void getVisitorCars();
	void getStaffCars();
	String getParkingName();
	void setParkingName(String parkingName);
	}

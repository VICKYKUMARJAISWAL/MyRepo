package com.igate.day6.jdbc.businesslogic.pojo;

import java.io.IOException;

import com.igate.day6.jdbc.businesslogic.service.ParkingImpl;

public class Visitor extends ParkingImpl {

	/*
	 * Declaring required static variables and method
	 */

	static Visitor visitor;

	private Visitor(String parkingName, int slotCount) {
		// TODO Auto-generated constructor stub
		super(parkingName, slotCount);
	}

	public static Visitor getVisitorObj(String parkingName, int slotCount)
			throws IOException {
		// Creating object only if no object is available
		if (visitor == null)
			visitor = new Visitor(parkingName, slotCount);

		return visitor;
	}

	public void calculateCharges() {
		// TODO Auto-generated method stub
		totalamt = totalamt + 10;
	}
}

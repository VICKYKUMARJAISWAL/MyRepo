package com.igate.day2.integration;

public class Slot {

	/*
	 * Slot has information about
	 * slotNumber,vehicle to which slot is allotted,
	 * and isAllottedStatus flag. 
	 * isAllotedStatus will be true if a vehicle is allotted 
	 * to that slot or else it will be false.
	 */
	int slotNumber;
	boolean isAllottedStatus;
	Vehicle vehicle;
	
	/*
	 * Slot(int slotNumber)  
	 * Constructor to initialize Slot object. 
	 * This should also set the isAllotedStatus flag 
	 * to false and Vehicle object to null.
	 */
	public Slot(int slotNumber)
	{
		this.slotNumber=slotNumber;
		this.isAllottedStatus=false;
		this.vehicle=null;
	}

	/*
	 * Getter/Setter methods for all variables
	 */
	public void setVehicle(Vehicle vehicle)
	{
		this.vehicle=vehicle;
	}

	public int getSlotNumber() {
		return slotNumber;
	}

	public void setSlotNumber(int slotNumber) {
		this.slotNumber = slotNumber;
	}

	public boolean isAllottedStatus() {
		return isAllottedStatus;
	}

	public void setAllottedStatus(boolean isAllottedStatus) {
		this.isAllottedStatus = isAllottedStatus;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}
	

}

package com.igate.day2.integration;

import java.util.ArrayList;

public abstract class Parking {
	String parkingName;
	int slotCount; //total number of slots
	Slot[] slots; //list of slots
	Vehicle[] vehicles; //list of vehicles
	static int totalamt;

	/*
	 * Constructor to create slots in parking
	 */
	public Parking(String parkingName,int slotCount)
	{
		this.parkingName=parkingName;
		this.slotCount=slotCount;
		slots=new Slot[slotCount];
		vehicles=new Vehicle[slotCount];
		
		//slot index should start from 1
		for(int i=1;i<=slotCount;i++)
		{
			//array index always start from 0
			slots[i-1]=new Slot(i);
		}
	}
	
	//abstract method to calculate charges
	public abstract void calculateCharges();
	
	
	/*
	 * Method to check whether a slot is free
	 */
	public Slot getFreeSlot() 
	{
		for(Slot slot:slots)
		{
			if(!slot.isAllottedStatus)
			{
				return slot;
			}
		}
		return null;
	}
	
	
	/*
	 * Tasks to be done when vehicle arrives
	 */
		
	
	public int vehicleDeparture(String vehRegNo)
	{
		for(Slot slot:slots)
		{
			
			//removing vehicle from list if it is departed
			 for(int index=0;index<vehicles.length;index++)
			 {
				 if(vehicles[index]!=null)
				 {
				 if(vehRegNo.equals(vehicles[index].getVehRegNo()))
				 vehicles[index]=null;
				 }
			 }
			
			if(slot.getVehicle().getVehRegNo().equals(vehRegNo))
			{
			 //making slot empty when vehicle departs	
			 slot.setVehicle(null);
			 slot.setAllottedStatus(false);
			 
			 for(Vehicle v:vehicles)
			 {
				 if(v!=null)
				 {
			 	if (v.waitStatus)
				{
			 		slot.setVehicle(v);
					slot.setAllottedStatus(true);
					v.setWaitStatus(false);
				}
			 }	 
		}
			 return 1;
			}
		}	
		return -1;
	}
	
	/*
	 * Method to check whether a slot is free
	 */
	
	public Vehicle findVehicle(String vehRegNo)
	{
		for(Vehicle veh:vehicles)
		{
			if(veh.getVehRegNo().equals(vehRegNo))
			{	
				return veh;
			}
		}
		return null;
	}
	
	
	public void vehicleArrival(String vehRegNo,String arrivalTime)
	{
		Vehicle newVehicle=new Vehicle(vehRegNo,arrivalTime);
		
		//Add vehicle entry at first empty position
		 for(int index=0;index<vehicles.length;index++)
		 {
			 if(vehicles[index]==null)
			 {
			 vehicles[index]=newVehicle;
			 break;
			 }
		 }

		//Search for free slot for the vehicle
		Slot free=getFreeSlot();
		
		if(free==null)
		{
			newVehicle.setWaitStatus(true); //requesting vehicle to wait
			System.out.println("Vehicle waiting: "+ vehRegNo);
		}
		else
		{
			calculateCharges();
			free.setVehicle(newVehicle); //allocate free slot to the new vehicle
			free.setAllottedStatus(true); //mark slot as allocated
		}
	}
	
	
	public Vehicle getVehicleOnSlot(int slotNumber)
	{
		for(Slot slot:slots)
		{
			if(slot.getSlotNumber()==slotNumber)
			{
				return slot.getVehicle();
			}
		}
		return null;
	}
	
	public Slot getAllotedSlot(String vehRegNo)
	{
		for(Slot slot:slots)
		{
			if(slot.getVehicle().getVehRegNo().equals(vehRegNo))
			{
				return slot;
			}
		}
		return null;
	}
}
package com.igatepatni.lesson7;

import java.io.*;

public class CopyCharacters {
	public static void main(String[] args) {
		FileReader inputStream = null;
		FileWriter outputStream = null;
		try {
			inputStream = new FileReader("sampleinput.txt");
			outputStream = new FileWriter("sampleoutput.txt");
			int c;
			while ((c = inputStream.read()) != -1) {
				outputStream.write(c);
			}

			if (inputStream != null)
				inputStream.close();
			if (outputStream != null)
				outputStream.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

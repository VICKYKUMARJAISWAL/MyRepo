package com.igatepatni.lesson7;

import java.io.*;

class stud implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int roll;
	String sname;

	public stud(int r, String s) {
		roll = r;
		sname = s;
	}

	public String toString() {
		return "Roll no is : " + roll + "   Name is : " + sname;
	}
}
package com.igatepatni.lesson7;

import java.io.*;

public class ObjectIOStreamdemo {
	public static void main(String args[]) {
		try {
			stud s1 = new stud(100, "Varsha");
			System.out.println("s1 object : " + s1);

			FileOutputStream fos = new FileOutputStream("student");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(s1);
			oos.flush();
			oos.close();
		} catch (Exception e) {
		}

		try {
			stud s2;
			FileInputStream fis = new FileInputStream("student");
			ObjectInputStream ois = new ObjectInputStream(fis);
			s2 = (stud) ois.readObject();
			ois.close();
			System.out.println("s2 object : " + s2);
		} catch (Exception e) {
		}
	}
}

/* This program works well
 * Change is made only in Parking.java
 * 
 */
package com.igate.day5.file.integration.presentation;

import java.io.IOException;

import com.igate.day5.file.integration.businesslogic.*;
import com.igate.day5.file.integration.exception.*;
import com.igate.day5.file.integration.service.IParking;
import com.igate.day5.file.integration.service.IParkingImpl;

public class Client {

	// Gets slot number of first free slot
	public static void which_slot_is_free(IParking park) {
		if (park.getFreeSlot() != null) {
			System.out.println("First Free slots available is"
					+ park.getFreeSlot().getSlotNumber());
		} else {
			System.out.println("No slot is currently available");
		}
	}

	// prints which car is parked at what slot
	public static void where_are_cars(IParking park) throws IOException, ClassNotFoundException {
		for (int i = 0; i < 100; i++) {
			Vehicle v = park.getVehicleOnSlot(i + 1);
			if (v != null)
				System.out.println("Vehicle Details are : "
						+ park.getVehicleOnSlot(i + 1) + " is on slot no. "
						+ (i + 1));
		}
	}

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws VehicleNotParkedException, IOException {
		// TODO Auto-generated method stub
		/*
		 * Following is the new code
		 * please compare it with the previous code
		 *  
		*/
		IParkingImpl ipi=new IParkingImpl();
		IParking park1 = ipi.getVisitorObj("Visitor", 80);
		IParking park2 = ipi.getStaffObj("Staff", 20);
		
		System.out.println("Total number of slots available for visitors"
				+ park1.getSlotCount());
		System.out.println("Total number of slots available for staff"
				+ park2.getSlotCount());
		System.out.println("----------------------------------------------");

		which_slot_is_free(park1);

		// Two vehicles are arriving and we are checking for first free slot
		try {
			park1.vehicleArrival("MH04 BT4585", "0800");
		} catch (NoParkingAvailableException e) {
			// TODO Auto-generated catch block
			System.err.println("No place available for " + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("----------------------------------------------");

		which_slot_is_free(park1);

		System.out.println("----------------------------------------------");

		try {
			park2.vehicleArrival("MH43 AL8849", "0900");
		} catch (NoParkingAvailableException e) {
			// TODO Auto-generated catch block
			System.err.println("No place available for" + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		which_slot_is_free(park2);

		System.out
				.println("--------------------------------------------------");
		System.out.println("Vehicle no. and slot no.");

		System.out.println("Visitors IParking status");
		try {
			where_are_cars(park1);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		System.out
				.println("--------------------------------------------------");
		System.out.println("Staff IParking status");

		try {
			where_are_cars(park2);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// second vehicle is leaving and we are checking for vacant slot
		// park.vehicleDeparture("MH43 AL8849");
		try {
			park1.vehicleDeparture("MH04 BT4585");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("Vehicle departing........");

		which_slot_is_free(park1);

		System.out
				.println("--------------------------------------------------");

		try {
			park1.vehicleArrival("MH43 PM9999", "2000");
		} catch (NoParkingAvailableException e) {
			// TODO Auto-generated catch block
			System.err.println("No place available for " + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Vehicle no. and slot no.");
		System.out.println("Visitors IParking status");
		try {
			where_are_cars(park1);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			park2.vehicleArrival("MH43 TL9999", "1900");
		} catch (NoParkingAvailableException e) {
			// TODO Auto-generated catch block
			System.err.println("No place available for" + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out
				.println("--------------------------------------------------");
		System.out.println("Staff IParking status");
		try {
			where_are_cars(park2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out
				.println("--------------------------------------------------");
		/*
		 * Previous code:
		 * System.out.println("Total charges are " + IParking.getTotalAmt());
		 */
		System.out.println("Total charges are " + park1.getTotalAmt());

		System.out.println("Finding whether vehicle is parked ....");
		try {
			Vehicle vehicle2 = park2.findVehicle("MH43 AL8849");
			if (vehicle2 != null)
				System.out.println(vehicle2);
			else
				throw new VehicleNotParkedException("MH43 AL8849");
			Vehicle vehicle1 = park1.findVehicle("MH05 BT4585");
			if (vehicle1 != null)
				System.out.println(vehicle1);
			else
				throw new VehicleNotParkedException("MH05 BT4585");

		} catch (VehicleNotParkedException ex_vehicle) {
			System.err.print("Error :Vehicle no " + ex_vehicle.getMessage()
					+ " is not in our IParking");
		}
	}
}
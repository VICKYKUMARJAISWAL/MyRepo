package com.igate.day5.file.integration.service;

import java.io.IOException;

import com.igate.day5.file.integration.businesslogic.Parking;
import com.igate.day5.file.integration.businesslogic.Slot;
import com.igate.day5.file.integration.businesslogic.Staff;
import com.igate.day5.file.integration.businesslogic.Vehicle;
import com.igate.day5.file.integration.businesslogic.Visitor;
import com.igate.day5.file.integration.exception.NoParkingAvailableException;
import com.igate.day5.file.integration.exception.VehicleNotParkedException;

public class IParkingImpl implements IParking {

	
	public IParkingImpl() {

	}

	@Override
	public void calculateCharges() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Vehicle findVehicle(String vehRegNo)
			throws VehicleNotParkedException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Slot getAllotedSlot(String vehRegNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Slot getFreeSlot() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getSlotCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getTotalAmt() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Vehicle getVehicleOnSlot(int slotNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void vehicleArrival(String vehRegNo, String arrivalTime)
			throws NoParkingAvailableException {
		// TODO Auto-generated method stub

	}

	@Override
	public int vehicleDeparture(String vehRegNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public Visitor getVisitorObj(String str,int cnt) throws IOException
	{
		IParking park1 = Visitor.getVisitorObj(str, cnt);
		return (Visitor) park1;
	}
	
	public Staff getStaffObj(String str,int cnt) throws IOException
	{
	IParking park2 = Staff.getStaffObj("Staff", 20);
	return (Staff) park2;
	}
}

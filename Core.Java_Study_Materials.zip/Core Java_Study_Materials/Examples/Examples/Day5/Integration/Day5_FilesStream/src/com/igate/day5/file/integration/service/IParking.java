package com.igate.day5.file.integration.service;

import java.io.IOException;

import com.igate.day5.file.integration.businesslogic.Slot;
import com.igate.day5.file.integration.businesslogic.Vehicle;
import com.igate.day5.file.integration.exception.NoParkingAvailableException;
import com.igate.day5.file.integration.exception.VehicleNotParkedException;
/*
 * Design Steps for the Service Layer
The approach used to design a service layer starts by defining 
the service interface, which consists of the contracts that you plan 
to expose from your service. This is commonly referred to as Contract 
First Design. 
Once the service interface has been defined, the next step is to design
 the service implementation; which is used to translate data contracts 
 into business entities and to interact with the business layer. 
 The following basic steps can be used when designing a service layer:

1.Define the data and message contracts that represent the schema used for messages.
2.Define the service contracts that represent operations supported by your service. 
3.Define the fault contracts that return error information to consumers of the service.
4.Design transformation objects that translate between business entities and data contracts.
5.Design the abstraction approach used to interact with the business layer.
You can use design tools such as the patterns & practices Web Service Software Factory: Modeling Edition (also known as the Service Factory) to generate Web services. This is an integrated collection of resources designed to help you quickly and consistently build Web services that adhere to well-known architecture and design patterns

 */
public interface IParking {
//Contract
	//by default, method declarations in interface are public abstract
	//it can not be static.
	void calculateCharges();
	Slot getFreeSlot();
	int vehicleDeparture(String vehRegNo) throws IOException, ClassNotFoundException;
	Vehicle findVehicle(String vehRegNo) throws VehicleNotParkedException;
	void vehicleArrival(String vehRegNo,String arrivalTime) throws NoParkingAvailableException, IOException;
	Vehicle getVehicleOnSlot(int slotNumber) throws IOException, ClassNotFoundException;
	Slot getAllotedSlot(String vehRegNo) throws IOException, ClassNotFoundException;
	int getSlotCount();
	int getTotalAmt();
}

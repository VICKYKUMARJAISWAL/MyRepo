package com.igate.day5.file.integration.businesslogic;
import com.igate.day5.file.integration.exception.*;
import com.igate.day5.file.integration.service.IParking;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Set;
import java.util.TreeMap;

public abstract class Parking implements IParking{
	String parkingName;
	public int slotCount; //total number of slots
	
	//For getting Sorted data, TreeMap is used.
	   TreeMap<Integer,Slot> slots;
	   TreeMap<Integer,Vehicle> vehicles;
	   public static int totalamt;

	   //Now we also need to write into a file as well as read from file and we would be writing
	   //and reading OBJECTS.
	   ObjectInputStream objectInputStream;
	   ObjectOutputStream objectOutputStream;
	   FileInputStream fileInputStream;
	   FileOutputStream fileOutputStream;
	   
	   
	/*
	 * Constructor to create slots in parking
	 */
	public Parking(String parkingName,int slotCount) throws IOException
	{
		this.parkingName=parkingName;
		this.slotCount=slotCount;
		slots=new TreeMap<Integer,Slot>();
		vehicles=new TreeMap<Integer,Vehicle>();
		for(int i=0;i<slotCount;i++)
		{
			slots.put(i+1,new Slot(i+1));
			vehicles.put(i+1,new Vehicle());
		}
		
	}
	
	//abstract method to calculate charges
	//public abstract void calculateCharges();
	//above declaration is now removed and is in interface IParking
	
	/*
	 * Method to check whether a slot is free
	 */
	public Slot getFreeSlot() 
	{
		Set<Integer> keys= slots.keySet();
		for(int key:keys)
		{
			Slot slot=slots.get(key);
			if(!slot.isAllottedStatus)
			{
				return slot;
			}
		}
		return null;
	}
	
	
	/*
	 * Tasks to be done when vehicle departs
	 */
	public int vehicleDeparture(String vehRegNo) throws IOException, ClassNotFoundException
	{
		//Reading treemap object from the file
		fileInputStream=new FileInputStream("records.obj");
		objectInputStream=new ObjectInputStream(fileInputStream);
		TreeMap<Integer,Slot> slots=(TreeMap<Integer,Slot>)(objectInputStream.readObject());
		objectInputStream.close();
		fileInputStream.close();
		Set<Integer> keys= slots.keySet();
		for(int key:keys)
		{
			//Type casting necessary
			Slot slot=(Slot) slots.get(key);
			
			Set<Integer> key_vehicle=vehicles.keySet();
			for(int key_v:key_vehicle)
			{
				Vehicle vehicle=vehicles.get(key_v);
				if(vehicle!=null)
				{
				if(vehRegNo.equals(vehicle.getVehRegNo()))
					vehicles.put(slot.getSlotNumber(), new Vehicle());
				} else
					try {
						throw new VehicleNotParkedException(vehRegNo);
					} catch (VehicleNotParkedException e) {
						// TODO Auto-generated catch block
						System.err.print(vehRegNo +" Not in parking");
					}
			}
			
			
			if(slot!=null && slot.getVehicle()!=null && slot.getVehicle().getVehRegNo().equals(vehRegNo))
			{
			 //making slot empty when vehicle departs	
			 slot.setVehicle(null);
			 slot.setAllottedStatus(false);
			
			
			 Set<Integer> key_veh=vehicles.keySet();
				for(int key_v:key_veh)
				{
					Vehicle vehicle=vehicles.get(key_v);
					if(vehRegNo.equals(vehicle.getVehRegNo()))
						vehicles.put(new Integer(key_v), null);
				}
				Set<Integer> key_vehicle1=vehicles.keySet();
				for(int key_v:key_vehicle1)
				{
					Vehicle v=vehicles.get(key_v);
					if(v!=null)
					 {
						if (v.waitStatus)
						{
				 		slot.setVehicle(v);
						slot.setAllottedStatus(true);
						v.setWaitStatus(false);
						}   
					 }
				}
				fileOutputStream=new FileOutputStream("records.obj");
				objectOutputStream=new ObjectOutputStream(fileOutputStream);
				objectOutputStream.writeObject(slots);
				objectOutputStream.close();
				fileOutputStream.close();
			 return 1;
			}
		}	
		return -1;
	}
	
	/*
	 * Method to check whether a slot is free
	 */
	
	public Vehicle findVehicle(String vehRegNo) throws VehicleNotParkedException
	{
		Set<Integer> key_veh=vehicles.keySet();
		for(int key_v:key_veh)
		{
			
			Vehicle veh=vehicles.get(key_v);
			//System.err.println(veh);
			
			if (veh==null)
				throw new VehicleNotParkedException(vehRegNo);
			else if(veh.getVehRegNo()!=null && veh.getVehRegNo().equals(vehRegNo))
			{	
				//System.err.println("FOUND :"+veh);
				return veh;
				
			}
		}
		return null;
	}
	
	//search if slot is available,
	//if slot is available, put vehicle in it.
	//some more exceptions added in throws list
	public void vehicleArrival(String vehRegNo,String arrivalTime) throws NoParkingAvailableException, IOException
	{
		Vehicle newVehicle=new Vehicle(vehRegNo,arrivalTime);
		
		//Add vehicle entry at first empty position
		Slot free=getFreeSlot();
		
		if(free==null)
		{
			newVehicle.setWaitStatus(true); //requesting vehicle to wait
			System.out.println("Vehicle waiting: "+ vehRegNo);
			throw new NoParkingAvailableException(vehRegNo);
		}
		else
		{
			//adding vehicle in TreeMap here:
			vehicles.put(free.getSlotNumber(), newVehicle);
			calculateCharges();
			free.setVehicle(newVehicle); //allocate free slot to the new vehicle
			free.setAllottedStatus(true); //mark slot as allocated
			/*
			 * Writing object here
			 */
			slots.put(free.getSlotNumber(),free);
			fileOutputStream=new FileOutputStream("records.obj");
			objectOutputStream=new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(slots);
			objectOutputStream.close();
			fileOutputStream.close();
		}
	}
	
	
	//To get slot occupation information
	//some more exceptions added in throws list
	public Vehicle getVehicleOnSlot(int slotNumber) throws IOException, ClassNotFoundException
	{
		//Reading treemap object from the file
		fileInputStream=new FileInputStream("records.obj");
		objectInputStream=new ObjectInputStream(fileInputStream);
		TreeMap<Integer,Slot> slots=(TreeMap<Integer,Slot>)(objectInputStream.readObject());
		objectInputStream.close();
		Set<Integer> keys= slots.keySet();
		for(int key:keys)
		{
			//Now typecasting is required, as get method will return object
			Slot slot=(Slot)slots.get(key);if(slot.getSlotNumber()==slotNumber)
			{
				return slot.getVehicle();
			}
		}
		return null;
	}
		
	//Getting slot number by providing vehicle number
	//some more exceptions added in throws list
	public Slot getAllotedSlot(String vehRegNo) throws IOException, ClassNotFoundException
	{
		//Reading treemap object from the file
		fileInputStream=new FileInputStream("records.obj");
		objectInputStream=new ObjectInputStream(fileInputStream);
		TreeMap<Integer,Slot> slots=(TreeMap<Integer,Slot>)(objectInputStream.readObject());
		objectInputStream.close();
		fileInputStream.close();
		Set<Integer> keys= slots.keySet();
		for(int key:keys)
		{
			//Now typecasting is required, as get method will return object
			Slot slot=(Slot)slots.get(key);
			if(slot.getVehicle().getVehRegNo().equals(vehRegNo))
			{
				return slot;
			}
		}
		return null;
		}
	
	
	    public int getSlotCount()
	    {
	    	return slotCount;
	    }
	    
	    public int getTotalAmt()
	    {
	    	return totalamt;
	    }
	    
}
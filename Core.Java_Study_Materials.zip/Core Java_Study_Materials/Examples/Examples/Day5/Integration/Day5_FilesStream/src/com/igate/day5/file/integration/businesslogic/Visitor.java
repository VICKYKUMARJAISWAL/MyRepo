package com.igate.day5.file.integration.businesslogic;

import java.io.IOException;

public class Visitor extends Parking {

	/*
	 * Declaring required static variables and method
	 */
	
	static Visitor visitor;
	
	public static Visitor getVisitorObj(String parkingName,int slotCount) throws IOException
	{
		//Creating object only if no object is available
		if (visitor==null)
			visitor=new Visitor(parkingName,slotCount);
		
		return visitor;
	}

	private Visitor(String parkingName, int slotCount) throws IOException {
		super(parkingName, slotCount);
		// TODO Auto-generated constructor stub
	}

	public void calculateCharges() {
		// TODO Auto-generated method stub
		totalamt=totalamt+10;
	}
}

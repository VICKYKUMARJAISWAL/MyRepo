package com.igatepatni.lesson11;

import java.io.File;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class TransformerDemo {

	public static void main(String[] args) {
		
		TransformerFactory tfactory;
		tfactory = TransformerFactory.newInstance();
		// Get the in and out file

		try {

			StreamSource in = new StreamSource(new File("books.xml"));
			StreamSource xsl = new StreamSource(new File("books.xsl"));
			StreamResult out = new StreamResult(new File("output.html"));
			Transformer xform = tfactory.newTransformer(xsl);
			xform.transform(in, out);

			System.exit(0);
		} catch (TransformerConfigurationException ex) {
			System.err.println(ex.getMessage());
		} catch (TransformerException ex) {
			System.err.println(ex.getMessage());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		System.exit(1);

	}

}

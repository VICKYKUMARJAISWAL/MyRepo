package com.igatepatni.lesson11;
import org.w3c.dom.*;

import javax.xml.parsers.*; 
import javax.xml.transform.*; 
import javax.xml.transform.dom.DOMSource; 
import javax.xml.transform.stream.StreamResult; 


public class CreateDOMXML 
{
  public static void main(String[] args) 
  {
    try{
    //Create instance of DocumentBuilderFactory
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    //Get the DocumentBuilder
    DocumentBuilder docBuilder = factory.newDocumentBuilder();
    //Create blank DOM Document
        Document doc = docBuilder.newDocument();

    //create the root element
        Element root = doc.createElement("root");
    //all it to the xml tree
        doc.appendChild(root);
    
      //create a comment
      Comment comment = doc.createComment("This is comment");
      //add in the root element
      root.appendChild(comment);

    //create child element
    Element childElement = doc.createElement("Child");
    //Add the atribute to the child
    childElement.setAttribute("attribute1","The value of Attribute 1");
    root.appendChild(childElement);
    root.normalize();
    

   TransformerFactory tranFactory = TransformerFactory.newInstance(); 
    Transformer aTransformer = tranFactory.newTransformer(); 

    Source src = new DOMSource(doc); 
    Result dest = new StreamResult(System.out); 
    aTransformer.transform(src, dest); 


    }catch(Exception e){
      System.out.println(e.getMessage());
    }


  }
} 
package com.igate.day8.jdbc.businesslogic.service;

import java.sql.SQLException;

import com.igate.day8.jdbc.businesslogic.dao.IParkingDao;
import com.igate.day8.jdbc.businesslogic.dao.ParkingDaoImpl;
import com.igate.day8.jdbc.businesslogic.pojo.Slot;
import com.igate.day8.jdbc.businesslogic.pojo.Vehicle;
import com.igate.day8.jdbc.integration.exception.NoParkingAvailableException;
import com.igate.day8.jdbc.integration.exception.VehicleNotParkedException;

public class ParkingImpl implements IParking {

	public static int totalamt;
	IParkingDao parkingDao;
	Vehicle vehicle;
	Slot slot;
	int slotCount;
	
	public int getSlotCount() {
		return slotCount;
	}

	public void setSlotCount(int slotCount) {
		this.slotCount = slotCount;
	}

	public ParkingImpl(String parkingName, int slotCount) {
		// TODO Auto-generated constructor stub
	
		parkingDao=new ParkingDaoImpl();
		parkingDao.setParkingName(parkingName);
	}

	@Override
	public void calculateCharges() {
		System.out.println("THIS METHOD MUST BE OVERRIDEN");
	}

	@Override
	public Vehicle findVehicle(String vehRegNo) {
		// TODO Auto-generated method stub
		try {
			vehicle=parkingDao.findVehicle(vehRegNo);
		} catch (VehicleNotParkedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vehicle;
	}

	@Override
	public Slot getAllotedSlot(String vehRegNo) {
		// TODO Auto-generated method stub
		slot=parkingDao.getAllocatedSlot(vehRegNo);
		return slot;
	}

	@Override
	public Slot getFreeSlot() {
		// TODO Auto-generated method stub
		slot=parkingDao.getFreeSlot();
		return slot;
	}

	@Override
	public int getTotalAmt() {
		// TODO Auto-generated method stub
		return totalamt;
	}

	@Override
	public Vehicle getVehicleOnSlot(int slotNumber) {
		// TODO Auto-generated method stub
	vehicle=parkingDao.findVehicle(slotNumber);
	return vehicle;
	}

	@Override
	public void vehicleArrival(String vehRegNo, String arrivalTime) {
		// TODO Auto-generated method stub
		try {
			Vehicle newVehicle = new Vehicle(vehRegNo, arrivalTime);

			// Add vehicle entry at first empty position
			Slot free = getFreeSlot();

			if (free == null) {
				newVehicle.setWaitStatus(true); // requesting vehicle to wait
				System.out.println("Vehicle waiting: " + vehRegNo);
				throw new NoParkingAvailableException(vehRegNo);
			} else {
				calculateCharges();
				parkingDao.insertVehicle(newVehicle);
				free.setVehicle(newVehicle); // allocate free slot to the new vehicle
				free.setAllottedStatus(true); // mark slot as allocated
				parkingDao.insertSlot(free);
			}
		} catch (NoParkingAvailableException e1) {
			System.err.println(e1.getMessage());
		} 
		
	}

	@Override
	public void vehicleDeparture(String vehRegNo) {
		// TODO Auto-generated method stub
		int cnt = 0;
		cnt=parkingDao.makeSlotFree(vehRegNo);
		cnt=parkingDao.deleteVehicle(vehRegNo);
		if (cnt == 0) {
			try {
				throw new VehicleNotParkedException(
						"Please check Vehicle no. This vehicle not in parking");
			} catch (VehicleNotParkedException e) {
				// TODO Auto-generated catch block
				System.err.println(e.getMessage());
			}
		}

	}

		
	@Override
	public void getStaffCars() {
		// TODO Auto-generated method stub
		parkingDao.getStaffCars();
	}

	@Override
	public void getVisitorCars() {
		// TODO Auto-generated method stub
		parkingDao.getVisitorCars();
	}

	public String getParkingName() {
		// TODO Auto-generated method stub
		return parkingDao.getParkingName();
	}

	
}

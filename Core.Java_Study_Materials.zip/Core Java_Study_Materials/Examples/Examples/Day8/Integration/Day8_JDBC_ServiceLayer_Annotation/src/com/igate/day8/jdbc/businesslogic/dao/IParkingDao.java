package com.igate.day8.jdbc.businesslogic.dao;

import com.igate.day8.annotations.IGate_ClassInfo;
import com.igate.day8.annotations.IGate_MethodInfo;
import com.igate.day8.jdbc.businesslogic.pojo.Slot;
import com.igate.day8.jdbc.businesslogic.pojo.Vehicle;
import com.igate.day8.jdbc.integration.exception.VehicleNotParkedException;

@IGate_ClassInfo(author="Pravin Surve",
		childHierarchyInfo="ParkingDaoImpl implements this interface",
		purpose="It has method declaraion for methods to be" +
"implemented in DAO, i.e. for data access")
public interface IParkingDao {

	@IGate_MethodInfo(purpose="To insert data from Vehicle object to" +
			" vehicle database table. It is done when a vehicle is " +
	"allocated some slot")
	int insertVehicle(Vehicle vehicle);

	@IGate_MethodInfo(purpose="To insert data from Slot object to" +
			" slot database table. It is done when a vehicle is " +
	"allocated some slot")
	int insertSlot(Slot slot);

	@IGate_MethodInfo(purpose="To search a vehicle in database when" +
	"vehicle registration number is provided")
	Vehicle findVehicle(String vehRegNo) throws VehicleNotParkedException;

	@IGate_MethodInfo(purpose="To search a vehicle in database when" +
	"SLOT number is provided")
	Vehicle findVehicle(int slot);

	@IGate_MethodInfo(purpose="To find first vacant slot where vehicle" +
	" can be allocated")
	Slot getFreeSlot();

	@IGate_MethodInfo(purpose="To search a SLOT in database when" +
	"vehicle registration number is provided")
	Slot getAllocatedSlot(String vehRegNo);

	@IGate_MethodInfo(purpose="On departure of vehicle, slot must be made" +
	" vacant. It is done by this method")
	int makeSlotFree(String vehRegNo);

	@IGate_MethodInfo(purpose="This to delete a vehicle entry from " +
	"vehicle database when vehicle departs")
	int deleteVehicle(String vehRegNo);

	@IGate_MethodInfo(purpose="To find out count of total free slots")
	int getFreeSlotCount();

	@IGate_MethodInfo(purpose="To get all cars parked in Visitor parking")
	void getVisitorCars();

	@IGate_MethodInfo(purpose="To get all cars parked in Staff parking")
	void getStaffCars();

	@IGate_MethodInfo(purpose="To find which object is invoking " +
	"some method, whether park1 object or park2 object")
	String getParkingName();

	@IGate_MethodInfo(purpose="To set parking name in DAO class, after retrieving " +
	"it from Client")
	void setParkingName(String parkingName);
}

package com.igate.day8.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface IGate_MethodInfo {
	String author() default "Pravin";
	String purpose();
	String[] paramList() default {};
	String returnType() default "void";
	int totalParams() default 0;
	String calledFrom() default "";
}

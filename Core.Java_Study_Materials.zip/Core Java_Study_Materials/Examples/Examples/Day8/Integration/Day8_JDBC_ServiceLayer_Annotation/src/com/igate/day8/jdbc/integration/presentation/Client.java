package com.igate.day8.jdbc.integration.presentation;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import com.igate.day8.jdbc.businesslogic.pojo.Staff;
import com.igate.day8.jdbc.businesslogic.pojo.Vehicle;
import com.igate.day8.jdbc.businesslogic.pojo.Visitor;
import com.igate.day8.jdbc.businesslogic.service.ParkingImpl;
import com.igate.day8.jdbc.integration.exception.*;

public class Client {

	static Properties properties = new Properties();

	public Client() throws IOException {
		FileInputStream fileinputstream = new FileInputStream(
				"vehicle.properties");
		properties.load(fileinputstream);
	}

	// Gets slot number of first free slot
	public static void which_slot_is_free(ParkingImpl park) {
		if (park.getFreeSlot() != null) {
			System.out.println("First Free slots available is"
					+ park.getFreeSlot().getSlotNumber());
		} else {
			System.out.println("No slot is currently available");
		}
	}

	// prints which car is parked at what slot
	public static void where_are_cars(ParkingImpl park) 
	{
		if(park.getParkingName().trim().equalsIgnoreCase("Visitor"))
		park.getVisitorCars();
		else
			park.getStaffCars();
	}
	
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 */
	public static void main(String[] args) throws VehicleNotParkedException,
			IOException, SQLException {
		// TODO Auto-generated method stub
		/*
		 * Following is the new code please compare it with the previous code
		 */

		Client client = new Client();
		ParkingImpl park1 = Visitor.getVisitorObj("Visitor", 80);
		ParkingImpl park2 = Staff.getStaffObj("Staff", 20);

		System.out.println("Total number of slots available for visitors"
				+ park1.getSlotCount());
		System.out.println("Total number of slots available for staff"
				+ park2.getSlotCount());
		System.out.println("----------------------------------------------");

		which_slot_is_free(park1);

		park1.vehicleArrival(properties.getProperty("first_vehicle"), "0800");
		System.out.println("----------------------------------------------");

		which_slot_is_free(park1);

		System.out.println("----------------------------------------------");

		park2.vehicleArrival(properties.getProperty("second_vehicle"), "0900");
		which_slot_is_free(park2);

		System.out
				.println("--------------------------------------------------");
		System.out.println("Vehicle no. and slot no.");

		System.out.println("Visitors IParking status");
		where_are_cars(park1);

		System.out
				.println("--------------------------------------------------");
		System.out.println("Staff IParking status");

		where_are_cars(park2);
		park1.vehicleDeparture("MH04 BT4585");
		System.out.println("Vehicle departing........");

		which_slot_is_free(park1);

		System.out
				.println("--------------------------------------------------");

		park1.vehicleArrival(properties.getProperty("third_vehicle"), "2000");
		System.out.println("Vehicle no. and slot no.");
		System.out.println("Visitors IParking status");
		where_are_cars(park1);

		park2.vehicleArrival("MH43 TL9999", "1900");
		System.out
				.println("--------------------------------------------------");
		System.out.println("Staff IParking status");
		where_are_cars(park2);
		System.out
				.println("--------------------------------------------------");

		System.out.println("Total charges are " + park1.getTotalAmt());

		System.out.println("Finding whether vehicle is parked ....");
		try {
			Vehicle vehicle2 = park2.findVehicle("MH43 AL8849");
			if (vehicle2 != null)
				System.out.println(vehicle2);
			else
				throw new VehicleNotParkedException("MH43 AL8849");
			Vehicle vehicle1 = park1.findVehicle("MH05 BT4585");
			if (vehicle1 != null)
				System.out.println(vehicle1);
			else
				throw new VehicleNotParkedException("MH05 BT4585");

		} catch (VehicleNotParkedException ex_vehicle) {
			System.err.print("Error :Vehicle no " + ex_vehicle.getMessage()
					+ " is not in our IParking");
		}
	}
}
package com.igate.day8.jdbc.integration.exception;

public class NoParkingAvailableException extends Exception {

	String message;

	public NoParkingAvailableException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}

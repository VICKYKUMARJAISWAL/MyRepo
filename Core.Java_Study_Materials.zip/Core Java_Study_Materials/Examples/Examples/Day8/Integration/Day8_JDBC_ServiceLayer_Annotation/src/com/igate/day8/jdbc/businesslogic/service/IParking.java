package com.igate.day8.jdbc.businesslogic.service;

import java.sql.SQLException;

import com.igate.day8.jdbc.businesslogic.pojo.Slot;
import com.igate.day8.jdbc.businesslogic.pojo.Vehicle;
import com.igate.day8.jdbc.integration.exception.NoParkingAvailableException;
import com.igate.day8.jdbc.integration.exception.VehicleNotParkedException;

public interface IParking {
	public Slot getFreeSlot();
	public void vehicleDeparture(String vehRegNo);
	public Vehicle findVehicle(String vehRegNo);
	public Vehicle getVehicleOnSlot(int slotNumber);
	public void vehicleArrival(String vehRegNo, String arrivalTime);
	public Slot getAllotedSlot(String vehRegNo);
	public int getTotalAmt();
	public void calculateCharges();
	void getVisitorCars();
	void getStaffCars();
}

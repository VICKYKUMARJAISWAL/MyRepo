package com.igatepatni.lesson12;

import java.lang.reflect.Method;



public class AnnotationTestDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
        int total= 0;
        for (Method m : Class.forName("com.igatepatni.lesson12.SampleTest").getMethods()){    
              if (m.isAnnotationPresent(Test.class)) {
                   m.invoke(null);
                   total++; 
               } 
          }
    System.out.println("No:of:methods with Annotation :"+total); 

	}

}

package com.igatepatni.lesson12;

public class SampleTest   {
	   @Test public static void m1() { } 
	   public static void m2() { }
	   @Test
	   public static void m3() {}
	    public static void m4() { } 
	    @Test 
	   public static void m5() { }
	    public static void m6() { }
	    @Test
	    public static void m7() {}
	   public static void m8() { } 
	} 


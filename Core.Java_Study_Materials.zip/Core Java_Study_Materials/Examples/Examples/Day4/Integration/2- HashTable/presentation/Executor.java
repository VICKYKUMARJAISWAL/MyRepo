/* This program works well
 * Except, it can not search for the first free slot
 * as ArrayList is used and we are using add and remove methods on it.
 * Hence, will not work as desired if any inbetween vehicle departs
 * As we have used ArrayList and we need to write some
 * different logic if we need index.
 */
package com.igate.day4.integration.usinghashtable.presentation;

import com.igate.day4.integration.usinghashtable.businesslogic.*;
import com.igate.day4.integration.usinghashtable.exception.*;

public class Executor {

	// Gets slot number of first free slot
	public static void which_slot_is_free(Parking park) {
		if (park.getFreeSlot() != null) {
			System.out.println("First Free slots available is"
					+ park.getFreeSlot().getSlotNumber());
		} else {
			System.out.println("No slot is currently available");
		}
	}

	// prints which car is parked at what slot
	public static void where_are_cars(Parking park) {
		for (int i = 0; i < 100; i++) {
			Vehicle v = park.getVehicleOnSlot(i + 1);
			if (v != null)
				System.out.println("Vehicle Details are : "
						+ park.getVehicleOnSlot(i + 1) + " is on slot no. "
						+ (i + 1));
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws VehicleNotParkedException {
		// TODO Auto-generated method stub
		/*
		 * Objects cannot be created using following statements Parking
		 * park1=new Visitor("Visitor", 80); Parking park2=new
		 * Staff("Staff",20); because we have singleton classes
		 */
		Parking park1 = Visitor.getVisitorObj("Visitor", 80);
		Parking park2 = Staff.getStaffObj("Staff", 20);
		System.out.println("Total number of slots available for visitors"
				+ park1.slotCount);
		System.out.println("Total number of slots available for staff"
				+ park2.slotCount);
		System.out.println("----------------------------------------------");

		which_slot_is_free(park1);

		// Two vehicles are arriving and we are checking for first free slot
		try {
			park1.vehicleArrival("MH04 BT4585", "0800");
		} catch (NoParkingAvailableException e) {
			// TODO Auto-generated catch block
			System.err.println("No place available for " + e.getMessage());
		}
		System.out.println("----------------------------------------------");

		which_slot_is_free(park1);

		System.out.println("----------------------------------------------");

		try {
			park2.vehicleArrival("MH43 AL8849", "0900");
		} catch (NoParkingAvailableException e) {
			// TODO Auto-generated catch block
			System.err.println("No place available for" + e.getMessage());
		}
		which_slot_is_free(park2);

		System.out
				.println("--------------------------------------------------");
		System.out.println("Vehicle no. and slot no.");

		System.out.println("Visitors parking status");
		where_are_cars(park1);

		System.out
				.println("--------------------------------------------------");
		System.out.println("Staff parking status");

		where_are_cars(park2);
		// second vehicle is leaving and we are checking for vacant slot
		// park.vehicleDeparture("MH43 AL8849");
		park1.vehicleDeparture("MH04 BT4585");
		System.out.println("Vehicle departing........");

		which_slot_is_free(park1);

		System.out
				.println("--------------------------------------------------");

		try {
			park1.vehicleArrival("MH43 PM9999", "2000");
		} catch (NoParkingAvailableException e) {
			// TODO Auto-generated catch block
			System.err.println("No place available for " + e.getMessage());
		}
		System.out.println("Vehicle no. and slot no.");
		System.out.println("Visitors parking status");
		where_are_cars(park1);

		try {
			park2.vehicleArrival("MH43 TL9999", "1900");
		} catch (NoParkingAvailableException e) {
			// TODO Auto-generated catch block
			System.err.println("No place available for" + e.getMessage());
		}
		System.out
				.println("--------------------------------------------------");
		System.out.println("Staff parking status");
		where_are_cars(park2);
		System.out
				.println("--------------------------------------------------");
		System.out.println("Total charges are " + Parking.totalamt);

		System.out.println("Finding whether vehicle is parked ....");
		try {
			Vehicle vehicle2 = park2.findVehicle("MH43 AL8849");
			if (vehicle2 != null)
				System.out.println(vehicle2);
			else
				throw new VehicleNotParkedException("MH43 AL8849");
			Vehicle vehicle1 = park1.findVehicle("MH05 BT4585");
			if (vehicle1 != null)
				System.out.println(vehicle1);
			else
				throw new VehicleNotParkedException("MH05 BT4585");

		} catch (VehicleNotParkedException ex_vehicle) {
			System.err.print("Error :Vehicle no " + ex_vehicle.getMessage()
					+ " is not in our parking");
		}
	}
}
package com.igate.day4.integration.usinghashtable.exception;

public class NoParkingAvailableException extends Exception {

	String message;

		public NoParkingAvailableException(String message) {
		super();
		this.message = message;
	}
		public String getMessage()
		{
			return message;
		}

}

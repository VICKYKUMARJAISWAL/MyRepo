package com.igate.day4.integration.usinghashtable.exception;

public class VehicleNotParkedException extends Exception {

	String message;

	public VehicleNotParkedException(String message) {
		super();
		this.message = message;
	}

	public String getMessage()
	{
		return message;
	}	
}

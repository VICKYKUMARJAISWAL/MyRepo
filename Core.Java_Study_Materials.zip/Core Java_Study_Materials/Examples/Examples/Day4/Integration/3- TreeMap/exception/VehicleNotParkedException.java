package com.igate.day4.integration.sorted.exception;

public class VehicleNotParkedException extends Exception {

	String message;

	public VehicleNotParkedException(String message) {
		super();
		this.message = message;
	}

	public String getMessage()
	{
		return message;
	}	
}

package com.igate.day4.integration.sorted.businesslogic;
import com.igate.day4.integration.sorted.exception.*;


import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

public abstract class Parking {
	String parkingName;
	public int slotCount; //total number of slots
	
	//For getting Sorted data, TreeMap is used.
	   TreeMap<Integer,Slot> slots;
	   TreeMap<Integer,Vehicle> vehicles;
	   private static int index; //to maintain key
	
	public static int totalamt;

	/*
	 * Constructor to create slots in parking
	 */
	public Parking(String parkingName,int slotCount)
	{
		this.parkingName=parkingName;
		this.slotCount=slotCount;
/*	Previous code
 *  slots=new ArrayList<Slot>();
	vehicles=new ArrayList<Vehicle>();
	for(int i=0;i<slotCount;i++)
		{
			slots.add(new Slot(i+1));
			vehicles.add(null);
		}
 */
		slots=new TreeMap<Integer,Slot>();
		vehicles=new TreeMap<Integer,Vehicle>();
		for(int i=0;i<slotCount;i++)
		{
			slots.put(i+1,new Slot(i+1));
			vehicles.put(i+1,new Vehicle());
		}
	}
	
	//abstract method to calculate charges
	public abstract void calculateCharges();
	
	
	/*
	 * Method to check whether a slot is free
	 */
	public Slot getFreeSlot() 
	{
		/* Previous code
		 * 	public Slot getFreeSlot() 
	{
		for(Slot slot:slots)
		{
			if(!slot.isAllottedStatus)
			{
				return slot;
			}
		}
		return null;
	}
	    End of previous code
	     */
		Set<Integer> keys= slots.keySet();
		for(int key:keys)
		{
			Slot slot=slots.get(key);
			if(!slot.isAllottedStatus)
			{
				return slot;
			}
		}
		return null;
	}
	
	
	/*
	 * Tasks to be done when vehicle departs
	 */
	public int vehicleDeparture(String vehRegNo)
	{
		/*
		 * Previous Code:
		 * 
			
			//removing vehicle from list if it is departed
			ArrayList<Vehicle> clone = (ArrayList<Vehicle>) ((ArrayList<Vehicle>)vehicles).clone();
			 for (Vehicle v : vehicles) {
				 if(v!=null)
					{
					if (vehRegNo.equals(v.getVehRegNo()))
						{
						clone.remove(v);
						}
					} 
				 }
			  
			 vehicles = (ArrayList<Vehicle>) clone.clone();
		
		 */
	
		Set<Integer> keys= slots.keySet();
		for(int key:keys)
		{
			Slot slot=slots.get(key);
			
			Set<Integer> key_vehicle=vehicles.keySet();
			for(int key_v:key_vehicle)
			{
				Vehicle vehicle=vehicles.get(key_v);
				if(vehicle!=null)
				{
				if(vehRegNo.equals(vehicle.getVehRegNo()))
					vehicles.put(slot.getSlotNumber(), new Vehicle());
				} else
					try {
						throw new VehicleNotParkedException(vehRegNo);
					} catch (VehicleNotParkedException e) {
						// TODO Auto-generated catch block
						System.err.print(vehRegNo +" Not in parking");
					}
			}
			
			
			if(slot.getVehicle().getVehRegNo().equals(vehRegNo))
			{
			 //making slot empty when vehicle departs	
			 slot.setVehicle(null);
			 slot.setAllottedStatus(false);
			
			 Set<Integer> key_veh=vehicles.keySet();
				for(int key_v:key_veh)
				{
					Vehicle vehicle=vehicles.get(key_v);
					if(vehRegNo.equals(vehicle.getVehRegNo()))
						vehicles.put(new Integer(key_v), null);
				}
			/* Previous code:
			 * for(Vehicle v:vehicles)
			 {
				 if(v!=null)
				 {
			 	if (v.waitStatus)
				{
			 		slot.setVehicle(v);
					slot.setAllottedStatus(true);
					v.setWaitStatus(false);
				}
			 }	 
			}
			 */
				Set<Integer> key_vehicle1=vehicles.keySet();
				for(int key_v:key_vehicle1)
				{
					Vehicle v=vehicles.get(key_v);
					if(v!=null)
					 {
						if (v.waitStatus)
						{
				 		slot.setVehicle(v);
						slot.setAllottedStatus(true);
						v.setWaitStatus(false);
						}   
					 }
				}
			 return 1;
			}
		}	
		return -1;
	}
	
	/*
	 * Method to check whether a slot is free
	 */
	
	public Vehicle findVehicle(String vehRegNo) throws VehicleNotParkedException
	{
		/* Previous code
		for(Vehicle veh:vehicles)
		{
			if (veh==null)
				throw new VehicleNotParkedException(vehRegNo);
			else if(veh.getVehRegNo().equals(vehRegNo))
			{	
				return veh;
			}
		}
		return null;
		*/
		Set<Integer> key_veh=vehicles.keySet();
		for(int key_v:key_veh)
		{
			
			Vehicle veh=vehicles.get(key_v);
			//System.err.println(veh);
			
			if (veh==null)
				throw new VehicleNotParkedException(vehRegNo);
			else if(veh.getVehRegNo()!=null && veh.getVehRegNo().equals(vehRegNo))
			{	
				//System.err.println("FOUND :"+veh);
				return veh;
				
			}
		}
		return null;
	}
	
	//search if slot is available,
	//if slot is available, put vehicle in it.
	public void vehicleArrival(String vehRegNo,String arrivalTime) throws NoParkingAvailableException
	{
		Vehicle newVehicle=new Vehicle(vehRegNo,arrivalTime);
		
		//Add vehicle entry at first empty position
		
		/*
		 * Previous code:
		 * vehicles.add(newVehicle);
		 * It was not actually adding vehicle to first empty position
		 */
		//Search for free slot for the vehicle
		Slot free=getFreeSlot();
		
		if(free==null)
		{
			newVehicle.setWaitStatus(true); //requesting vehicle to wait
			System.out.println("Vehicle waiting: "+ vehRegNo);
			throw new NoParkingAvailableException(vehRegNo);
		}
		else
		{
			//adding vehicle in TreeMap here:
			vehicles.put(free.getSlotNumber(), newVehicle);
			calculateCharges();
			free.setVehicle(newVehicle); //allocate free slot to the new vehicle
			free.setAllottedStatus(true); //mark slot as allocated
		}
	}
	
	
	//To get slot occupation information
	public Vehicle getVehicleOnSlot(int slotNumber)
	{
		/*
		 * Previous code:
		 * 	for(Slot slot:slots)
		{
			if(slot.getSlotNumber()==slotNumber)
			{
				return slot.getVehicle();
			}
		}
		return null;
		 */
		
		Set<Integer> keys= slots.keySet();
		for(int key:keys)
		{
			Slot slot=slots.get(key);if(slot.getSlotNumber()==slotNumber)
			{
				return slot.getVehicle();
			}
		}
		return null;
	}
		
	//Getting slot number by providing vehicle number
	public Slot getAllotedSlot(String vehRegNo)
	{
		/*
		 * Previous code:
		 * for(Slot slot:slots)
		{
			if(slot.getVehicle().getVehRegNo().equals(vehRegNo))
			{
				return slot;
			}
		}
		return null;
		}
		*/
		Set<Integer> keys= slots.keySet();
		for(int key:keys)
		{
			Slot slot=slots.get(key);
			if(slot.getVehicle().getVehRegNo().equals(vehRegNo))
			{
				return slot;
			}
		}
		return null;
		}
}
package com.igate.day4.integration.usingarraylist.businesslogic;

public class Vehicle {
	/*
	 * Vehicle should have information about the vehRegNo, arrivalTime and its waitStatus .
	 * waitStatus tells whether all slots are occupied or not. If all slots are occupied then the wait status need to be set as true or else false.
	 */
	String vehRegNo ;
	String arrivalTime;
	public boolean waitStatus ;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "RegNo : "+ vehRegNo + "\tarrivalTime :" +arrivalTime +"\t";
	}
	
	
	/* 
	 * public Vehicle(String vehRegNo,String arrivalTime) 
	 * Constructor to initialize Vehicle object. 
	 * This should also set its wait property to false
	 */
	public Vehicle(String vehRegNo,String arrivalTime)
	{
		this.waitStatus=false;
		this.arrivalTime=arrivalTime;
		this.vehRegNo=vehRegNo;
	}
	
	/*
	 * accessor/mutator methods for all the variables
	 */
	public String getVehRegNo() {
		return vehRegNo;
	}
	public void setVehRegNo(String vehRegNo) {
		this.vehRegNo = vehRegNo;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public boolean isWaitStatus() {
		return waitStatus;
	}
	public void setWaitStatus(boolean waitStatus) {
		this.waitStatus = waitStatus;
	}

}

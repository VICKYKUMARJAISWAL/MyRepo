package com.igate.day4.integration.usingarraylist.businesslogic;

import com.igate.day3.integration.exception.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.igate.day3.integration.exception.VehicleNotParkedException;

public abstract class Parking {
	String parkingName;
	public int slotCount; // total number of slots
	/*
	 * Instead of array in previous code, List is used here Also, generics is
	 * used to have only Slot type objects into the list Hence, this code is
	 * removed: Slot[] slots; //list of slots
	 */
	List<Slot> slots;

	/*
	 * Instead of array in previous code, List is used here Also, generics is
	 * used to have only Vehicle type objects into the list Hence, this code is
	 * removed: Vehicle[] vehicles; //list of vehicles
	 */
	List<Vehicle> vehicles;

	public static int totalamt;

	/*
	 * Constructor to create slots in parking
	 */
	public Parking(String parkingName, int slotCount) {
		this.parkingName = parkingName;
		this.slotCount = slotCount;
		/*
		 * Previous code slots=new Slot[slotCount]; vehicles=new
		 * Vehicle[slotCount];
		 * 
		 * //slot index should start from 1 for(int i=1;i<=slotCount;i++) {
		 * //array index always start from 0 slots[i-1]=new Slot(i); }
		 */
		/*
		 * slots=new ArrayList<Slot>(); vehicles=new ArrayList<Vehicle>(); is
		 * the new code
		 */
		slots = new ArrayList<Slot>();
		vehicles = new ArrayList<Vehicle>();
		for(int i=0;i<slotCount;i++)
		{
			slots.add(new Slot(i+1));
			vehicles.add(null);
		}
	}

	// abstract method to calculate charges
	public abstract void calculateCharges();

	/*
	 * Method to check whether a slot is free
	 */
	public Slot getFreeSlot() {
		for (Slot slot : slots) {
			if (!slot.isAllottedStatus) {
				return slot;
			}
		}
		return null;
	}

	/*
	 * Tasks to be done when vehicle arrives
	 */

	public int vehicleDeparture(String vehRegNo) {
		for (Slot slot : slots) {

			// removing vehicle from list if it is departed
			/*
			 * Previous code for(int index=0;index<vehicles.length;index++) {
			 * if(vehRegNo.equals(vehicles[index].getVehRegNo()))
			 * vehicles[index]=null; }
			 * 
			 * and the new code after replacement is for(Vehicle
			 * vehicle:vehicles) { if(vehRegNo.equals(vehicle.getVehRegNo()))
			 * vehicles.remove(vehicle); }
			 */
			/*
			 * Logically following code looks correct
			 * but
			 * While iterating over it 
			 * we have to remove elements at the same time. 
			 * This throws an java.util.ConcurrentModificationException
			 *for (Vehicle vehicle : vehicles) {
				if(vehicle!=null)
				{
				if (vehRegNo.equals(vehicle.getVehRegNo()))
					{
					vehicles.remove(vehicle);
					}
				}
			}
			NOTE:
			Hence, in following code, we have created clone of our array list Vehicle
			we are iterating using "vehicles", however not removing
			contents directly from "vehicles".
			removing it from "clone" and assigning "clone" to "vehicles" later.
			*/
			ArrayList<Vehicle> clone = (ArrayList<Vehicle>) ((ArrayList<Vehicle>)vehicles).clone();
			 for (Vehicle v : vehicles) {
				 if(v!=null)
					{
					if (vehRegNo.equals(v.getVehRegNo()))
						{
						clone.remove(v);
						}
					} 
				 }
			  
			 vehicles = (ArrayList<Vehicle>) clone.clone();
			 System.err.println("Just good to know.. what happens to hashcodes when you clone");
			 System.err.println("hash code for vehicles:" + vehicles.hashCode());
			 System.err.println("hash code for vehicles's clone:" + clone.hashCode());

			if (slot.getVehicle().getVehRegNo().equals(vehRegNo)) {
				// making slot empty when vehicle departs
				slot.setVehicle(null);
				slot.setAllottedStatus(false);

				for (Vehicle v : vehicles) {
					if (v != null) {
						if (v.waitStatus) {
							slot.setVehicle(v);
							slot.setAllottedStatus(true);
							v.setWaitStatus(false);
						}
					}
				}
				return 1;
			}
		}
		return -1;
	}

	/*
	 * Method to check whether a slot is free
	 */

	public Vehicle findVehicle(String vehRegNo)
			throws VehicleNotParkedException {
		// System.err.print(vehRegNo);
		for (Vehicle veh : vehicles) {
			if (veh == null)
				throw new VehicleNotParkedException(vehRegNo);
			else if (veh.getVehRegNo().equals(vehRegNo)) {
				return veh;
			}
		}
		return null;
	}

	public void vehicleArrival(String vehRegNo, String arrivalTime)
			throws NoParkingAvailableException {
		Vehicle newVehicle = new Vehicle(vehRegNo, arrivalTime);

		// Add vehicle entry at first empty position

		/*
		 * Removing old code for(int index=0;index<vehicles.length;index++) {
		 * if(vehicles[index]==null) { vehicles[index]=newVehicle; break; } }
		 * with vehicles.add(newVehicle);
		 */
		vehicles.add(newVehicle);
		// Search for free slot for the vehicle
		Slot free = getFreeSlot();

		if (free == null) {
			newVehicle.setWaitStatus(true); // requesting vehicle to wait
			System.out.println("Vehicle waiting: " + vehRegNo);
			throw new NoParkingAvailableException(vehRegNo);
		} else {
			calculateCharges();
			free.setVehicle(newVehicle); // allocate free slot to the new
											// vehicle
			free.setAllottedStatus(true); // mark slot as allocated
		}
	}

	public Vehicle getVehicleOnSlot(int slotNumber) {
		for (Slot slot : slots) {
			if (slot.getSlotNumber() == slotNumber) {
				return slot.getVehicle();
			}
		}
		return null;
	}

	public Slot getAllotedSlot(String vehRegNo) {
		for (Slot slot : slots) {
			if (slot.getVehicle().getVehRegNo().equals(vehRegNo)) {
				return slot;
			}
		}
		return null;
	}
}
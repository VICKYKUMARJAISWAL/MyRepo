package com.igate.day3.integration.exception;

public class VehicleNotParkedException extends Exception {

	String message;

	public VehicleNotParkedException(String message) {
		super();
		this.message = message;
	}

	public String getMessage()
	{
		return message;
	}	
}

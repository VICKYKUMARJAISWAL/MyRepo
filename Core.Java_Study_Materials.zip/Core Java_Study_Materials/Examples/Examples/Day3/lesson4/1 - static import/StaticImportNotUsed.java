package com.igate.lesson4;
//Math class is in lang package, hence import not required
public class StaticImportNotUsed {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Math.sqrt(27));
		System.out.println(Math.random());
		System.out.println(Math.ceil(12.1));
		System.out.println(Math.floor(12.9));
		System.out.println(Math.round(12.5));
		System.out.println(Math.pow(2,3));
	}

}

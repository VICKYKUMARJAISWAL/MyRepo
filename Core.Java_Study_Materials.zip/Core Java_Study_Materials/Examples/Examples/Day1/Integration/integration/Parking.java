package com.igate.day1.integration;

import java.util.ArrayList;

public class Parking {
	String parkingName;
	int slotCount; //total number of slots
	Slot[] slots; //list of slots
	Vehicle[] vehicles; //list of vehicles
	
	/*
	 * Constructor to create slots in parking
	 */
	public Parking(String parkingName,int slotCount)
	{
		this.parkingName=parkingName;
		this.slotCount=slotCount;
		slots=new Slot[slotCount];
		vehicles=new Vehicle[slotCount];
		
		//slot index should start from 1
		for(int i=1;i<=slotCount;i++)
		{
			//array index always start from 0
			slots[i-1]=new Slot(i);
		}
	}
	
	/*
	 * Method to check whether a slot is free
	 */
	public Slot getFreeSlot() 
	{
		for(Slot s:slots)
		{
			if(!s.isAllottedStatus)
			{
				return s;
			}
		}
		return null;
	}
	
	/*
	 * To search vehicle in list of vehicles
	 */
	public Vehicle findVehicle(String vehRegNo)
	{
		for(Vehicle v:vehicles)
		{
			if(v.getVehRegNo().equals(vehRegNo))
			{	
				return v;
			}
		}
		return null;
	}
	
	/*
	 * Tasks to be done when vehicle arrives
	 */
	public void vehicleArrival(String vehRegNo,String arrivalTime)
	{
		Vehicle newVehicle=new Vehicle(vehRegNo,arrivalTime);
		
		//Add vehicle entry at first empty position
		 for(int index=0;index<vehicles.length;index++)
		 {
			 if(vehicles[index]==null)
			 {
			 vehicles[index]=newVehicle;
			 break;
			 }
		 }

		//Search for free slot for the vehicle
		Slot free=getFreeSlot();
		
		if(free==null)
			newVehicle.setWaitStatus(true); //requesting vehicle to wait
		else
		{
			free.setVehicle(newVehicle); //allocate free slot to the new vehicle
			free.setAllottedStatus(true); //mark slot as allocated
		}
	}
	
	
	public int vehicleDeparture(String vehRegNo)
	{
		for(Slot p:slots)
		{
			
			//removing vehicle from list if it is departed
			 for(int index=0;index<vehicles.length;index++)
			 {
				 if(vehicles[index]!=null)
				 {
				 if(vehRegNo.equals(vehicles[index].getVehRegNo()))
				 vehicles[index]=null;
				 }
			 }
			
			if(p.getVehicle().getVehRegNo().equals(vehRegNo))
			{
			 //making slot empty when vehicle departs	
			 p.setVehicle(null);
			 p.setAllottedStatus(false);
			 
			 for(Vehicle v:vehicles)
			 {
				 if(v!=null)
				 {
			 	if (v.waitStatus)
				{
			 		p.setVehicle(v);
					p.setAllottedStatus(true);
					v.setWaitStatus(false);
				}
			 }	 
		}
			 return 1;
			}
		}	
		return -1;
	}
	
	public Vehicle getVehicleOnSlot(int slotNumber)
	{
		for(Slot p:slots)
		{
			if(p.getSlotNumber()==slotNumber)
			{
				return p.getVehicle();
			}
		}
		return null;
	}
	
	public Slot getAllotedSlot(String vehRegNo)
	{
		for(Slot p:slots)
		{
			if(p.getVehicle().getVehRegNo().equals(vehRegNo))
			{
				return p;
			}
		}
		return null;
	}
}
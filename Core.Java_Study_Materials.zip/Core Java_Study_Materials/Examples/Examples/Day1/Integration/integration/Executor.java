package com.igate.day1.integration;

public class Executor {

	public static void which_slot_is_free(Parking park)
	{
		if(park.getFreeSlot()!=null)
		{
			System.out.println("First Free slots available is"+ park.getFreeSlot().getSlotNumber());
		}
		else
		{
			System.out.println("No slot is currently available");
		}
	}
	
	public static void where_are_cars(Parking park)
	{
		for(int i=0;i<100;i++)
		{
			Vehicle v=park.getVehicleOnSlot(i+1);
			if(v!=null)
				System.out.println("Vehicle " + park.getVehicleOnSlot(i+1).getVehRegNo() + " is on slot no. "+ (i+1));
		}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parking park=new Parking("InOrbit", 100);
		System.out.println("Total number of slots available"+park.slotCount);
		System.out.println("----------------------------------------------");
	
		which_slot_is_free(park);
	
		//Two vehicles are arriving and we are checking for first free slot
		park.vehicleArrival("MH04 BT4585", "0800");
		System.out.println("----------------------------------------------");
	
		which_slot_is_free(park);
		
		System.out.println("----------------------------------------------");
		park.vehicleArrival("MH43 AL8849", "0900");
		
		which_slot_is_free(park);
		
		System.out.println("--------------------------------------------------");
		System.out.println("Vehicle no. and slot no.");
	
		where_are_cars(park);
		
		//second vehicle is leaving and we are checking for vacant slot
		//park.vehicleDeparture("MH43 AL8849");
		park.vehicleDeparture("MH04 BT4585");
		System.out.println("Vehicle departing........");
		
		which_slot_is_free(park);
		
		System.out.println("--------------------------------------------------");
		
		System.out.println("Vehicle no. and slot no.");
		
		where_are_cars(park);
	}
}

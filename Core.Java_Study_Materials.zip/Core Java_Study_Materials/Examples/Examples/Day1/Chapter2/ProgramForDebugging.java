
public class ProgramForDebugging {

	int a,b;
	/**
	 * This method is to be debugged
	 * Intentionally value of loop variable is changed inside loop
	 * Participants may not know about "for loop" at this stage,
	 * however instructor need to put in the picture that it is to understand 
	 * how to use debugger
	 */
	public void testMe()
	{
		for(int i=0; i<20; i++)
		{
			System.out.println("Value of i is "+ i);
			System.out.println("Value of a is "+ a);
			System.out.println("Value of b is "+ b);
			/* Put break points on below lines */
			i+=4;
			a++;
			b+=3;
			/* End of break points */
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ProgramForDebugging p4d=new ProgramForDebugging();
		p4d.testMe();
	}

}

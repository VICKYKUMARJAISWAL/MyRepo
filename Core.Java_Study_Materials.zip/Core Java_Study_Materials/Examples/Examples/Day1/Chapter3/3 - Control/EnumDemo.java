package com.igate.lesson3;

enum Apple {
	Jonathan(10, 12), GoldenDel(9, 12), RedDel(12, 5), Winesap(15, 7), Cortland(
			8, 10);

	private int price; // price of each apple 
	private int qty;

	// Constructor 
	Apple(int p, int x) {
		price = p;
		qty = x;
	}

	int getQty() {
		return qty;
	}

	int getPrice() {
		return price;
	}
}

class EnumDemo {
	public static void main(String args[]) {
	// Display price of Winesap. 
		System.out.println("Winesap costs " + Apple.Winesap.getPrice()
				+ " cents.\n" + Apple.Winesap.getQty());

		// Display all apples and prices. 
		System.out.println("All apple prices:");
		for (Apple a : Apple.values())
			System.out.println(a + " costs " + a.getPrice() + " cents."
					+ "Qty available" + a.getQty());
	}
}

package com.igate.lesson3;

import java.util.ArrayList;
import java.util.Vector;

public class InstanceofExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object testObject = new Vector();
	    if (testObject instanceof Vector)
	      System.out.println("Object was an instance of the class java.util.Vector");
	    else if (testObject instanceof ArrayList)
	      System.out.println("Object was an instance of the class java.util.ArrayList");
	    else
	      System.out.println("Object was an instance of the " + testObject.getClass());

	  
	}

}

package com.igate.lesson3;

public class AllDataTypesInJava {

	byte byte_var;
	short short_var;
	int int_var;
	long long_var;
	float float_var;
	double double_var;
	char char_var;
	boolean boolean_var;

	public AllDataTypesInJava() {
		// TODO Auto-generated constructor stub
		System.out.println("Default values are ::==>");
		System.out.println("default value of 'byte' is  ::==>" + byte_var);
		System.out.println("default value of 'short' is  ::==>" + short_var);
		System.out.println("default value of 'int' is  ::==>" + int_var);
		System.out.println("default value of 'long' is  ::==>" + long_var);
		System.out.println("default value of 'float' is  ::==>" + float_var);
		System.out.println("default value of 'double' is  ::==>" + double_var);
		System.out.println("default value of 'char' is  ::==>" + char_var);
		System.out.println("default value of 'boolean' is  ::==>" + boolean_var);
		
		System.out.println("----------------------------------------------------------");
		System.out.println("Ranges....................................................");
		System.out.println("min value of 'byte' is  ::==>" + Byte.MIN_VALUE + " and max value is "+ Byte.MAX_VALUE);
		System.out.println("min value of 'short' is  ::==>" + Short.MIN_VALUE + " and max value is "+ Short.MAX_VALUE);
		System.out.println("min value of 'int' is  ::==>" + Integer.MIN_VALUE + " and max value is "+ Integer.MAX_VALUE);
		System.out.println("min value of 'long' is  ::==>" + Long.MIN_VALUE + " and max value is "+ Long.MAX_VALUE);
		System.out.println("min value of 'float' is  ::==>" + Float.MIN_VALUE + " and max value is "+ Float.MAX_VALUE);
		System.out.println("min value of 'double' is  ::==>" + Double.MIN_VALUE + " and max value is "+ Double.MAX_VALUE);
		System.out.println("min value of 'byte' is  ::==>" + Character.MIN_VALUE + " and max value is "+ Character.MAX_VALUE);
		
		/* Boolean have only true and false as values. No min or max value hence, 
		code in following line will not work */
		//System.out.println("min value of 'boolean' is  ::==>" + Boolean.MIN_VALUE + " and max value is "+ Boolean.MAX_VALUE);
		System.out.println("Boolean does not have min or max value");	
		
		System.out.println("----------------------------------------------------------");
		System.out.println("What happens when range is crossed");
		System.out.println("Following lines will create compilation errors ....");
		System.out.println(" byte_var=127+1; \n byte_var=-128-1");
		/*
		byte_var=127+1;
		byte_var=-128-1;
		*/
		
		System.out.println("----------------------------------------------------------");
		System.out.println("What can be incremented and how");
		System.out.println("Integer is incremented "+ ++int_var);
		System.out.println("Integer is incremented again "+ (int_var=int_var+ 1));
		System.out.println("Integer is incremented again... "+ (int_var+= 1));
		
		System.out.println("Byte is incremented "+ ++byte_var);
		System.out.println("Byte is incremented again... "+ (byte_var+= 1));
		System.out.println("Following code doesn't work! Compilation error!!");
		System.out.println("System.out.println(\"Byte is incremented again \"+ (byte_var=byte_var+ 1)");
		System.out.println("It is because, it means byte=byte+int and hence invalid");
		
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new AllDataTypesInJava();
	
	}
}

package com.igate.lesson3.finaldemos;

/*
 * Below code will not work 
 * as class Base is declared as final
 */
public class Derived extends Base {

}

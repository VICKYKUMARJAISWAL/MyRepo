package com.hackerearth;

import java.util.Arrays;
import java.util.Scanner;

public class MaximumDishes {

	public static void main(String[] args) {
		


		Scanner sc = new Scanner(System.in);

		int noOfTestCases = sc.nextInt();
		
		for (int k = 1; k <= noOfTestCases; k++) {
			int raguCalories = sc.nextInt();
			int sayanCalories = sc.nextInt();
			int noOfElements = sc.nextInt();
			int count1 = 0,count2=0;
			int a[] = new int[noOfElements];

			for (int i = 0; i < a.length; i++) {

				a[i] = sc.nextInt();
			}
			Arrays.sort(a);
			
			

			for (int i = 0; i < a.length; i++) {
				if(raguCalories>=a[i]){
					count1++;
					raguCalories = raguCalories-a[i];
				}
				
				if(sayanCalories>=a[i]){
					count2++;
					sayanCalories = sayanCalories-a[i];
				}
				
				if(raguCalories<a[i] && sayanCalories<a[i]) break;
					
			}
			if(count1==count2){
				System.out.println("tie");
			}else if(count1>count2){
				System.out.println("raghu won");
			}else{
				System.out.println("sayan won");
			}
		}

		

	
	}
}

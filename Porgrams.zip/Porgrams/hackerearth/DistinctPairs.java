package com.hackerearth;

import java.util.Scanner;

public class DistinctPairs {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int noOfTestCases = sc.nextInt();
		
		for (int k = 1; k <= noOfTestCases; k++) {
			int noOfElements = sc.nextInt();
			int count = 0;
			int a[] = new int[noOfElements];

			for (int i = 0; i < a.length; i++) {

				a[i] = sc.nextInt();
			}

			

			for (int i = 0; i < a.length; i++) {

				for (int j = i; j < a.length; j++) {

					if (a[i] == a[j]) {
						count++;
					}

				}
			}
			System.out.println(count);
		}

		

	}

}

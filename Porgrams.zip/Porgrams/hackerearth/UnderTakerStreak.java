package com.hackerearth;

import java.util.Scanner;

public class UnderTakerStreak {

	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int noOfElements = sc.nextInt();
		
		
		UnderTakerStreak  gm = new UnderTakerStreak();
		for (int i = 0; i < noOfElements; i++) {
			int x= sc.nextInt();
			
			gm.underTakerStreak(x);
			
		}
		
	

	}
	
	
	public void underTakerStreak(Integer x){
		
		 
		String s = x.toString();
		int a [] = new int[s.length()]; int i =0; boolean check = false;
		for (int j = 0; j < a.length; j++) {
			if(s.charAt(j)==2 && s.charAt(j+1)==1){
				System.out.println(s.charAt(j));
				check = true;
			}
		}
		
		if(x%21==0){
			System.out.println("The streak is broken!");
		}else if(check){
			System.out.println("The streak is broken!");
		}else{
			System.out.println("The streak lives still in our heart!");
		}
		
	}
}

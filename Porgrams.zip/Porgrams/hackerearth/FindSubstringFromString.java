package com.hackerearth;

import java.util.Scanner;

public class FindSubstringFromString {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int no=sc.nextInt();
		FindSubstringFromString obj = new FindSubstringFromString();
		for(int i=0;i<no;i++){
			String str1=sc.next(); 
			String str2 = sc.next();
			obj.findSubstring(str2, str1);
		}
	

	}
	
	public void findSubstring(String s1, String s2){
		int len = s1.length();
		StringBuffer buffer;
		boolean check = true;
		for (int i = 0; i < len; i++) {
			
			if(s2.charAt(0) == s1.charAt(i)){
				
				
				if (s2.length() + i <= len && s1.substring(i, i + s2.length()).equals(s2)) {

					System.out.println("Yes");
					check = false;
					break;
				} 
				else if (i - s2.length() >= 0) {
					buffer = new StringBuffer(s1.substring(i - s2.length()+1, i+1));
					buffer = buffer.reverse();
					if ((buffer.toString()).equals(s2))
					{
						System.out.println("Yes");
						check = false;
						break;
					}
				}
				
			}
			
		}
		
		if(check) System.out.println("No");
		
		
	}

}

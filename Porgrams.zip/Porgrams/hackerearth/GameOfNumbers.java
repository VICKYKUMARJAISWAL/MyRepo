package com.hackerearth;
import java.util.Scanner;

public class GameOfNumbers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int noOfElements = sc.nextInt();
		
		
		GameOfNumbers  gm = new GameOfNumbers();
		for (int i = 0; i < noOfElements; i++) {
			int x= sc.nextInt();
			int y = sc.nextInt();
			gm.findSpecialNumbers(x, y);
			
		}
		
	}
	
	public void findSpecialNumbers(int x,int y){
		int count =0;
		int range = (int) Math.sqrt((double)y);
		for (int i = x; i <=y ; i++) {
			boolean check = true;
			for (int j = 2; j <=range; j++) {
				
				if(i%(j*j)==0){
					check = false;
					break;
				}
				
			}
			
			if(check) count++;
			
		}
		System.out.println(count);
	}

}

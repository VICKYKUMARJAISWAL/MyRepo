package com.hackerearth;

import java.util.Scanner;

public class GirlFriendsDemands {

	
	public static void main(String[] args) {

		GirlFriendsDemands numbers = new GirlFriendsDemands();
		Scanner sc = new Scanner(System.in);
		String demand = sc.next();
		int noOfElements = sc.nextInt();
		StringBuffer sb = new StringBuffer(demand);
		for (int i = 0; i < noOfElements; i++) {
			int x= sc.nextInt();
			int y =sc.nextInt();
			numbers.girlfriendDemands(sb, x,y);
			
		}
		
	
	}
	
	 public void girlfriendDemands(StringBuffer str,int x,int y){
		 int j=0;
		 if(str.length()<x || str.length()<y){
		 if(x>y){
			  j = x/5;
		 }else{
			  j = y/5;
		 }
		 
		 for (int i = 0; i < j; i++) {
			str.append(str);
			
		}}
		 
	    	if(str.charAt(x-1)==str.charAt(y-1)){
	    		System.out.println("Yes");
	    	}else{
	    		System.out.println("No");
	    	}
	    	
	    	
	    } 
}


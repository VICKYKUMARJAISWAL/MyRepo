package com.hackerearth;

import java.util.Scanner;

public class PerfectString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		int noOfString=sc.nextInt();
		for(int i=0;i<noOfString;i++){
		String str=sc.next();
		PerfectString pf = new PerfectString();
		pf.checkPerfectString(str.toLowerCase());
		}

	}
	public void checkPerfectString(String str){
		int len=str.length();
		if(len<26){
			System.out.println("NO");
			return;
		}
		char ch[]= new char[26];
		
		int j=0;
		for(int i=97;i<=122;i++){
			ch[j]=(char) i;
			j++;
		}
		int length=ch.length;
		int k=0;
		for(k=0;k<length;k++){
			boolean check =false;
			for(int l=0;l<len;l++){
				
				if(ch[k]==str.charAt(l)){
					check=true;
					break;
				}
			}
			if(!check){
				System.out.println("NO");
				break;
			}
		}
		if(k==26){
			System.out.println("YES");
		}
		
	}

}

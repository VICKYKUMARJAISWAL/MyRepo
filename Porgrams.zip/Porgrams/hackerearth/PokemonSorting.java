package com.hackerearth;

import java.util.Arrays;
import java.util.Scanner;

import com.practice.sort.InsertionSort;

public class PokemonSorting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int noOfElements = sc.nextInt();
		int count = 0;
		int a[] = new int[noOfElements];

		for (int i = 0; i < a.length; i++) {

			a[i] = sc.nextInt();
		}
		
		PokemonSorting sort= new PokemonSorting();
		sort.pokemonEvolution(sort.insertionSort(a));
		
		

	}
	
	public int[] insertionSort(int a[]){
		int j=0;
		int temp=0;
		for(int i=1;i<a.length;i++){
			j=i-1;
			temp=a[i];
			while(j>-1 && temp>a[j] ){
				a[j+1]=a[j];
				j--;
			}
			a[j+1]=temp;
		}
		return a;
		
	}
	
	public void pokemonEvolution(int a[]){
		
		int len=a.length;
		int max=0;
		for(int i=0;i<len;i++){
			
			if(i+a[i]+2>max){
				max=i+a[i]+2;
			}
			
		}
		System.out.println(max);
	}
	

}

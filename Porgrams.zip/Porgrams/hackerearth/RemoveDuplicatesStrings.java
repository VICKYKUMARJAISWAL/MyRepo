package com.hackerearth;

import java.util.Scanner;

public class RemoveDuplicatesStrings {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int no=sc.nextInt();
		RemoveDuplicatesStrings obj = new RemoveDuplicatesStrings();
		for(int i=0;i<no;i++){
			String str=sc.next();
			obj.removeDuplicateString(str);
		}
	

	}
	public void removeDuplicateString(String str){
		int len = str.length();
		for(int i=0;i<len;i++){
			int j=i+1;
			
			while( j<len && str.charAt(i)==str.charAt(j) ){
				j++;
			}
			System.out.print(str.charAt(i));
			i=j-1;
		}
		System.out.println();
	}

}

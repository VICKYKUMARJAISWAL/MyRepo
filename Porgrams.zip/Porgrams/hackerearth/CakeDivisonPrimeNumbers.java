package com.hackerearth;

import java.util.Scanner;

public class CakeDivisonPrimeNumbers {
	
	public static void main(String[] args) {
		CakeDivisonPrimeNumbers numbers = new CakeDivisonPrimeNumbers();
		Scanner sc = new Scanner(System.in);
		int noOfElements = sc.nextInt();
		for (int i = 0; i < noOfElements; i++) {
			int x= sc.nextInt();
			numbers.primeNumbers(x);
			
		}
		
	}
	
	
	public void  primeNumbers(int n){
		int a  = n/2;
		boolean check = true;
		
		
		for (int i = 2; i <= a; i++) {
			if ((n - i) % 2 != 0) {
				if (isPrime(i) && isPrime(n - i)) {
					// System.out.println(i + " " + (n-i));
					check = false;
					break;
				}
			}

		}
		
		if(check){
			System.out.println("Arijit");
		}else{
			System.out.println("Deepa");
		}
		
		
		
		
	}
	
	public boolean isPrime(int n){
		int i;
		for ( i = 2; i < n; i++) {
			
			if(n%i==0){
				break;
			}
		}
		
		if(n==i){
			return true;
		}
		
		return false;
	}
	

}

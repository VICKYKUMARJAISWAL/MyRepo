package com.hackerearth;

import java.util.Arrays;
import java.util.Scanner;

public class IkshuMachineGun {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int noOfElements = sc.nextInt();
		
		int a[] = new int[noOfElements];
		
		for (int i = 0; i < noOfElements; i++) {
			a[i] = sc.nextInt();
			
		}
		Arrays.sort(a);
		IkshuMachineGun gun = new IkshuMachineGun();
		gun.findCommands(a);
		
	}
	
	
	public void findCommands(int a[]){
		
		int j=0; int len =a.length;
		
		for (int i = 0; i < len; i++) {
			
			System.out.print(a[i] -j  + " ");
			j++;
		}
	}

}

package com.hackerearth;

import java.util.Scanner;

public class SubStringCharactersInaString {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int no=sc.nextInt();
		SubStringCharactersInaString obj = new SubStringCharactersInaString();
		for(int i=0;i<no;i++){
			String str1=sc.next(); 
			String str2 = sc.next();
			obj.n2complexity(str1, str2);
		}
	

	}

	
	public void n2complexity(String s1,String s2){
		char [] str= s2.toCharArray();
		for (int i = 0; i < s1.length(); i++) {
			boolean check = true;
			
			for (int j = 0; j < str.length; j++) {
				if(s1.charAt(i)==str[j]){
					str[j] = '!';
					check = false;
					break;
				}
			}
			
			if(check){
				System.out.println("NO");
				return;
			}
		}
		
		System.out.println("YES");
		
	}
}

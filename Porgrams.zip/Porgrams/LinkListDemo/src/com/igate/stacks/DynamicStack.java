package com.igate.stacks;

public class DynamicStack {
	
	private int capacity;
	private int top;
	private int arr[];
	
	
	public DynamicStack() {
		capacity = 5;
		top = -1;
		arr = new int[5];
	}
	
	
	public boolean isFull(){
		
		return (top==capacity-1);
	}
	
	
	public boolean isEmpty(){
		
		return (top==-1);		
	}
	
	
	public void push(int item){
		
		if(isFull()){
			
			capacity = capacity *2;
			int temp[] = new int[capacity];
			
			for(int i=0;i<arr.length;i++){
				temp[i] = arr[i];
			}
			
			arr = temp;
			
			
		}
			arr[++top] = item;
		
		
	}
	
	public int pop(){
		
		if(capacity/2 == (top+1)){
			
			capacity = capacity/2;
			int temp[] = new int[capacity];  
			for(int i=0;i<=top;i++){
				temp[i] = arr[i];
			}
			
			arr = temp;
			
		}
		
		return arr[top--];
		
	}
	
	public void display(){
		
		for (int i = 0; i <= top; i++) {
			
			System.out.println(arr[i]);
		}
		
	}
	
	public int size(){
		
		return top+1;
	}
	
	public void deleteStack(){
		top = -1;
	}
	
	
	public static void main(String[] args) {
		
		DynamicStack ds =  new DynamicStack();
		
		System.out.println(ds.size());
		
		ds.push(3);
		
		ds.push(31);
		ds.push(2);
		ds.push(232);
		ds.push(434);
		ds.push(2323);
		ds.push(657);
		
		System.out.println("size ---> " + ds.size());
		/*System.out.println(ds.pop());
		ds.pop();*/
		ds.display();
		
	
		System.out.println();
		
		ds.pop(); 
		System.out.println("size ---> " + ds.size());
		System.out.println("capacity  " + ds.capacity + " arr length " + ds.arr.length);
		ds.display();
		
		
		System.out.println();
		
		ds.pop(); 
		System.out.println("size ---> " + ds.size());
		System.out.println("capacity  " + ds.capacity + " arr length " + ds.arr.length);
		ds.display();
		
		
		System.out.println();
		
		ds.pop(); 
		System.out.println("size ---> " + ds.size());
		System.out.println("capacity  " + ds.capacity + " arr length " + ds.arr.length);
		ds.display();
		
		

		
	}

}

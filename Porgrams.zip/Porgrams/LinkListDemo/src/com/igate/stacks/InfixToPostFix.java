package com.igate.stacks;

import java.util.HashMap;

public class InfixToPostFix {

	public static void main(String[] args) {

		HashMap<Character, Integer> precedenceMap = new HashMap<Character, Integer>();

		precedenceMap.put('^', 3);
		precedenceMap.put('*', 2);
		precedenceMap.put('/', 2);
		precedenceMap.put('-', 1);
		precedenceMap.put('+', 1);

		StringBuffer str = new StringBuffer("A+B*C+D+(G^H)");

		
		InfixToPostFix obj = new InfixToPostFix();
		obj.infixToPostfix(precedenceMap, str);
		
	}

	public String infixToPostfix(HashMap<Character, Integer> pMap,
			StringBuffer str) {

		CharacterStack cs = new CharacterStack();
		cs.push('(');
		str.append(')');
		System.out.println(pMap.get('-'));

		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < str.length(); i++) {

			Character c = str.charAt(i);

			if (c == '(') {

				cs.push(c);

			} else if (c >= 65 && c <= 91) {

				sb.append(c);

			} else if (pMap.get(c) != null) {

				char ch = cs.returnTop();

				if (ch == '(') {
					
					cs.push(c);
					
				}else{
					while (ch!='(' && pMap.get(ch) >= pMap.get(c)) {

						sb.append(ch);
						cs.pop();
						
						ch = cs.returnTop();

					}
					cs.push(c);
				}
				
				

			} else if (c == ')') {

				char ch = cs.returnTop();

				while (ch != '(') {

					sb.append(ch);
					cs.pop();
					ch = cs.returnTop();
				}
				
				cs.pop();

			}

		}

		System.out.println(sb);

		return null;

	}

}

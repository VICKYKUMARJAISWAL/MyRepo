package com.igate.stacks;

public class IntegerStack {
	


	private int capacity;
	private int top;
	private int arr[];

	public IntegerStack() {
		capacity = 10;
		top = -1;
		arr = new int[capacity];
	}

	public void push(int item) {

		arr[++top] = item;

	}

	public void pop() {

		top = top - 1;

	}
	
	public int returnTop(){
		
		return arr[top];
	}


}

package com.igate.stacks;

public class PostfixEvaluation {
	
	
	public static void main(String[] args) {
		
		PostfixEvaluation obj = new PostfixEvaluation();
		char c =0;
		System.out.println(c);
		System.out.println(obj.postFixEvaluation(new StringBuffer("224*+1+23^+")));
		
	}
	
	
	public int postFixEvaluation(StringBuffer str){
		
		IntegerStack is = new IntegerStack();
		
		for(int i=0;i<str.length();i++){
			
			int c=str.charAt(i);
			if(c >= 48 && c <= 57)
			 c = c - 48;
			
			
			if(c >= 0 && c <= 10){
				is.push(c);
			}else{
				
				int a = is.returnTop();
				is.pop();
				int b= is.returnTop();
				is.pop();
				
				if(c=='+'){
					is.push(a+b);
				}else if(c=='*'){
					is.push(b*a);
				}else if(c=='/'){
					is.push(b/a);
				}else if(c=='^'){
					is.push((int)Math.pow(b, a));
				}
				
			}
			
			
		}
		
		
		
		
		
		
		return is.returnTop();
		
	}

}

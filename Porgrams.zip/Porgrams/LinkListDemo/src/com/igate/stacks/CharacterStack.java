package com.igate.stacks;

public class CharacterStack {

	private int capacity;
	private int top;
	private char arr[];

	public CharacterStack() {
		capacity = 10;
		top = -1;
		arr = new char[capacity];
	}

	public void push(char item) {

		arr[++top] = item;

	}

	public void pop() {

		top = top - 1;

	}
	
	public char returnTop(){
		
		return arr[top];
	}
}

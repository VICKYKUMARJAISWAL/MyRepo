package com.igate.practice;

public class ListDemo {
	
	
	public static void main(String[] args) {
		
		LinkedListImpl list = new LinkedListImpl();
		
		list.add(11);
		list.add(13);
		list.add(16);
		list.add(19);
		
		
		
		
		list.display();
		
		/*list.delete();
		
		System.out.println("-----------------------");
		
		list.display();*/
		
		//list.findNthFromLast(1);
		
		
	/*	list.addSpecific(44, 7);
		
		list.deleteSpecific(2);
		System.out.println();
		list.display();
		
		System.out.println();
		list.findMiddleInOnePass();*/
		
		System.out.println("size--->" + list.size());
		System.out.println();
		System.out.println();
		System.out.println();
		//list.reverseListUsingMemory();
		//list.display();
		
		
		/*list.createLoop();
		//list.findLoop();
		
		list.findStartOfLoop();
		list.findSizeOfLoop();*/
		
		//list.insertSortedLink(1);
		
		//list.display();
		//list.createLoop();
		//list.findLoopUsingHashMap();
		
		LinkedListImpl list2 = new LinkedListImpl();
		list2.add(21);
		list2.add(22);
		list2.add(26);
		list2.add(29);
		
		list.mergeLists(list2.getHeadNode());
		
		
		
		
	}

}

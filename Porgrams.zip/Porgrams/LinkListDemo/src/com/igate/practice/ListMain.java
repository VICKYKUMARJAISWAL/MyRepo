package com.igate.practice;

public class ListMain {

	public static void main(String[] args) {

		LinkedListImpl list = new LinkedListImpl();

		list.add(11);
		list.add(13);
		list.add(16);
		list.add(19);
		list.add(5);
		

		LinkedListImpl list2 = new LinkedListImpl();
		list2.add(-21);
		list2.add(-17);
		list2.add(22);
		list2.add(23);
		
		
		LinkedListImpl finalList = new LinkedListImpl();
		
		//finalList.mergeSortedLists(list.getHeadNode(), list2.getHeadNode());
		//finalList.display();
		
		
		list.exchangeAdjacent();
		list.display();

	}

}

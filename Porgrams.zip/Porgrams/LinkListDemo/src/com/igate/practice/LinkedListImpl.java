package com.igate.practice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LinkedListImpl {

	private ListNode headNode;

	public ListNode getHeadNode() {
		return headNode;
	}

	public void setHeadNode(ListNode headNode) {
		this.headNode = headNode;
	}

	public void add(int data) {

		if (headNode == null) {

			headNode = new ListNode(data);

		} else {

			ListNode currNode = headNode;

			while (currNode.getNext() != null) {
				currNode = currNode.getNext();
			}

			currNode.setNext(new ListNode(data));

		}

	}

	public void addSpecific(int data, int pos) {

		if (pos <= 0 || pos > size() + 1) {
			System.out.println("Pos can be 1 to " + (size() + 1));
		} else if (pos == 1) {
			ListNode node = new ListNode(data);
			node.setNext(headNode);
			headNode = node;
		} else {
			int count = 1;
			ListNode currNode = headNode;
			while (currNode.getNext() != null) {
				if (count == pos - 1) {
					break;
				}

				currNode = currNode.getNext();
			}

			ListNode node = new ListNode(data);
			node.setNext(currNode.getNext());
			currNode.setNext(node);
		}

	}

	public int size() {

		ListNode currNode = headNode;
		int count = 0;

		while (currNode != null) {

			count++;
			currNode = currNode.getNext();

		}

		return count;
	}

	public void display() {

		ListNode currNode = headNode;

		while (currNode != null) {
			System.out.println(currNode.getData());
			// System.out.println(currNode.getNext());
			currNode = currNode.getNext();

		}

	}

	public void delete() {

		ListNode currNode = headNode;

		while (currNode.getNext().getNext() != null) {

			currNode = currNode.getNext();

		}

		currNode.setNext(null);

	}

	public void deleteSpecific(int pos) {

		if (pos < 1 || pos > size()) {

			System.out.println("can't delete");
		} else if (pos == 1) {
			ListNode temp = headNode.getNext();
			headNode.setNext(null);
			headNode = temp;
		} else {

			int count = 0;
			ListNode currNode = headNode;
			while (count < pos - 2) {

				currNode = currNode.getNext();
				count++;
			}
			ListNode temp = currNode.getNext();
			currNode.setNext(temp.getNext());
			temp.setNext(null);

		}
	}

	public void findNthFromLast(int n) {
		HashMap<Integer, ListNode> hm = new HashMap<Integer, ListNode>();

		ListNode currNode = headNode;
		int i = 1, count = 0;
		while (currNode != null) {

			hm.put(i++, currNode);
			count++;
			currNode = currNode.getNext();

		}

		System.out.println(hm);
		System.out.println("count -- " + count);

		int nthFromLast = count - n + 1;
		System.out
				.println("nth from last --> " + hm.get(nthFromLast).getData());

	}

	public void findMiddleInOnePass() {

		ListNode firstPtr = headNode;
		ListNode secondPtr = headNode;

		while (secondPtr.getNext() != null
				&& secondPtr.getNext().getNext() != null) {
			firstPtr = firstPtr.getNext();
			secondPtr = secondPtr.getNext().getNext();

		}

		System.out.println("Middle-->" + firstPtr.getData());

	}

	public void reverseList() {
		ListNode firstPtr = null;
		ListNode SecondPtr = null;

		while (headNode != null) {

			firstPtr = headNode.getNext();
			headNode.setNext(SecondPtr);
			SecondPtr = headNode;
			headNode = firstPtr;

		}

		headNode = SecondPtr;
	}

	public void reverseListUsingMemory() {
		ListNode currNode = headNode;
		List<Integer> al = new ArrayList<Integer>();
		while (currNode != null) {

			al.add(currNode.getData());
			currNode = currNode.getNext();

		}

		// System.out.println(al.size());
		// System.out.println(al.get(al.size()));
		headNode = null;
		for (int i = al.size() - 1; i >= 0; i--) {
			add(al.get(i));
		}

	}

	public void createLoop() {

		ListNode currNode = headNode;

		while (currNode.getNext() != null) {
			currNode = currNode.getNext();
		}

		currNode.setNext(headNode.getNext());

	}

	public void findLoop() {

		ListNode firstPtr = headNode;
		ListNode secondPtr = headNode;
		boolean check = false;

		while (firstPtr.getNext() != null
				&& firstPtr.getNext().getNext() != null) {

			secondPtr = secondPtr.getNext();
			firstPtr = firstPtr.getNext().getNext();
			if (firstPtr == secondPtr) {
				check = true;
				break;
			}

		}

		if (check) {
			System.out.println("Exists" + firstPtr.getData());
		} else {
			System.out.println("Sorry");
		}

	}

	public void findStartOfLoop() {

		ListNode firstPtr = headNode;
		ListNode secondPtr = headNode;
		boolean check = false;

		while (firstPtr.getNext() != null
				&& firstPtr.getNext().getNext() != null) {

			secondPtr = secondPtr.getNext();
			firstPtr = firstPtr.getNext().getNext();
			if (firstPtr == secondPtr) {
				check = true;
				break;
			}

		}

		System.out.println("first" + firstPtr.getData());
		System.out.println("second" + secondPtr.getData());

		if (check) {

			secondPtr = headNode;
			while (firstPtr != secondPtr) {
				firstPtr = firstPtr.getNext();
				secondPtr = secondPtr.getNext();
			}

			System.out.println("Start of Loop " + firstPtr.getData());

		} else {
			System.out.println("Sorry No Loop");
		}

	}

	public void findSizeOfLoop() {

		ListNode firstPtr = headNode;
		ListNode secondPtr = headNode;
		boolean check = false;

		while (firstPtr.getNext() != null
				&& firstPtr.getNext().getNext() != null) {

			secondPtr = secondPtr.getNext();
			firstPtr = firstPtr.getNext().getNext();
			if (firstPtr == secondPtr) {
				check = true;
				break;
			}

		}

		System.out.println("first" + firstPtr.getData());
		System.out.println("second" + secondPtr.getData());

		int count = 1;

		if (check) {

			firstPtr = firstPtr.getNext();

			while (firstPtr != secondPtr) {
				firstPtr = firstPtr.getNext();
				count++;
			}

			System.out.println("size of Lopp --->> " + count);

		} else {
			System.out.println("No Loop");
		}

	}

	public void insertSortedLink(int data) {

		ListNode currNode = headNode;
		ListNode temp = new ListNode(data);
		if (currNode.getData() > data) {

			temp.setNext(headNode);
			headNode = temp;

		} else {

			while (currNode.getNext() != null
					&& currNode.getNext().getData() < data) {

				currNode = currNode.getNext();

			}

			temp.setNext(currNode.getNext());
			currNode.setNext(temp);

		}

	}

	public void findLoopUsingHashMap() {

		ListNode currNode = headNode;
		HashMap<ListNode, Integer> hm = new HashMap<ListNode, Integer>();

		while (currNode != null) {
			if (hm.get(currNode) == null) {
				hm.put(currNode, 1);
			} else {
				System.out.println("Loop Exists");
				break;
			}

			currNode = currNode.getNext();
		}

		System.out.println("NO LOOP");

	}

	public void mergeLists(ListNode list2) {

		ListNode currNode = list2;

		while (currNode.getNext() != null) {

			currNode = currNode.getNext();

		}

		currNode.setNext(headNode.getNext().getNext());

		currNode = list2;

		/*
		 * while(currNode!=null){ System.out.println(currNode.getData());
		 * currNode = currNode.getNext(); }
		 */

		isMerging(list2);

	}

	public boolean isMerging(ListNode list2) {

		ListNode firstList = headNode;
		ListNode secondList = list2;
		boolean check = false;

		while (firstList != null) {

			secondList = list2;

			while (secondList != null) {

				if (firstList == secondList) {
					check = true;
					break;
				}

				secondList = secondList.getNext();
			}

			if (check) {
				System.out.println("Merrging Point -->> "
						+ secondList.getData());
				return true;
			}

			firstList = firstList.getNext();

		}

		if (!check) {
			System.out.println("Not Merging");
		}

		return false;

	}
	
	
	public boolean isMergingUsingMap(ListNode list2){
		
		
		HashMap<ListNode,Integer> hm = new HashMap<ListNode, Integer>();
		ListNode currNode = list2;
		boolean check = false;
		
		while(currNode!=null){
			hm.put(currNode, 1);
			currNode = currNode.getNext();
			
		}
		
		ListNode list1= headNode;
		while(list1!=null){
			
			if(hm.get(list1)!=null){
				System.out.println("merging " + list1.getData());
				check = true;
				break;
			}
			
			list1 = list1.getNext();
			
		}
		if(!check)
		System.out.println("Not Merging");
		return false;
	}
	
	
	public void mergeSortedLists(ListNode list1, ListNode list2) {

		while (list1 != null && list2 != null) {
			if (list1.getData() < list2.getData()) {

				add(list1.getData());
				list1 = list1.getNext();

			} else {
				add(list2.getData());
				list2 = list2.getNext();
			}
		}
		
		
		while(list1!=null){
			add(list1.getData());
			list1 = list1.getNext();
		}
		
		while(list2!=null){
			add(list2.getData());
			list2 = list2.getNext();
		}


	}
	
	
	public void exchangeAdjacent(){
		
		ListNode currNode = headNode;
		
		while(currNode!=null && currNode.getNext()!=null){
			int temp = currNode.getData();
			currNode.setData(currNode.getNext().getData());
			currNode.getNext().setData(temp);
			
			currNode = currNode.getNext().getNext();
		}
		
		
		
	}

}

package com.igate.javaRevisited;

public class FindMissingNumberArray {
	
	
	public static void main(String[] args) {
		int arr[] = new int[100];
		
		for (int i = 0; i < arr.length; i++) {
			
			arr[i] = i+1;
		}
		
		arr[98] = 98;
		
		FindMissingNumberArray obj = new FindMissingNumberArray();
		obj.findMissing(arr);
	}
	
	
	public void findMissing(int a[]){
		int missingNo =0;
		for (int i = 1; i <= 100; i++) {
			
			boolean check = false;
			
			for (int j = 0; j < a.length; j++) {
				
				if(a[j] == i){
					check=true;
					break;
				}
				
			}
			
			if(!check){
				missingNo = i;
				break;
			}
			
		}
		
		System.out.println(missingNo);
		
		
	}
	
	
	public void findMissingUsingSum(int a[]){
		
		for (int i : a) {
			System.out.print(i + " ");
		}
		
		int sum = 0;
		int sumOfArray = 0;
		
		sum = 50 * (2 +  99);
		for (int i : a) {
			sumOfArray =sumOfArray+i;
		}
		System.out.println("sum " + sum);
		System.out.println(sumOfArray);
		System.out.println(sum - sumOfArray);
		
		
	}

}
